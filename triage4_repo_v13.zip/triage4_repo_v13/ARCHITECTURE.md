# triage4 — ARCHITECTURE

## Purpose

`triage4` is a modular stand-off triage architecture that integrates:

- micro-perception of the casualty body,
- semantic reasoning over observed evidence,
- mission-world coordination and operator-facing visualization.

It synthesizes three upstream ideas:

- `meta2` — structure, descriptors, fractal logic
- `infom` — graph memory, relations, semantic reasoning
- `in4n` — dynamic visualization, 3D navigation, replay

## K3 Fractal Matrix

| Layer | `.1` Linear / Signal Mode | `.2` Structural / Relational Mode | `.3` Dynamic / Spatiotemporal Mode |
|---|---|---|---|
| **K3-1 Micro Perception** | **1.1 Temporal Signature Layer** — breathing lines, perfusion signals, micro-motion curves | **1.2 Spatial Body Map Layer** — body polygons, wound regions, thermal overlays, 2D skeleton | **1.3 Dynamic Skeletal Graph Layer** — pseudo-3D body graph, motion graph, evolving body state |
| **K3-2 Semantic Reasoning** | **2.1 Evidence Semantics Layer** — evidence tokens, normalized observations | **2.2 Relational Body-State Layer** — hypothesis graph, state relations, support/conflict links | **2.3 Temporal Triage Reasoning Layer** — urgency dynamics, deterioration trend, revisit logic |
| **K3-3 Mission / World** | **3.1 Tactical Scene Layer** — local mission map, casualty markers, platform positions | **3.2 Mission Coordination Layer** — assignments, task graph, revisit queue | **3.3 Strategic World & Replay Layer** — replay timeline, world-state memory, forecast |

## Rows

- **K3-1** = observe the body
- **K3-2** = understand the body state
- **K3-3** = act in the mission world

## Columns

- **.1** = signals and direct meaning
- **.2** = maps, structures, relations
- **.3** = dynamics, time, control

## Diagonal build strategy

- `1.1 -> 2.1 -> 3.1`
- `1.2 -> 2.2 -> 3.2`
- `1.3 -> 2.3 -> 3.3`

This keeps the MVP incremental and testable.
