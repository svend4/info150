from dataclasses import dataclass, field, asdict
from typing import Any


@dataclass
class GeoPose:
    x: float
    y: float
    z: float = 0.0
    frame: str = "map"


@dataclass
class SignalLine:
    name: str
    values: list[float]
    confidence: float


@dataclass
class EvidenceToken:
    name: str
    score: float
    source: str
    explanation: str


@dataclass
class BodyRegion:
    name: str
    polygon: list[tuple[float, float]]


@dataclass
class WoundCandidate:
    region_name: str
    score: float
    polygon: list[tuple[float, float]]
    explanation: str


@dataclass
class StateHypothesis:
    name: str
    score: float
    evidence: list[str] = field(default_factory=list)
    explanation: str = ""


@dataclass
class CasualtyNode:
    id: str
    location: GeoPose
    signal_lines: list[SignalLine] = field(default_factory=list)
    evidence_tokens: list[EvidenceToken] = field(default_factory=list)
    body_regions: list[BodyRegion] = field(default_factory=list)
    wound_candidates: list[WoundCandidate] = field(default_factory=list)
    state_hypotheses: list[StateHypothesis] = field(default_factory=list)
    body_state_graph: dict[str, Any] = field(default_factory=dict)
    dynamic_body_graph: dict[str, Any] = field(default_factory=dict)
    triage_priority: str = "unknown"
    confidence: float = 0.0
    deterioration_risk: float = 0.0
    bleeding_score: float = 0.0
    thermal_anomaly_score: float = 0.0
    uncertainty: dict[str, Any] = field(default_factory=dict)
    status: str = "detected"
    assigned_asset: str | None = None
    revisit_required: bool = False
    priority_history: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
