from enum import Enum


class TriagePriority(str, Enum):
    UNKNOWN = "unknown"
    MINIMAL = "minimal"
    DELAYED = "delayed"
    IMMEDIATE = "immediate"


class CasualtyStatus(str, Enum):
    DETECTED = "detected"
    OBSERVED = "observed"
    TAGGED = "tagged"
