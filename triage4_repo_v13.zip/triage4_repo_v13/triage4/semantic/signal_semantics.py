from triage4.core.models import EvidenceToken
from triage4.semantic.evidence_tokens import EvidenceBuilder


class SignalSemanticsEngine:
    def __init__(self) -> None:
        self.builder = EvidenceBuilder()

    def from_signal_scores(
        self,
        chest_motion_score: float,
        perfusion_drop_score: float,
    ) -> list[EvidenceToken]:
        tokens: list[EvidenceToken] = []

        if chest_motion_score < 0.15:
            tokens.append(self.builder.low_chest_motion(score=round(1.0 - chest_motion_score, 3)))

        if perfusion_drop_score > 0.65:
            tokens.append(self.builder.poor_perfusion(score=round(perfusion_drop_score, 3)))

        return tokens

    def triage_from_tokens(self, tokens: list[EvidenceToken]) -> tuple[str, float]:
        score = 0.0

        for token in tokens:
            if token.name == "low_chest_motion":
                score += 0.45
            if token.name == "poor_perfusion_pattern":
                score += 0.30

        if score >= 0.65:
            return "immediate", round(score, 3)
        if score >= 0.30:
            return "delayed", round(score, 3)
        return "minimal", round(score, 3)
