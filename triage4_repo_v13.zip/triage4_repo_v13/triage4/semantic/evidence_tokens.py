from triage4.core.models import EvidenceToken


class EvidenceBuilder:
    def low_chest_motion(self, score: float) -> EvidenceToken:
        return EvidenceToken(
            name="low_chest_motion",
            score=score,
            source="breathing_curve",
            explanation="weak chest motion pattern detected",
        )

    def poor_perfusion(self, score: float) -> EvidenceToken:
        return EvidenceToken(
            name="poor_perfusion_pattern",
            score=score,
            source="perfusion_curve",
            explanation="possible low-perfusion pattern detected",
        )
