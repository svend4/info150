from __future__ import annotations

from triage4.core.models import CasualtyNode


class HumanHandoffBuilder:
    """Builds a compact medic-facing handoff payload."""

    def build(self, casualty: CasualtyNode) -> dict:
        top_hypotheses = [
            {
                "name": h.name,
                "score": h.score,
                "explanation": h.explanation,
            }
            for h in sorted(casualty.state_hypotheses, key=lambda x: x.score, reverse=True)[:3]
        ]
        return {
            "casualty_id": casualty.id,
            "priority": casualty.triage_priority,
            "confidence": casualty.confidence,
            "deterioration_risk": casualty.deterioration_risk,
            "uncertainty": casualty.uncertainty,
            "location": casualty.location.__dict__,
            "assigned_asset": casualty.assigned_asset,
            "revisit_required": casualty.revisit_required,
            "top_hypotheses": top_hypotheses,
            "recommended_action": self._recommended_action(casualty),
        }

    def _recommended_action(self, casualty: CasualtyNode) -> str:
        if casualty.triage_priority == "immediate":
            return "urgent medic assessment"
        if casualty.revisit_required:
            return "secondary remote assessment"
        return "routine follow-up"
