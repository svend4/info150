from __future__ import annotations
from triage4.repositories.job_repository import JobRepository
class JobControl:
    def __init__(self, db_path=None) -> None: self.repo = JobRepository(db_path)
    def cancel(self, job_id: str) -> dict: return self.repo.cancel(job_id)
    def retry(self, job_id: str) -> dict: return self.repo.retry(job_id)
