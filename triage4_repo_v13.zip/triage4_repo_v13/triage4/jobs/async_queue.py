from __future__ import annotations

from typing import Any, Callable

from triage4.jobs.worker_loop import BackgroundWorkerLoop


class AsyncJobQueue:
    def __init__(self) -> None:
        self._worker_loop = BackgroundWorkerLoop()

    def submit(self, job_id: str, fn: Callable[[], dict[str, Any]], on_success: Callable[[dict[str, Any]], None], on_error: Callable[[Exception], None]) -> None:
        self._worker_loop.submit(job_id, fn, on_success, on_error)

    def status(self) -> dict[str, Any]:
        return self._worker_loop.status()
