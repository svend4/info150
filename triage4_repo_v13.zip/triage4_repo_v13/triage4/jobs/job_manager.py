from __future__ import annotations

from typing import Any, Callable

from triage4.jobs.async_queue import AsyncJobQueue
from triage4.repositories.job_repository import JobRepository


class JobManager:
    def __init__(self) -> None:
        self.repo = JobRepository()
        self.async_queue = AsyncJobQueue()

    def queue_job(self, kind: str, payload: dict[str, Any]) -> dict[str, Any]:
        return self.repo.create(kind, payload)

    def queue(self, kind: str, payload: dict[str, Any]) -> dict[str, Any]:
        return self.queue_job(kind, payload)

    def complete(self, job_id: str, result: dict[str, Any]) -> dict[str, Any]:
        return self.repo.update(job_id, 'completed', result)

    def fail(self, job_id: str, error: str) -> dict[str, Any]:
        return self.repo.update(job_id, 'failed', {'error': error})

    def running(self, job_id: str) -> dict[str, Any]:
        return self.repo.update(job_id, 'running', {'message': 'job started'})

    def submit_async(self, kind: str, payload: dict[str, Any], fn: Callable[[], dict[str, Any]]) -> dict[str, Any]:
        job = self.queue_job(kind, payload)
        self.running(job['id'])
        self.async_queue.submit(
            job['id'],
            fn,
            lambda result: self.complete(job['id'], result),
            lambda exc: self.fail(job['id'], str(exc)),
        )
        return self.load(job['id'])

    def load(self, job_id: str) -> dict[str, Any]:
        return self.repo.load(job_id)

    def list(self, limit: int = 50) -> list[dict[str, Any]]:
        return self.repo.list(limit=limit)

    def worker_status(self) -> dict[str, Any]:
        return self.async_queue.status()
