from __future__ import annotations

import queue
import threading
from typing import Any, Callable


class BackgroundWorkerLoop:
    def __init__(self) -> None:
        self._q: "queue.Queue[tuple[str, Callable[[], dict[str, Any]], Callable[[dict[str, Any]], None], Callable[[Exception], None]]]" = queue.Queue()
        self._thread = threading.Thread(target=self._run, daemon=True, name='triage4-worker-loop')
        self._started = False

    def start(self) -> None:
        if not self._started:
            self._thread.start()
            self._started = True

    def submit(self, job_id: str, fn: Callable[[], dict[str, Any]], on_success: Callable[[dict[str, Any]], None], on_error: Callable[[Exception], None]) -> None:
        self.start()
        self._q.put((job_id, fn, on_success, on_error))

    def status(self) -> dict[str, Any]:
        return {
            'alive': self._thread.is_alive() if self._started else False,
            'started': self._started,
            'queue_depth': self._q.qsize(),
            'worker_name': self._thread.name,
        }

    def _run(self) -> None:
        while True:
            _job_id, fn, on_success, on_error = self._q.get()
            try:
                result = fn()
                on_success(result)
            except Exception as exc:  # pragma: no cover
                on_error(exc)
            finally:
                self._q.task_done()
