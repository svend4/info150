from __future__ import annotations

from typing import Any

from triage4.repositories.job_repository import JobRepository
from triage4.sim.demo_scene import make_replay_payload, make_world_state


class DurableWorkerProcess:
    def __init__(self, db_path=None) -> None:
        self.repo = JobRepository(db_path)

    def queued(self, limit: int = 25) -> list[dict[str, Any]]:
        return [j for j in self.repo.store.list_jobs_by_status('queued', limit=limit)]

    def run_once(self, limit: int = 10) -> dict[str, Any]:
        processed = []
        for job in self.queued(limit=limit):
            kind = job.get('kind')
            self.repo.update(job['id'], 'running', {'message': 'durable worker started'})
            payload = job.get('payload', {})
            if kind in {'durable_recompute_replay', 'recompute_replay_durable'}:
                result = {'session': make_replay_payload(persist=True, scenario_id=payload.get('scenario_id'))}
                self.repo.update(job['id'], 'completed', result)
                processed.append({'job_id': job['id'], 'kind': kind, 'status': 'completed'})
            elif kind in {'durable_recompute_world_state', 'recompute_world_state_durable'}:
                result = {'world_state': make_world_state(persist=True, scenario_id=payload.get('scenario_id'))}
                self.repo.update(job['id'], 'completed', result)
                processed.append({'job_id': job['id'], 'kind': kind, 'status': 'completed'})
            else:
                self.repo.update(job['id'], 'failed', {'error': 'unsupported durable job kind'})
                processed.append({'job_id': job['id'], 'kind': kind, 'status': 'failed'})
        return {'processed': len(processed), 'items': processed}

    def status(self) -> dict[str, Any]:
        queued = self.queued(limit=100)
        return {'queued': len(queued), 'mode': 'durable', 'items': [j['id'] for j in queued]}
