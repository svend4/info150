from __future__ import annotations

from triage4.core.models import WoundCandidate


class WoundCandidateBuilder:
    def from_priority_hint(
        self,
        priority_hint: str,
        body_regions: dict[str, list[tuple[float, float]]],
    ) -> list[WoundCandidate]:
        out: list[WoundCandidate] = []

        if priority_hint == "immediate":
            torso_poly = body_regions["torso"]
            out.append(
                WoundCandidate(
                    region_name="torso",
                    score=0.86,
                    polygon=self._shrink(torso_poly, factor=0.55),
                    explanation="strong wound candidate in torso region",
                )
            )
        elif priority_hint == "delayed":
            leg_poly = body_regions["left_leg"]
            out.append(
                WoundCandidate(
                    region_name="left_leg",
                    score=0.46,
                    polygon=self._shrink(leg_poly, factor=0.65),
                    explanation="moderate wound candidate in left leg region",
                )
            )

        return out

    def _shrink(
        self,
        poly: list[tuple[float, float]],
        factor: float,
    ) -> list[tuple[float, float]]:
        xs = [p[0] for p in poly]
        ys = [p[1] for p in poly]
        cx = sum(xs) / len(xs)
        cy = sum(ys) / len(ys)

        out = []
        for x, y in poly:
            out.append((cx + (x - cx) * factor, cy + (y - cy) * factor))
        return out
