from __future__ import annotations

from dataclasses import dataclass


Polygon = list[tuple[float, float]]


@dataclass
class BodyRegions:
    head: Polygon
    torso: Polygon
    left_arm: Polygon
    right_arm: Polygon
    left_leg: Polygon
    right_leg: Polygon

    def as_dict(self) -> dict[str, Polygon]:
        return {
            "head": self.head,
            "torso": self.torso,
            "left_arm": self.left_arm,
            "right_arm": self.right_arm,
            "left_leg": self.left_leg,
            "right_leg": self.right_leg,
        }


class BodyRegionPolygonizer:
    def build_from_center(
        self,
        center_x: float,
        center_y: float,
        width: float = 14.0,
        height: float = 28.0,
    ) -> dict[str, Polygon]:
        x1 = center_x - width / 2
        x2 = center_x + width / 2
        y1 = center_y - height / 2
        y2 = center_y + height / 2

        head_h = height * 0.18
        torso_h = height * 0.30
        leg_h = height * 0.34
        arm_h = height * 0.26

        head_w = width * 0.34
        torso_w = width * 0.42
        arm_w = width * 0.16
        leg_w = width * 0.15
        leg_gap = width * 0.06

        cx = center_x
        shoulder_y = y1 + head_h
        torso_y2 = shoulder_y + torso_h
        hip_y = torso_y2

        head = self._rect(cx - head_w / 2, y1, cx + head_w / 2, shoulder_y)
        torso = self._rect(cx - torso_w / 2, shoulder_y, cx + torso_w / 2, torso_y2)

        left_arm = self._rect(
            cx - torso_w / 2 - arm_w,
            shoulder_y + 1,
            cx - torso_w / 2,
            shoulder_y + arm_h,
        )
        right_arm = self._rect(
            cx + torso_w / 2,
            shoulder_y + 1,
            cx + torso_w / 2 + arm_w,
            shoulder_y + arm_h,
        )

        left_leg = self._rect(
            cx - leg_gap / 2 - leg_w,
            hip_y,
            cx - leg_gap / 2,
            min(y2, hip_y + leg_h),
        )
        right_leg = self._rect(
            cx + leg_gap / 2,
            hip_y,
            cx + leg_gap / 2 + leg_w,
            min(y2, hip_y + leg_h),
        )

        return BodyRegions(
            head=head,
            torso=torso,
            left_arm=left_arm,
            right_arm=right_arm,
            left_leg=left_leg,
            right_leg=right_leg,
        ).as_dict()

    @staticmethod
    def _rect(x1: float, y1: float, x2: float, y2: float) -> Polygon:
        return [(x1, y1), (x2, y1), (x2, y2), (x1, y2)]
