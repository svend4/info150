from triage4.core.models import CasualtyNode


class TacticalMarkerBuilder:
    def build_marker(self, node: CasualtyNode) -> dict:
        return {
            "id": node.id,
            "label": f"{node.id}:{node.triage_priority}",
            "x": node.location.x,
            "y": node.location.y,
            "confidence": node.confidence,
        }
