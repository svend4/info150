from triage4.core.models import CasualtyNode


class TacticalMapProjector:
    def project(self, casualties: list[CasualtyNode]) -> dict:
        return {
            "casualties": [
                {
                    "id": c.id,
                    "x": c.location.x,
                    "y": c.location.y,
                    "priority": c.triage_priority,
                    "confidence": c.confidence,
                }
                for c in casualties
            ]
        }
