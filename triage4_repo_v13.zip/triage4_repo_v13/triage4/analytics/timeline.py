from __future__ import annotations
from typing import Any
def world_state_timeline(records: list[dict[str, Any]]) -> dict[str, Any]:
    pts = []
    for r in reversed(records):
        payload = r.get('payload', {}) or {}; summary = payload.get('summary', {}) or {}
        pts.append({'id': r.get('id'), 'created_at': r.get('created_at'), 'casualty_count': summary.get('casualty_count', 0), 'immediate_count': summary.get('immediate_count', 0), 'avg_confidence': summary.get('avg_confidence', 0), 'avg_deterioration_risk': summary.get('avg_deterioration_risk', 0)})
    return {'points': pts, 'count': len(pts)}

def casualty_timeline(history: list[dict[str, Any]]) -> dict[str, Any]:
    pts = []
    for r in reversed(history):
        payload = r.get('payload', {}) or {}
        pts.append({'id': r.get('id'), 'created_at': r.get('created_at'), 'priority': payload.get('triage_priority', 'unknown'), 'confidence': payload.get('confidence', 0), 'deterioration_risk': payload.get('deterioration_risk', 0)})
    return {'points': pts, 'count': len(pts)}
