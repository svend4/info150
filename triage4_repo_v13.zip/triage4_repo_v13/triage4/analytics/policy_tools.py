from __future__ import annotations
from triage4.analytics.diffing import diff_payloads
REQUIRED_ROLES = ['viewer', 'analyst', 'operator', 'admin']
def validate_policy_profile(payload: dict) -> dict:
    errors, warnings = [], []
    role_actions = (payload or {}).get('role_actions')
    if not isinstance(role_actions, dict):
        return {'valid': False, 'errors': ['role_actions must be a dict'], 'warnings': warnings}
    for role in REQUIRED_ROLES:
        if role not in role_actions: errors.append(f'missing role: {role}')
        elif not isinstance(role_actions.get(role), list): errors.append(f'role_actions[{role}] must be a list')
    extras = sorted(set(role_actions.keys()) - set(REQUIRED_ROLES))
    if extras: warnings.append(f'extra roles: {", ".join(extras)}')
    return {'valid': not errors, 'errors': errors, 'warnings': warnings}
def diff_policy_profiles(left: dict, right: dict) -> dict: return diff_payloads(left or {}, right or {})
