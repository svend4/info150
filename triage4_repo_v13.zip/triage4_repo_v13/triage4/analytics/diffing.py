from __future__ import annotations

from typing import Any


def _path_join(base: str, part: str) -> str:
    return f"{base}.{part}" if base else part


def deep_diff(left: Any, right: Any, path: str = '') -> list[dict[str, Any]]:
    changes: list[dict[str, Any]] = []
    if isinstance(left, dict) and isinstance(right, dict):
        keys = sorted(set(left.keys()) | set(right.keys()))
        for key in keys:
            if key not in left:
                changes.append({'path': _path_join(path, str(key)), 'kind': 'added', 'left': None, 'right': right[key]})
            elif key not in right:
                changes.append({'path': _path_join(path, str(key)), 'kind': 'removed', 'left': left[key], 'right': None})
            else:
                changes.extend(deep_diff(left[key], right[key], _path_join(path, str(key))))
        return changes
    if isinstance(left, list) and isinstance(right, list):
        max_len = max(len(left), len(right))
        for i in range(max_len):
            p = f"{path}[{i}]"
            if i >= len(left):
                changes.append({'path': p, 'kind': 'added', 'left': None, 'right': right[i]})
            elif i >= len(right):
                changes.append({'path': p, 'kind': 'removed', 'left': left[i], 'right': None})
            else:
                changes.extend(deep_diff(left[i], right[i], p))
        return changes
    if left != right:
        changes.append({'path': path or '$', 'kind': 'changed', 'left': left, 'right': right})
    return changes


def diff_payloads(left: dict[str, Any], right: dict[str, Any], left_id: str | int | None = None, right_id: str | int | None = None) -> dict[str, Any]:
    changes = deep_diff(left, right)
    return {
        'left_id': left_id,
        'right_id': right_id,
        'change_count': len(changes),
        'changes': changes,
    }
