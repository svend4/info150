from __future__ import annotations

from typing import Any


def compare_world_states(left: dict[str, Any], right: dict[str, Any]) -> dict[str, Any]:
    ls = left.get('summary', {})
    rs = right.get('summary', {})
    la = left.get('analytics', {})
    ra = right.get('analytics', {})

    def delta(key: str) -> float:
        return round(float(rs.get(key, 0)) - float(ls.get(key, 0)), 3)

    return {
        'left': {
            'scenario': left.get('scenario', {}),
            'summary': ls,
        },
        'right': {
            'scenario': right.get('scenario', {}),
            'summary': rs,
        },
        'delta': {
            'casualty_count': delta('casualty_count'),
            'immediate_count': delta('immediate_count'),
            'delayed_count': delta('delayed_count'),
            'minimal_count': delta('minimal_count'),
            'avg_deterioration_risk': delta('avg_deterioration_risk'),
            'avg_confidence': delta('avg_confidence'),
            'revisit_count': delta('revisit_count'),
        },
        'analytics': {
            'left_priority_histogram': la.get('priority_histogram', {}),
            'right_priority_histogram': ra.get('priority_histogram', {}),
            'left_risk_bands': la.get('risk_bands', {}),
            'right_risk_bands': ra.get('risk_bands', {}),
        },
    }
