from __future__ import annotations

from pathlib import Path
from typing import Any

from triage4.storage.sqlite_store import SQLiteStore


class RestoreHistoryRepository:
    def __init__(self, db_path: str | Path | None = None) -> None:
        self.store = SQLiteStore(db_path)

    def save(self, token: str, action: str, target_type: str, target_id: str, before_payload: dict[str, Any], after_payload: dict[str, Any], undo_payload: dict[str, Any]) -> dict[str, Any]:
        return self.store.save_restore_history(token, action, target_type, target_id, before_payload, after_payload, undo_payload)

    def list(self, token: str | None = None, limit: int = 50) -> list[dict[str, Any]]:
        return self.store.list_restore_history(token=token, limit=limit)

    def load(self, restore_id: int) -> dict[str, Any]:
        return self.store.load_restore_history_item(restore_id)

    def mark_undone(self, restore_id: int) -> dict[str, Any]:
        return self.store.mark_restore_undone(restore_id)
