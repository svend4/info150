from __future__ import annotations

from pathlib import Path
from typing import Any

from triage4.storage.sqlite_store import SQLiteStore
from triage4.repositories.baseline_run_repository import BaselineRunRepository


class CompareBaselineRepository:
    def __init__(self, db_path: str | Path | None = None) -> None:
        self.store = SQLiteStore(db_path)
        self.runs = BaselineRunRepository()

    def save(self, baseline_id: str, left_scenario: str, right_scenario: str, payload: dict[str, Any]) -> dict[str, Any]:
        return self.store.save_compare_baseline(baseline_id, left_scenario, right_scenario, payload)

    def list(self) -> list[dict[str, Any]]:
        return self.store.list_compare_baselines()

    def load(self, baseline_id: str) -> dict[str, Any]:
        return self.store.load_compare_baseline(baseline_id)


    def record_run(self, baseline_id: str, left: str, right: str, payload: dict[str, Any]) -> dict[str, Any]:
        return self.runs.save(baseline_id, left, right, payload)

    def history(self, baseline_id: str) -> list[dict[str, Any]]:
        return self.runs.list(baseline_id)

    def trend(self, baseline_id: str) -> dict[str, Any]:
        return self.runs.trend(baseline_id)
