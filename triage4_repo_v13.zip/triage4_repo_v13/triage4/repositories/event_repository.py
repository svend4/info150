from __future__ import annotations

from pathlib import Path
from typing import Any

from triage4.repositories.audit_repository import AuditRepository
from triage4.repositories.job_repository import JobRepository


class EventRepository:
    def __init__(self, db_path: str | Path | None = None) -> None:
        self.audit = AuditRepository(db_path)
        self.jobs = JobRepository(db_path)

    def feed(self, limit: int = 50) -> list[dict[str, Any]]:
        items: list[dict[str, Any]] = []
        for row in self.audit.list(limit=limit):
            items.append({
                'id': f"audit:{row['id']}",
                'kind': 'audit',
                'action': row['action'],
                'title': row['action'],
                'created_at': row['created_at'],
                'payload': row,
            })
        for row in self.jobs.list(limit=limit):
            items.append({
                'id': f"job:{row['id']}",
                'kind': 'job',
                'action': row['kind'],
                'title': f"{row['kind']}:{row['status']}",
                'created_at': row['updated_at'] or row['created_at'],
                'payload': row,
            })
        items.sort(key=lambda x: (x['created_at'], x['id']), reverse=True)
        return items[:limit]
