
from __future__ import annotations

from pathlib import Path
from typing import Any

from triage4.storage.sqlite_store import SQLiteStore


class CompareHistoryRepository:
    def __init__(self, db_path: str | Path | None = None) -> None:
        self.store = SQLiteStore(db_path)

    def save(self, left_scenario: str, right_scenario: str, payload: dict[str, Any]) -> dict[str, Any]:
        return self.store.save_compare_history(left_scenario, right_scenario, payload)

    def list(self, limit: int = 50) -> list[dict[str, Any]]:
        return self.store.list_compare_history(limit=limit)

    def load(self, compare_id: int) -> dict[str, Any]:
        return self.store.load_compare_history(compare_id)
