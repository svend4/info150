from __future__ import annotations

from pathlib import Path
from typing import Any

from triage4.storage.sqlite_store import SQLiteStore


class UserRepository:
    def __init__(self, db_path: str | Path | None = None) -> None:
        self.store = SQLiteStore(db_path)

    def save(self, user_id: str, role: str, display_name: str = '', payload: dict[str, Any] | None = None) -> dict[str, Any]:
        return self.store.save_user_profile(user_id, role, display_name, payload)

    def load(self, user_id: str, include_deleted: bool = True) -> dict[str, Any]:
        return self.store.load_user_profile(user_id, include_deleted=include_deleted)

    def list(self, include_deleted: bool = False) -> list[dict[str, Any]]:
        return self.store.list_user_profiles(include_deleted=include_deleted)

    def soft_delete(self, user_id: str) -> bool:
        return self.store.soft_delete_user(user_id)

    def restore(self, user_id: str) -> bool:
        return self.store.restore_user(user_id)
