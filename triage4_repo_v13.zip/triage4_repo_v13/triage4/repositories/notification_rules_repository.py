from __future__ import annotations
import json
from pathlib import Path
from typing import Any
class NotificationRulesRepository:
    def __init__(self, root_path: str | Path | None = None) -> None:
        self.base = Path(root_path) if root_path else Path(__file__).resolve().parents[2] / 'data' / 'notification_rules'
        self.base.mkdir(parents=True, exist_ok=True)
    def _path(self, token: str) -> Path:
        return self.base / f'{token}.json'
    def defaults(self) -> dict[str, Any]:
        return {'priority_threshold': 'all', 'include_kinds': ['audit', 'job'], 'include_actions': [], 'only_unread': False}
    def load(self, token: str) -> dict[str, Any]:
        path = self._path(token)
        if not path.exists():
            return {'token': token, 'payload': self.defaults()}
        return {'token': token, 'payload': json.loads(path.read_text())}
    def save(self, token: str, payload: dict[str, Any]) -> dict[str, Any]:
        body = {**self.defaults(), **(payload or {})}
        self._path(token).write_text(json.dumps(body, indent=2))
        return {'token': token, 'payload': body}
