from __future__ import annotations

from pathlib import Path
from typing import Any

from triage4.storage.sqlite_store import SQLiteStore


class SessionRepository:
    def __init__(self, db_path: str | Path | None = None) -> None:
        self.store = SQLiteStore(db_path)

    def create(self, user_id: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        return self.store.create_session(user_id, payload)

    def load(self, token: str) -> dict[str, Any]:
        return self.store.load_session(token)

    def update(self, token: str, payload: dict[str, Any]) -> dict[str, Any]:
        return self.store.update_session(token, payload)

    def list(self) -> list[dict[str, Any]]:
        return self.store.list_sessions()
