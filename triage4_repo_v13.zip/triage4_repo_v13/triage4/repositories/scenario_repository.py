from __future__ import annotations

from pathlib import Path
from typing import Any

from triage4.storage.sqlite_store import SQLiteStore


class ScenarioRepository:
    def __init__(self, db_path: str | Path | None = None) -> None:
        self.store = SQLiteStore(db_path)

    def list(self, include_deleted: bool = False) -> list[dict[str, Any]]:
        return self.store.list_scenarios(include_deleted=include_deleted)

    def load(self, scenario_id: str, include_deleted: bool = True) -> dict[str, Any]:
        return self.store.load_scenario(scenario_id, include_deleted=include_deleted)

    def save(self, payload: dict[str, Any], active: bool = False, note: str = '') -> dict[str, Any]:
        return self.store.upsert_scenario(payload, active=active, note=note)

    def delete(self, scenario_id: str) -> bool:
        return self.store.delete_scenario(scenario_id)

    def restore(self, scenario_id: str) -> bool:
        return self.store.restore_scenario(scenario_id)

    def activate(self, scenario_id: str) -> dict[str, Any]:
        return self.store.set_active_scenario(scenario_id)

    def active_id(self) -> str | None:
        return self.store.get_active_scenario_id()

    def list_revisions(self, scenario_id: str, limit: int = 50) -> list[dict[str, Any]]:
        return self.store.list_scenario_revisions(scenario_id, limit)

    def load_revision(self, scenario_id: str, revision_id: int) -> dict[str, Any]:
        return self.store.load_scenario_revision(scenario_id, revision_id)
