from __future__ import annotations
import json, secrets
from pathlib import Path
from typing import Any
class DigestPresetRepository:
    def __init__(self, root_path: str | Path | None = None) -> None:
        self.base = Path(root_path) if root_path else Path(__file__).resolve().parents[2] / 'data' / 'digest_presets'
        self.base.mkdir(parents=True, exist_ok=True)
    def _path(self, token: str, preset_id: str) -> Path:
        return self.base / f"{token.replace('/', '_')}__{preset_id}.json"
    def save(self, token: str, name: str, payload: dict[str, Any]) -> dict[str, Any]:
        preset_id = secrets.token_hex(4)
        body = {'id': preset_id, 'token': token, 'name': name, 'payload': payload or {}}
        self._path(token, preset_id).write_text(json.dumps(body, indent=2))
        return body
    def list(self, token: str) -> list[dict[str, Any]]:
        safe = token.replace('/', '_')
        return [json.loads(p.read_text()) for p in sorted(self.base.glob(f'{safe}__*.json'))]
    def load(self, token: str, preset_id: str) -> dict[str, Any]:
        p = self._path(token, preset_id)
        return json.loads(p.read_text()) if p.exists() else {}
