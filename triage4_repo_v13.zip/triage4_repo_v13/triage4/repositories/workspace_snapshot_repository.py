from __future__ import annotations

from pathlib import Path
from typing import Any

from triage4.analytics.diffing import diff_payloads
from triage4.storage.sqlite_store import SQLiteStore


class WorkspaceSnapshotRepository:
    def __init__(self, db_path: str | Path | None = None) -> None:
        self.store = SQLiteStore(db_path)

    def save(self, token: str, name: str, payload: dict[str, Any]) -> dict[str, Any]:
        return self.store.save_workspace_snapshot(token, name, payload)

    def list(self, token: str, limit: int = 50) -> list[dict[str, Any]]:
        return self.store.list_workspace_snapshots(token, limit=limit)

    def load(self, snapshot_id: int, token: str | None = None) -> dict[str, Any]:
        return self.store.load_workspace_snapshot(snapshot_id, token=token)

    def diff(self, left_snapshot_id: int, right_snapshot_id: int, token: str | None = None) -> dict[str, Any]:
        left = self.load(left_snapshot_id, token=token)
        right = self.load(right_snapshot_id, token=token)
        if not left or not right:
            return {}
        return diff_payloads(left.get('payload', {}), right.get('payload', {}), left_id=left_snapshot_id, right_id=right_snapshot_id)
