from __future__ import annotations
import json
from pathlib import Path
from typing import Any
class BaselineRunRepository:
    def __init__(self, root_path: str | Path | None = None) -> None:
        self.path = Path(root_path) if root_path else Path(__file__).resolve().parents[2] / 'data' / 'baseline_runs.json'
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists(): self.path.write_text('[]')
    def _rows(self) -> list[dict[str, Any]]: return json.loads(self.path.read_text())
    def _save(self, rows: list[dict[str, Any]]) -> None: self.path.write_text(json.dumps(rows, indent=2))
    def save(self, baseline_id: str, left: str, right: str, payload: dict[str, Any]) -> dict[str, Any]:
        rows = self._rows(); item = {'id': len(rows)+1, 'baseline_id': baseline_id, 'left_scenario': left, 'right_scenario': right, 'payload': payload}; rows.append(item); self._save(rows); return item
    def list(self, baseline_id: str) -> list[dict[str, Any]]:
        rows = [r for r in self._rows() if r.get('baseline_id') == baseline_id]; rows.sort(key=lambda x: x['id'], reverse=True); return rows
    def trend(self, baseline_id: str) -> dict[str, Any]:
        rows = self.list(baseline_id); keys = set();
        for r in rows: keys.update((r.get('payload', {}).get('delta') or {}).keys())
        avg = {}
        for k in keys:
            vals = []
            for r in rows:
                try: vals.append(float((r.get('payload', {}).get('delta') or {}).get(k, 0)))
                except Exception: pass
            if vals: avg[k] = round(sum(vals)/len(vals), 3)
        return {'baseline_id': baseline_id, 'runs': len(rows), 'avg_delta': avg, 'series': [{'id': r['id'], 'delta': r.get('payload', {}).get('delta', {})} for r in reversed(rows)]}
