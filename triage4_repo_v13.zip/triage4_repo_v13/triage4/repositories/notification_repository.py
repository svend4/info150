from __future__ import annotations

from pathlib import Path
from typing import Any

from triage4.repositories.event_repository import EventRepository
from triage4.storage.sqlite_store import SQLiteStore


class NotificationRepository:
    def __init__(self, db_path: str | Path | None = None) -> None:
        self.store = SQLiteStore(db_path)
        self.events = EventRepository(db_path)

    def subscription(self, token: str) -> dict[str, Any]:
        return self.store.load_notification_subscription(token)

    def save_subscription(self, token: str, payload: dict[str, Any]) -> dict[str, Any]:
        body = {
            'kinds': payload.get('kinds', ['audit', 'job']),
            'actions': payload.get('actions', []),
            'muted': bool(payload.get('muted', False)),
            'pause_until': payload.get('pause_until'),
            'digest_mode': payload.get('digest_mode', 'realtime'),
            'rules': payload.get('rules', {}),
        }
        return self.store.save_notification_subscription(token, body)

    def feed(self, token: str, limit: int = 50, only_unread: bool = False) -> list[dict[str, Any]]:
        sub = self.subscription(token).get('payload', {})
        allowed_kinds = set(sub.get('kinds', ['audit', 'job']))
        allowed_actions = set(sub.get('actions', []))
        rules = sub.get('rules', {}) or {}
        read_ids = self.store.list_notification_reads(token)
        if sub.get('muted'):
            return []
        pause_until = sub.get('pause_until')
        if pause_until:
            from datetime import datetime, timezone
            try:
                pause_dt = datetime.fromisoformat(str(pause_until))
                if pause_dt.tzinfo is None:
                    pause_dt = pause_dt.replace(tzinfo=timezone.utc)
                if pause_dt > datetime.now(timezone.utc):
                    return []
            except Exception:
                pass
        items = []
        for item in self.events.feed(limit=limit * 2):
            if allowed_kinds and item.get('kind') not in allowed_kinds:
                continue
            if allowed_actions and item.get('kind') == 'audit':
                action = item.get('payload', {}).get('action')
                if action not in allowed_actions:
                    continue
            if rules.get('include_kinds') and item.get('kind') not in set(rules.get('include_kinds') or []):
                continue
            unread = item['id'] not in read_ids
            if rules.get('only_unread') and not unread:
                continue
            if only_unread and not unread:
                continue
            items.append({**item, 'unread': unread})
            if len(items) >= limit:
                break
        return items

    def mark_read(self, token: str, event_id: str) -> dict[str, Any]:
        return self.store.mark_notification_read(token, event_id)

    def unread_count(self, token: str) -> dict[str, Any]:
        items = self.feed(token, limit=500, only_unread=True)
        return {'token': token, 'unread': len(items)}
