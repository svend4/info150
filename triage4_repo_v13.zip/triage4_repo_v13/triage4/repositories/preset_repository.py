from __future__ import annotations

from pathlib import Path
from typing import Any

from triage4.storage.sqlite_store import SQLiteStore


class PresetRepository:
    def __init__(self, db_path: str | Path | None = None) -> None:
        self.store = SQLiteStore(db_path)

    def save(self, token: str, name: str, payload: dict[str, Any]) -> dict[str, Any]:
        return self.store.save_dashboard_preset(token, name, payload)

    def list(self, token: str) -> list[dict[str, Any]]:
        return self.store.list_dashboard_presets(token)

    def load(self, token: str, preset_id: int) -> dict[str, Any]:
        return self.store.load_dashboard_preset(token, preset_id)
