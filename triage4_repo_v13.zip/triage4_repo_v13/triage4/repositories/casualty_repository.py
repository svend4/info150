from __future__ import annotations

from pathlib import Path
from typing import Any

from triage4.storage.sqlite_store import SQLiteStore


class CasualtyRepository:
    def __init__(self, db_path: str | Path | None = None) -> None:
        self.store = SQLiteStore(db_path)

    def add(self, scenario_id: str | None, casualty_id: str, payload: dict[str, Any]) -> int:
        return self.store.add_casualty_history(scenario_id, casualty_id, payload)

    def list_history(self, casualty_id: str, scenario_id: str | None = None, limit: int = 50) -> list[dict[str, Any]]:
        return self.store.list_casualty_history(casualty_id=casualty_id, scenario_id=scenario_id, limit=limit)

    def summary(self, scenario_id: str | None = None) -> dict[str, Any]:
        return self.store.casualty_history_summary(scenario_id=scenario_id)
