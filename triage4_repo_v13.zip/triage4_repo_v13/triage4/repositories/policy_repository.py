from __future__ import annotations

from pathlib import Path
from typing import Any

from triage4.storage.sqlite_store import SQLiteStore


class PolicyRepository:
    def __init__(self, db_path: str | Path | None = None) -> None:
        self.store = SQLiteStore(db_path)

    def save(self, profile_id: str, payload: dict[str, Any], activate: bool = False) -> dict[str, Any]:
        return self.store.save_policy_profile(profile_id, payload, activate=activate)

    def list(self) -> list[dict[str, Any]]:
        return self.store.list_policy_profiles()

    def load(self, profile_id: str) -> dict[str, Any]:
        return self.store.load_policy_profile(profile_id)

    def active(self) -> dict[str, Any]:
        return self.store.active_policy_profile()

    def activate(self, profile_id: str) -> dict[str, Any]:
        return self.store.activate_policy_profile(profile_id)
