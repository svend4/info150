
from __future__ import annotations

from pathlib import Path
from typing import Any

from triage4.storage.sqlite_store import SQLiteStore


class AuditRepository:
    def __init__(self, db_path: str | Path | None = None) -> None:
        self.store = SQLiteStore(db_path)

    def add(self, action: str, actor_user_id: str = '', actor_role: str = '', target_type: str = '', target_id: str = '', payload: dict[str, Any] | None = None) -> dict[str, Any]:
        return self.store.add_audit_entry(action, actor_user_id, actor_role, target_type, target_id, payload)

    def list(self, limit: int = 100, action: str | None = None) -> list[dict[str, Any]]:
        return self.store.list_audit_entries(limit=limit, action=action)

    def load(self, audit_id: int) -> dict[str, Any]:
        return self.store.load_audit_entry(audit_id)
