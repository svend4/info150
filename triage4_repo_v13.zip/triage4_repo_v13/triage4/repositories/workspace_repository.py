from __future__ import annotations

from pathlib import Path
from typing import Any

from triage4.storage.sqlite_store import SQLiteStore


class WorkspaceRepository:
    def __init__(self, db_path: str | Path | None = None) -> None:
        self.store = SQLiteStore(db_path)

    def save(self, token: str, payload: dict[str, Any]) -> dict[str, Any]:
        return self.store.save_workspace(token, payload)

    def load(self, token: str) -> dict[str, Any]:
        return self.store.load_workspace(token)
