from __future__ import annotations

from pathlib import Path
from typing import Any

from triage4.storage.sqlite_store import SQLiteStore


class JobRepository:
    def __init__(self, db_path: str | Path | None = None) -> None:
        self.store = SQLiteStore(db_path)

    def create(self, kind: str, payload: dict[str, Any]) -> dict[str, Any]:
        return self.store.create_job(kind, payload)

    def update(self, job_id: str, status: str, result: dict[str, Any] | None = None) -> dict[str, Any]:
        return self.store.update_job(job_id, status, result)

    def load(self, job_id: str) -> dict[str, Any]:
        return self.store.load_job(job_id)

    def list(self, limit: int = 50) -> list[dict[str, Any]]:
        return self.store.list_jobs(limit=limit)

    def queue_stats(self) -> dict[str, Any]:
        return self.store.job_queue_stats()


    def cancel(self, job_id: str) -> dict[str, Any]:
        current = self.load(job_id)
        if not current:
            return {}
        if current.get('status') in {'completed', 'failed', 'canceled'}:
            return current
        return self.update(job_id, 'canceled', {'message': 'job canceled'})

    def retry(self, job_id: str) -> dict[str, Any]:
        current = self.load(job_id)
        if not current:
            return {}
        payload = {**(current.get('payload') or {}), 'retry_of': job_id}
        return self.create(current.get('kind', 'retry_job'), payload)
