from __future__ import annotations

from pathlib import Path
from typing import Any

from triage4.storage.sqlite_store import SQLiteStore


class WorldStateRepository:
    def __init__(self, db_path: str | Path | None = None) -> None:
        self.store = SQLiteStore(db_path)

    def add(self, scenario_id: str | None, payload: dict[str, Any]) -> int:
        return self.store.add_world_state(scenario_id, payload)

    def list(self, limit: int = 50) -> list[dict[str, Any]]:
        return self.store.list_world_states(limit=limit)

    def load(self, record_id: int) -> dict[str, Any]:
        return self.store.load_world_state(record_id)

    def latest(self) -> dict[str, Any]:
        return self.store.latest_world_state()
