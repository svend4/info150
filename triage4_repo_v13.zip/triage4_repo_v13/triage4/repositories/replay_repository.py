from __future__ import annotations

from pathlib import Path
from typing import Any

from triage4.storage.sqlite_store import SQLiteStore


class ReplayRepository:
    def __init__(self, db_path: str | Path | None = None) -> None:
        self.store = SQLiteStore(db_path)

    def save(self, session_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        return self.store.save_replay_session(session_id, payload)

    def load(self, session_id: str) -> dict[str, Any]:
        return self.store.load_replay_session(session_id)

    def list(self) -> list[dict[str, Any]]:
        return self.store.list_replay_sessions()
