from __future__ import annotations

from triage4.core.models import CasualtyNode


class AssignmentEngine:
    def plan(self, casualties: list[CasualtyNode]) -> dict:
        ordered = sorted(
            casualties,
            key=lambda c: (
                0 if c.triage_priority == "immediate" else 1 if c.triage_priority == "delayed" else 2,
                -c.confidence,
            ),
        )

        assignments = []
        revisit_queue = []

        medic_slots = ["medic_1", "quadruped_1", "uav_reinspect_1"]

        for idx, casualty in enumerate(ordered):
            asset = medic_slots[min(idx, len(medic_slots) - 1)]

            if casualty.triage_priority == "immediate":
                assignments.append(
                    {
                        "asset": asset,
                        "casualty_id": casualty.id,
                        "action": "urgent_assess_and_handoff",
                        "priority": casualty.triage_priority,
                    }
                )
                if casualty.confidence < 0.80:
                    revisit_queue.append(
                        {
                            "casualty_id": casualty.id,
                            "reason": "high urgency but confidence not yet strong",
                        }
                    )

            elif casualty.triage_priority == "delayed":
                assignments.append(
                    {
                        "asset": "uav_reinspect_1",
                        "casualty_id": casualty.id,
                        "action": "schedule_revisit",
                        "priority": casualty.triage_priority,
                    }
                )
                revisit_queue.append(
                    {
                        "casualty_id": casualty.id,
                        "reason": "delayed priority requires secondary confirmation",
                    }
                )

        return {
            "assignments": assignments,
            "revisit_queue": revisit_queue,
        }
