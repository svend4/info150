from __future__ import annotations


class DeteriorationModel:
    def estimate(
        self,
        chest_motion_score: float,
        perfusion_drop_score: float,
        hypothesis_count: int,
    ) -> float:
        risk = 0.0

        if chest_motion_score < 0.10:
            risk += 0.35
        elif chest_motion_score < 0.18:
            risk += 0.18

        if perfusion_drop_score > 0.80:
            risk += 0.35
        elif perfusion_drop_score > 0.65:
            risk += 0.20

        risk += min(0.20, hypothesis_count * 0.06)

        return round(min(risk, 1.0), 3)
