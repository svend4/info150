from __future__ import annotations


class RevisitLogic:
    def should_revisit(
        self,
        priority: str,
        confidence: float,
        deterioration_risk: float,
    ) -> bool:
        if priority == "immediate" and confidence < 0.85:
            return True
        if deterioration_risk > 0.55:
            return True
        if priority == "delayed" and confidence < 0.50:
            return True
        return False
