from __future__ import annotations

from triage4.core.models import StateHypothesis


class TemporalPriorityEngine:
    def infer(
        self,
        hypotheses: list[StateHypothesis],
        chest_motion_score: float,
        perfusion_drop_score: float,
    ) -> tuple[str, float]:
        score = 0.0

        for hyp in hypotheses:
            if hyp.name == "respiratory_distress":
                score += 0.35
            elif hyp.name == "hemorrhage_risk":
                score += 0.40
            elif hyp.name == "shock_risk":
                score += 0.25
            elif hyp.name == "major_external_wound":
                score += 0.20

        if chest_motion_score < 0.08:
            score += 0.20
        elif chest_motion_score < 0.15:
            score += 0.10

        if perfusion_drop_score > 0.80:
            score += 0.20
        elif perfusion_drop_score > 0.65:
            score += 0.10

        if score >= 0.75:
            return "immediate", round(min(score, 1.0), 3)
        if score >= 0.35:
            return "delayed", round(min(score, 1.0), 3)
        return "minimal", round(min(score, 1.0), 3)
