from __future__ import annotations

from triage4.core.models import CasualtyNode, StateHypothesis


class BodyStateGraphBuilder:
    def build(
        self,
        casualty: CasualtyNode,
        hypotheses: list[StateHypothesis],
    ) -> dict:
        nodes = []
        edges = []

        nodes.append({"id": casualty.id, "kind": "casualty", "label": casualty.id})

        for region in casualty.body_regions:
            rid = f"{casualty.id}:region:{region.name}"
            nodes.append({"id": rid, "kind": "body_region", "label": region.name})
            edges.append((casualty.id, "has_region", rid))

        for token in casualty.evidence_tokens:
            eid = f"{casualty.id}:evidence:{token.name}"
            nodes.append({"id": eid, "kind": "evidence", "label": token.name, "score": token.score})
            edges.append((casualty.id, "has_evidence", eid))

        for wound in casualty.wound_candidates:
            wid = f"{casualty.id}:wound:{wound.region_name}"
            nodes.append({"id": wid, "kind": "wound", "label": wound.region_name, "score": wound.score})
            edges.append((casualty.id, "has_wound", wid))
            edges.append((wid, "located_in", f"{casualty.id}:region:{wound.region_name}"))

        for hyp in hypotheses:
            hid = f"{casualty.id}:hyp:{hyp.name}"
            nodes.append({"id": hid, "kind": "hypothesis", "label": hyp.name, "score": hyp.score})
            edges.append((casualty.id, "has_hypothesis", hid))
            for ev in hyp.evidence:
                edges.append((f"{casualty.id}:evidence:{ev}", "supports", hid))

        return {"nodes": nodes, "edges": edges}
