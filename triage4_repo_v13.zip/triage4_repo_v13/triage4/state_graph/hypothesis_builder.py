from __future__ import annotations

from triage4.core.models import EvidenceToken, StateHypothesis, WoundCandidate


class HypothesisBuilder:
    def build(
        self,
        evidence_tokens: list[EvidenceToken],
        wound_candidates: list[WoundCandidate],
    ) -> list[StateHypothesis]:
        out: list[StateHypothesis] = []

        names = {t.name for t in evidence_tokens}
        max_wound = max((w.score for w in wound_candidates), default=0.0)

        if "low_chest_motion" in names:
            out.append(
                StateHypothesis(
                    name="respiratory_distress",
                    score=0.78,
                    evidence=["low_chest_motion"],
                    explanation="weak chest motion suggests respiratory compromise",
                )
            )

        if "poor_perfusion_pattern" in names and max_wound > 0.40:
            out.append(
                StateHypothesis(
                    name="hemorrhage_risk",
                    score=0.84,
                    evidence=["poor_perfusion_pattern", "wound_candidate"],
                    explanation="possible bleeding-related shock pattern",
                )
            )
        elif "poor_perfusion_pattern" in names:
            out.append(
                StateHypothesis(
                    name="shock_risk",
                    score=0.66,
                    evidence=["poor_perfusion_pattern"],
                    explanation="low-perfusion pattern without strong external wound evidence",
                )
            )

        if max_wound > 0.75:
            out.append(
                StateHypothesis(
                    name="major_external_wound",
                    score=max_wound,
                    evidence=["wound_candidate"],
                    explanation="large wound candidate visible in mapped body region",
                )
            )
        elif max_wound > 0.35:
            out.append(
                StateHypothesis(
                    name="minor_external_wound",
                    score=max_wound,
                    evidence=["wound_candidate"],
                    explanation="moderate wound candidate detected",
                )
            )

        return out
