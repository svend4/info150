from __future__ import annotations

from triage4.core.models import BodyRegion


class DynamicBodyGraphBuilder:
    def build(
        self,
        casualty_id: str,
        body_regions: list[BodyRegion],
        chest_motion_score: float,
        perfusion_drop_score: float,
    ) -> dict:
        nodes = []
        edges = []

        root_id = f"{casualty_id}:body_root"
        nodes.append(
            {
                "id": root_id,
                "kind": "body_root",
                "label": casualty_id,
                "z": 0.0,
            }
        )

        z_map = {
            "head": 1.2,
            "torso": 0.8,
            "left_arm": 0.7,
            "right_arm": 0.7,
            "left_leg": 0.2,
            "right_leg": 0.2,
        }

        for region in body_regions:
            rid = f"{casualty_id}:dyn:{region.name}"
            nodes.append(
                {
                    "id": rid,
                    "kind": "dynamic_region",
                    "label": region.name,
                    "polygon": region.polygon,
                    "z": z_map.get(region.name, 0.5),
                }
            )
            edges.append((root_id, "contains", rid))

        nodes.append(
            {
                "id": f"{casualty_id}:metric:motion",
                "kind": "metric",
                "label": "chest_motion",
                "value": chest_motion_score,
            }
        )
        nodes.append(
            {
                "id": f"{casualty_id}:metric:perfusion",
                "kind": "metric",
                "label": "perfusion_drop",
                "value": perfusion_drop_score,
            }
        )

        edges.append((root_id, "has_metric", f"{casualty_id}:metric:motion"))
        edges.append((root_id, "has_metric", f"{casualty_id}:metric:perfusion"))

        return {
            "nodes": nodes,
            "edges": edges,
            "body_energy": round((1.0 - perfusion_drop_score + chest_motion_score) / 2, 3),
        }
