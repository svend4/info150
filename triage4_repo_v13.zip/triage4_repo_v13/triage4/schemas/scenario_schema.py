from __future__ import annotations

from pydantic import BaseModel, Field, field_validator


class CasualtyScenarioModel(BaseModel):
    id: str
    x: float
    y: float
    breathing: list[float] = Field(min_length=4)
    perfusion: list[float] = Field(min_length=4)
    hint: str

    @field_validator('hint')
    @classmethod
    def validate_hint(cls, v: str) -> str:
        if v not in {'immediate', 'delayed', 'minimal'}:
            raise ValueError('hint must be immediate, delayed, or minimal')
        return v


class PlatformScenarioModel(BaseModel):
    id: str
    x: float
    y: float
    kind: str


class ScenarioPayloadModel(BaseModel):
    id: str
    name: str
    description: str = ''
    casualties: list[CasualtyScenarioModel]
    platforms: list[PlatformScenarioModel]
