from __future__ import annotations

from pydantic import BaseModel, field_validator


class UserProfileModel(BaseModel):
    user_id: str
    role: str = 'analyst'
    display_name: str = ''
    payload: dict = {}

    @field_validator('role')
    @classmethod
    def validate_role(cls, v: str) -> str:
        if v not in {'viewer', 'analyst', 'operator', 'admin'}:
            raise ValueError('role must be viewer, analyst, operator, or admin')
        return v
