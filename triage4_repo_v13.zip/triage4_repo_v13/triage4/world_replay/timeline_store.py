
from __future__ import annotations

import json
from pathlib import Path
from typing import Any


class TimelineStore:
    """Timeline store with JSON persistence for the current replay timeline."""

    def __init__(self, storage_path: str | Path | None = None) -> None:
        if storage_path is None:
            root = Path(__file__).resolve().parents[2]
            storage_path = root / "data" / "replay_sessions" / "current_replay.json"
        self.storage_path = Path(storage_path)
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        self.frames: list[dict[str, Any]] = []

    def add_frame(self, frame: dict[str, Any]) -> None:
        self.frames.append(frame)

    def extend(self, frames: list[dict[str, Any]]) -> None:
        self.frames.extend(frames)

    def as_dict(self) -> dict[str, Any]:
        return {"frames": self.frames}

    def save(self) -> dict[str, Any]:
        payload = self.as_dict()
        self.storage_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        return payload

    def load(self) -> dict[str, Any]:
        if not self.storage_path.exists():
            return {"frames": []}
        return json.loads(self.storage_path.read_text(encoding="utf-8"))
