
from __future__ import annotations

from triage4.core.models import CasualtyNode
from triage4.world_replay.session_store import ReplaySessionStore
from triage4.world_replay.timeline_store import TimelineStore


class ReplayEngine:
    def build(self, casualties: list[CasualtyNode], persist: bool = False, session_id: str | None = None) -> dict:
        frames = []

        for t in range(6):
            frame = {
                "t": t,
                "platforms": [
                    {
                        "id": "demo_uav",
                        "x": 14 + t * 9,
                        "y": 10 + t * 5,
                        "kind": "uav",
                    }
                ],
                "casualties": [
                    {
                        "id": c.id,
                        "x": c.location.x,
                        "y": c.location.y,
                        "priority": c.triage_priority,
                        "confidence": c.confidence,
                        "deterioration_risk": c.deterioration_risk,
                        "assigned_asset": c.assigned_asset,
                    }
                    for c in casualties
                ],
            }
            frames.append(frame)

        payload = {"frames": frames}
        if persist:
            store = TimelineStore()
            store.frames = []
            store.extend(frames)
            payload = store.save()
            if session_id:
                ReplaySessionStore().save_named(session_id, payload)
        return payload
