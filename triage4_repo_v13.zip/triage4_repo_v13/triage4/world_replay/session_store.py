from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from triage4.repositories.replay_repository import ReplayRepository


class ReplaySessionStore:
    """Persistent JSON + repository store for named replay sessions."""

    def __init__(self, sessions_dir: str | Path | None = None) -> None:
        if sessions_dir is None:
            root = Path(__file__).resolve().parents[2]
            sessions_dir = root / 'data' / 'replay_sessions'
        self.sessions_dir = Path(sessions_dir)
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        self.repo = ReplayRepository()

    def save_named(self, session_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        path = self.sessions_dir / f'{session_id}.json'
        path.write_text(json.dumps(payload, indent=2), encoding='utf-8')
        self.repo.save(session_id, payload)
        return payload

    def load_named(self, session_id: str) -> dict[str, Any]:
        payload = self.repo.load(session_id)
        if payload:
            return payload
        path = self.sessions_dir / f'{session_id}.json'
        if not path.exists():
            return {}
        return json.loads(path.read_text(encoding='utf-8'))

    def list_sessions(self) -> list[dict[str, Any]]:
        items = self.repo.list()
        if items:
            return items
        fallback = []
        for path in sorted(self.sessions_dir.glob('*.json')):
            payload = json.loads(path.read_text(encoding='utf-8'))
            if 'frames' in payload:
                fallback.append({'id': path.stem, 'frame_count': len(payload.get('frames', [])), 'kind': 'replay_session'})
        return fallback
