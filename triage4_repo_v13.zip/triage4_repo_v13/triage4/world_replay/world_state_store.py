from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from triage4.repositories.world_state_repository import WorldStateRepository


class WorldStateStore:
    """Persistent JSON + repository store for world-state snapshots and history."""

    def __init__(self, storage_path: str | Path | None = None) -> None:
        if storage_path is None:
            root = Path(__file__).resolve().parents[2]
            storage_path = root / "data" / "replay_sessions" / "latest_world_state.json"
        self.storage_path = Path(storage_path)
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        self.repo = WorldStateRepository()

    def save(self, payload: dict[str, Any]) -> dict[str, Any]:
        self.storage_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        scenario_id = payload.get('scenario', {}).get('id') if isinstance(payload.get('scenario'), dict) else None
        record_id = self.repo.add(scenario_id, payload)
        payload = dict(payload)
        payload['record_id'] = record_id
        return payload

    def load(self) -> dict[str, Any]:
        if not self.storage_path.exists():
            return {}
        return json.loads(self.storage_path.read_text(encoding="utf-8"))

    def history(self, limit: int = 50) -> list[dict[str, Any]]:
        return self.repo.list(limit=limit)

    def load_history_item(self, record_id: int) -> dict[str, Any]:
        return self.repo.load(record_id)

    def latest_from_history(self) -> dict[str, Any]:
        return self.repo.latest()
