from __future__ import annotations

from typing import Any

from triage4.repositories.policy_repository import PolicyRepository


ROLE_ORDER = {
    'viewer': 0,
    'analyst': 1,
    'operator': 2,
    'admin': 3,
}

DEFAULT_ROLE_ACTIONS = {
    'viewer': {
        'scenario:read', 'events:read', 'workspace:read', 'world:read', 'jobs:read', 'audit:read_basic'
    },
    'analyst': {
        'scenario:compare', 'workspace:edit', 'workspace:snapshot', 'workspace:restore',
        'presets:save', 'audit:read', 'workspace:diff', 'scenario:revision:read'
    },
    'operator': {
        'scenario:mutate', 'scenario:activate', 'jobs:queue', 'jobs:async', 'scenario:restore'
    },
    'admin': {
        'scenario:delete', 'users:mutate', 'users:delete', 'users:restore', 'workspace:admin', 'policy:read', 'policy:mutate', 'policy:activate'
    },
}


class PolicyEngine:
    def __init__(self, db_path=None) -> None:
        self.repo = PolicyRepository(db_path)
        self._ensure_default_profile()

    def _ensure_default_profile(self) -> None:
        if not self.repo.active():
            self.repo.save('default', {'role_actions': {k: sorted(v) for k, v in DEFAULT_ROLE_ACTIONS.items()}}, activate=True)

    def _role_actions(self) -> dict[str, set[str]]:
        profile = self.repo.active()
        payload = (profile or {}).get('payload', {})
        data = payload.get('role_actions') or {k: sorted(v) for k, v in DEFAULT_ROLE_ACTIONS.items()}
        return {k: set(v) for k, v in data.items()}

    def allowed_actions(self, role: str) -> set[str]:
        actions: set[str] = set()
        role_actions = self._role_actions()
        lvl = ROLE_ORDER.get(role, -1)
        for r, rv in ROLE_ORDER.items():
            if rv <= lvl:
                actions.update(role_actions.get(r, set()))
        return actions

    def can(self, role: str, action: str) -> bool:
        return action in self.allowed_actions(role)

    def require(self, role: str, action: str) -> None:
        if not self.can(role, action):
            raise PermissionError(f'requires permission {action}')
