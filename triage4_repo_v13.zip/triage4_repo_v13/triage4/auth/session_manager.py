from __future__ import annotations

from typing import Any

from triage4.repositories.session_repository import SessionRepository
from triage4.repositories.user_repository import UserRepository


ROLE_ORDER = {
    "viewer": 0,
    "analyst": 1,
    "operator": 2,
    "admin": 3,
}


class SessionManager:
    def __init__(self, db_path=None) -> None:
        self.repo = SessionRepository(db_path)
        self.users = UserRepository(db_path)

    def create_user(self, user_id: str, role: str = "analyst", display_name: str = "", payload: dict[str, Any] | None = None) -> dict[str, Any]:
        if role not in ROLE_ORDER:
            raise ValueError("invalid role")
        return self.users.save(user_id, role, display_name or user_id, payload)

    def list_users(self, include_deleted: bool = False) -> list[dict[str, Any]]:
        return self.users.list(include_deleted=include_deleted)

    def get_user(self, user_id: str, include_deleted: bool = True) -> dict[str, Any]:
        return self.users.load(user_id, include_deleted=include_deleted)

    def create(self, user_id: str) -> dict[str, Any]:
        profile = self.users.load(user_id, include_deleted=False)
        if not profile:
            existing = self.users.load(user_id, include_deleted=True)
            if existing and existing.get("deleted"):
                raise ValueError("user is deleted")
            profile = self.create_user(user_id, "analyst", user_id)
        return self.repo.create(user_id, payload={
            "filters": {"priority": "all", "scenario_id": None},
            "dashboard": {"tab": "overview"},
        })

    def resolve(self, token: str | None) -> dict[str, Any]:
        if not token:
            return {}
        return self.repo.load(token)

    def update_filters(self, token: str, filters: dict[str, Any]) -> dict[str, Any]:
        sess = self.repo.load(token)
        if not sess:
            raise KeyError(token)
        payload = dict(sess.get("payload", {}))
        payload["filters"] = filters
        return self.repo.update(token, payload)

    def require_role(self, token: str | None, minimum_role: str) -> dict[str, Any]:
        sess = self.resolve(token)
        if not sess:
            raise PermissionError("missing session")
        current = ROLE_ORDER.get(sess.get("role", "viewer"), -1)
        target = ROLE_ORDER[minimum_role]
        if current < target:
            raise PermissionError(f"requires role {minimum_role}")
        return sess

    def update_user(self, user_id: str, role: str | None = None, display_name: str | None = None, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        current = self.users.load(user_id, include_deleted=True)
        if not current:
            raise KeyError(user_id)
        return self.users.save(
            user_id,
            role or current.get("role", "analyst"),
            display_name if display_name is not None else current.get("display_name", user_id),
            payload if payload is not None else current.get("payload", {}),
        )

    def soft_delete_user(self, user_id: str) -> bool:
        return self.users.soft_delete(user_id)

    def restore_user(self, user_id: str) -> bool:
        return self.users.restore(user_id)
