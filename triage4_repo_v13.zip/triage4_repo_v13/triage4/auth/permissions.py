from __future__ import annotations

from fastapi import HTTPException

from triage4.auth.policy_engine import PolicyEngine
from triage4.auth.session_manager import SessionManager


class PermissionGuard:
    def __init__(self, db_path=None) -> None:
        self.sessions = SessionManager(db_path)
        self.policy = PolicyEngine(db_path)

    def require(self, token: str | None, minimum_role: str) -> dict:
        try:
            return self.sessions.require_role(token, minimum_role)
        except PermissionError as exc:
            raise HTTPException(status_code=403, detail=str(exc))

    def require_action(self, token: str | None, action: str) -> dict:
        sess = self.sessions.resolve(token)
        if not sess:
            raise HTTPException(status_code=403, detail='missing session')
        try:
            self.policy.require(sess.get('role', 'viewer'), action)
            return sess
        except PermissionError as exc:
            raise HTTPException(status_code=403, detail=str(exc))
