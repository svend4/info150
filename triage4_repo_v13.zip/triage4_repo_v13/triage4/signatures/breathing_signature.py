from triage4.core.models import SignalLine


class BreathingSignatureExtractor:
    def extract(self, series: list[float]) -> SignalLine:
        if not series:
            return SignalLine(name="breathing_curve", values=[], confidence=0.0)

        amplitude = max(series) - min(series)
        confidence = min(1.0, max(0.2, 0.4 + amplitude * 2.0))

        return SignalLine(
            name="breathing_curve",
            values=series,
            confidence=round(confidence, 3),
        )

    def chest_motion_score(self, series: list[float]) -> float:
        if len(series) < 2:
            return 0.0
        amplitude = max(series) - min(series)
        return round(min(1.0, max(0.0, amplitude * 2.5)), 3)
