from triage4.core.models import SignalLine


class PerfusionSignatureExtractor:
    def extract(self, series: list[float]) -> SignalLine:
        if not series:
            return SignalLine(name="perfusion_curve", values=[], confidence=0.0)

        variance = max(series) - min(series)
        confidence = min(1.0, max(0.2, 0.35 + variance * 1.5))

        return SignalLine(
            name="perfusion_curve",
            values=series,
            confidence=round(confidence, 3),
        )

    def perfusion_drop_score(self, series: list[float]) -> float:
        if not series:
            return 0.0
        low_value = 1.0 - (sum(series) / len(series))
        return round(min(1.0, max(0.0, low_value)), 3)
