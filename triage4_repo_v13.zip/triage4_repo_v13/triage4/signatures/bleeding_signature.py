from __future__ import annotations


class BleedingSignatureExtractor:
    """Simple synthetic bleeding signature for MVP v2."""

    def score(
        self,
        wound_score: float,
        perfusion_drop_score: float,
        priority_hint: str = "minimal",
    ) -> float:
        score = wound_score * 0.65 + perfusion_drop_score * 0.25
        if priority_hint == "immediate":
            score += 0.15
        elif priority_hint == "delayed":
            score += 0.05
        return round(min(max(score, 0.0), 1.0), 3)
