from __future__ import annotations


class ThermalSignatureExtractor:
    """Simple synthetic thermal anomaly model for MVP v2."""

    def score(self, priority_hint: str, wound_score: float = 0.0) -> float:
        base = {
            "immediate": 0.78,
            "delayed": 0.42,
            "minimal": 0.16,
        }.get(priority_hint, 0.2)
        return round(min(1.0, max(0.0, base + wound_score * 0.15)), 3)
