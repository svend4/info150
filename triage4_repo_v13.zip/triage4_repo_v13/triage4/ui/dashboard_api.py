from __future__ import annotations

import time
from typing import Any

from fastapi import FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from triage4.analytics.comparison import compare_world_states
from triage4.analytics.diffing import diff_payloads
from triage4.auth.permissions import PermissionGuard
from triage4.auth.policy_engine import PolicyEngine
from triage4.auth.session_manager import SessionManager
from triage4.jobs.job_manager import JobManager
from triage4.jobs.worker_process import DurableWorkerProcess
from triage4.repositories.casualty_repository import CasualtyRepository
from triage4.repositories.preset_repository import PresetRepository
from triage4.repositories.session_repository import SessionRepository
from triage4.repositories.user_repository import UserRepository
from triage4.repositories.workspace_repository import WorkspaceRepository
from triage4.repositories.audit_repository import AuditRepository
from triage4.repositories.workspace_snapshot_repository import WorkspaceSnapshotRepository
from triage4.repositories.compare_history_repository import CompareHistoryRepository
from triage4.repositories.compare_baseline_repository import CompareBaselineRepository
from triage4.repositories.event_repository import EventRepository
from triage4.repositories.notification_repository import NotificationRepository
from triage4.repositories.restore_history_repository import RestoreHistoryRepository
from triage4.repositories.policy_repository import PolicyRepository
from triage4.sim.demo_scene import (
    make_coordination_plan,
    make_demo_casualties,
    make_handoff_payload,
    make_replay_payload,
    make_world_state,
)
from triage4.sim.scenario_registry import ScenarioRegistry
from triage4.schemas.user_schema import UserProfileModel
from triage4.tactical_scene.casualty_markers import TacticalMarkerBuilder
from triage4.tactical_scene.map_projection import TacticalMapProjector
from triage4.world_replay.session_store import ReplaySessionStore
from triage4.world_replay.timeline_store import TimelineStore
from triage4.world_replay.world_state_store import WorldStateStore

app = FastAPI(title="triage4 v13 operational shell", version="1.5.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

projector = TacticalMapProjector()
marker_builder = TacticalMarkerBuilder()
scenario_registry = ScenarioRegistry()
world_state_store = WorldStateStore()
casualty_repo = CasualtyRepository()
session_manager = SessionManager()
session_repo = SessionRepository()
user_repo = UserRepository()
preset_repo = PresetRepository()
workspace_repo = WorkspaceRepository()
audit_repo = AuditRepository()
workspace_snapshot_repo = WorkspaceSnapshotRepository()
compare_history_repo = CompareHistoryRepository()
compare_baseline_repo = CompareBaselineRepository()
event_repo = EventRepository()
notification_repo = NotificationRepository()
restore_history_repo = RestoreHistoryRepository()
policy_repo = PolicyRepository()
job_manager = JobManager()
durable_worker = DurableWorkerProcess()
permission_guard = PermissionGuard()
policy_engine = PolicyEngine()


class ReplayImportRequest(BaseModel):
    session_id: str
    payload: dict


class ScenarioUpsertRequest(BaseModel):
    payload: dict


class LoginRequest(BaseModel):
    user_id: str


class FiltersRequest(BaseModel):
    filters: dict


class PresetRequest(BaseModel):
    name: str
    payload: dict


class UserRequest(BaseModel):
    user_id: str
    role: str = 'analyst'
    display_name: str = ''
    payload: dict = {}


class WorkspaceRequest(BaseModel):
    payload: dict


class LayoutRequest(BaseModel):
    layout: dict


class WorkspaceSnapshotRequest(BaseModel):
    name: str


class NotificationSubscriptionRequest(BaseModel):
    kinds: list[str] = ['audit', 'job']
    actions: list[str] = []
    muted: bool = False
    pause_until: str | None = None
    digest_mode: str = "realtime"


class PolicyProfileRequest(BaseModel):
    profile_id: str
    payload: dict


class UserUpdateRequest(BaseModel):
    role: str | None = None
    display_name: str | None = None
    payload: dict | None = None



def _session_token(x_session_token: str | None) -> str | None:
    return x_session_token


def _require_role(x_session_token: str | None, minimum_role: str) -> dict:
    return permission_guard.require(_session_token(x_session_token), minimum_role)


def _require_action(x_session_token: str | None, action: str) -> dict:
    return permission_guard.require_action(_session_token(x_session_token), action)


def _audit(action: str, session: dict | None = None, target_type: str = '', target_id: str = '', payload: dict | None = None) -> dict:
    session = session or {}
    return audit_repo.add(
        action=action,
        actor_user_id=session.get('user_id', ''),
        actor_role=session.get('role', ''),
        target_type=target_type,
        target_id=target_id,
        payload=payload or {},
    )


@app.get("/health")
def health() -> dict:
    return {"ok": True, "version": "1.5.0", "worker": job_manager.worker_status(), "durable_worker": durable_worker.status()}



@app.post("/auth/users")
def create_or_update_user(req: UserRequest, x_session_token: str | None = Header(default=None)) -> dict:
    if user_repo.list():
        sess = _require_action(x_session_token, 'users:mutate')
    else:
        sess = {'user_id': 'bootstrap', 'role': 'admin'}
    try:
        data = UserProfileModel.model_validate(req.model_dump()).model_dump()
    except Exception as e:
        raise HTTPException(status_code=422, detail=str(e))
    result = session_manager.create_user(data['user_id'], data['role'], data.get('display_name', ''), data.get('payload', {}))
    _audit('user.create', sess, 'user', data['user_id'], {'role': data['role']})
    return result


@app.put("/auth/users/{user_id}")
def update_user(user_id: str, req: UserUpdateRequest, x_session_token: str | None = Header(default=None)) -> dict:
    sess = _require_action(x_session_token, 'users:mutate')
    try:
        result = session_manager.update_user(user_id, role=req.role, display_name=req.display_name, payload=req.payload)
    except KeyError:
        raise HTTPException(status_code=404, detail="User not found")
    _audit('user.update', sess, 'user', user_id, {'role': req.role, 'display_name': req.display_name})
    return result


@app.get("/auth/users")
def list_users(include_deleted: bool = False) -> list[dict]:
    return session_manager.list_users(include_deleted=include_deleted)


@app.get("/auth/users/{user_id}")
def get_user(user_id: str, include_deleted: bool = True) -> dict:
    payload = session_manager.get_user(user_id, include_deleted=include_deleted)
    if not payload:
        raise HTTPException(status_code=404, detail="User not found")
    return payload


@app.delete("/auth/users/{user_id}")
def delete_user(user_id: str, x_session_token: str | None = Header(default=None)) -> dict:
    sess = _require_action(x_session_token, 'users:delete')
    ok = session_manager.soft_delete_user(user_id)
    if not ok:
        raise HTTPException(status_code=404, detail='User not found')
    _audit('user.soft_delete', sess, 'user', user_id, {})
    return {'ok': True, 'user_id': user_id}


@app.post("/auth/users/{user_id}/restore")
def restore_user(user_id: str, x_session_token: str | None = Header(default=None)) -> dict:
    sess = _require_action(x_session_token, 'users:restore')
    before = session_manager.get_user(user_id, include_deleted=True)
    ok = session_manager.restore_user(user_id)
    if not ok:
        raise HTTPException(status_code=404, detail='User not found or not deleted')
    after = session_manager.get_user(user_id, include_deleted=True)
    hist = restore_history_repo.save('', 'user.restore', 'user', user_id, before, after, {'mode': 'user_soft_delete'})
    _audit('user.restore', sess, 'user', user_id, {'restore_id': hist.get('id')})
    return {'ok': True, 'user_id': user_id}


@app.post("/auth/session")
def create_session(req: LoginRequest) -> dict:
    try:
        result = session_manager.create(req.user_id)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    _audit("session.create", {"user_id": result.get("user_id", req.user_id), "role": result.get("role", "")}, "session", result.get("token", ""), {"user_id": req.user_id})
    return result


@app.get("/auth/sessions")
def list_sessions() -> list[dict]:
    return session_repo.list()


@app.get("/auth/session/{token}")
def get_session(token: str) -> dict:
    sess = session_repo.load(token)
    if not sess:
        raise HTTPException(status_code=404, detail="Session not found")
    return sess


@app.put("/auth/session/{token}/filters")
def update_session_filters(token: str, req: FiltersRequest) -> dict:
    try:
        return session_manager.update_filters(token, req.filters)
    except KeyError:
        raise HTTPException(status_code=404, detail="Session not found")


@app.get("/presets")
def list_presets(x_session_token: str | None = Header(default=None)) -> list[dict]:
    token = _session_token(x_session_token)
    if not token:
        return []
    return preset_repo.list(token)


@app.post("/presets")
def save_preset(req: PresetRequest, x_session_token: str | None = Header(default=None)) -> dict:
    token = _session_token(x_session_token)
    if not token:
        raise HTTPException(status_code=400, detail="Missing X-Session-Token")
    return preset_repo.save(token, req.name, req.payload)


@app.get("/presets/{preset_id}")
def get_preset(preset_id: int, x_session_token: str | None = Header(default=None)) -> dict:
    token = _session_token(x_session_token)
    if not token:
        raise HTTPException(status_code=400, detail="Missing X-Session-Token")
    payload = preset_repo.load(token, preset_id)
    if not payload:
        raise HTTPException(status_code=404, detail="Preset not found")
    return payload


@app.get("/workspace/export")
def workspace_export(x_session_token: str | None = Header(default=None)) -> dict:
    token = _session_token(x_session_token)
    if not token:
        raise HTTPException(status_code=400, detail="Missing X-Session-Token")
    sess = session_repo.load(token)
    presets = preset_repo.list(token)
    workspace = workspace_repo.load(token)
    payload = workspace.get('payload') or {
        'layout': {'leftPanel': 340, 'tab': 'overview'},
        'filters': sess.get('payload', {}).get('filters', {}),
        'presets': presets,
    }
    return {'token': token, 'workspace': payload}


@app.post("/workspace/import")
def workspace_import(req: WorkspaceRequest, x_session_token: str | None = Header(default=None)) -> dict:
    sess = _require_action(x_session_token, "workspace:edit")
    token = _session_token(x_session_token)
    if not token:
        raise HTTPException(status_code=400, detail="Missing X-Session-Token")
    result = workspace_repo.save(token, req.payload)
    _audit("workspace.import", sess, "workspace", token, {"keys": sorted(list(req.payload.keys()))})
    return result


@app.put("/workspace/layout")
def workspace_layout(req: LayoutRequest, x_session_token: str | None = Header(default=None)) -> dict:
    sess = _require_action(x_session_token, "workspace:edit")
    token = _session_token(x_session_token)
    if not token:
        raise HTTPException(status_code=400, detail="Missing X-Session-Token")
    current = workspace_repo.load(token).get('payload', {})
    current['layout'] = req.layout
    result = workspace_repo.save(token, current)
    _audit("workspace.layout", sess, "workspace", token, {"layout": req.layout})
    return result




@app.post("/workspace/snapshot")
def workspace_snapshot(req: WorkspaceSnapshotRequest, x_session_token: str | None = Header(default=None)) -> dict:
    sess = _require_action(x_session_token, 'workspace:snapshot')
    token = _session_token(x_session_token)
    if not token:
        raise HTTPException(status_code=400, detail="Missing X-Session-Token")
    payload = workspace_repo.load(token).get('payload', {})
    result = workspace_snapshot_repo.save(token, req.name, payload)
    _audit('workspace.snapshot', sess, 'workspace_snapshot', str(result.get('id')), {'name': req.name})
    return result


@app.get("/workspace/snapshots")
def workspace_snapshots(limit: int = 20, x_session_token: str | None = Header(default=None)) -> list[dict]:
    token = _session_token(x_session_token)
    if not token:
        raise HTTPException(status_code=400, detail="Missing X-Session-Token")
    return workspace_snapshot_repo.list(token, limit=limit)


@app.post("/workspace/restore/{snapshot_id}")
def workspace_restore(snapshot_id: int, x_session_token: str | None = Header(default=None)) -> dict:
    sess = _require_action(x_session_token, 'workspace:restore')
    token = _session_token(x_session_token)
    if not token:
        raise HTTPException(status_code=400, detail="Missing X-Session-Token")
    snap = workspace_snapshot_repo.load(snapshot_id, token=token)
    if not snap:
        raise HTTPException(status_code=404, detail='Snapshot not found')
    before = workspace_repo.load(token).get('payload', {})
    result = workspace_repo.save(token, snap.get('payload', {}))
    hist = restore_history_repo.save(token, 'workspace.restore', 'workspace_snapshot', str(snapshot_id), {'payload': before}, {'payload': result.get('payload', {})}, {'mode': 'workspace_restore', 'payload': before})
    _audit('workspace.restore', sess, 'workspace_snapshot', str(snapshot_id), {'token': token, 'restore_id': hist.get('id')})
    return result


@app.get("/workspace/snapshots/diff")
def workspace_snapshot_diff(left_snapshot_id: int, right_snapshot_id: int, x_session_token: str | None = Header(default=None)) -> dict:
    token = _session_token(x_session_token)
    if not token:
        raise HTTPException(status_code=400, detail="Missing X-Session-Token")
    payload = workspace_snapshot_repo.diff(left_snapshot_id, right_snapshot_id, token=token)
    if not payload:
        raise HTTPException(status_code=404, detail='Snapshot diff source not found')
    payload['left_payload'] = workspace_snapshot_repo.load(left_snapshot_id, token=token).get('payload', {})
    payload['right_payload'] = workspace_snapshot_repo.load(right_snapshot_id, token=token).get('payload', {})
    return payload


@app.get("/scenarios")
def scenarios(include_deleted: bool = False) -> list[dict]:
    return scenario_registry.list_scenarios(include_deleted=include_deleted)


@app.get("/scenarios/current")
def current_scenario() -> dict:
    return scenario_registry.get_current()


@app.get("/scenarios/{scenario_id}")
def scenario_detail(scenario_id: str, include_deleted: bool = True) -> dict:
    try:
        return scenario_registry.load(scenario_id, include_deleted=include_deleted)
    except KeyError:
        raise HTTPException(status_code=404, detail="Scenario not found")


@app.get("/scenarios/{scenario_id}/revisions")
def scenario_revisions(scenario_id: str, limit: int = 20) -> list[dict]:
    return scenario_registry.revisions(scenario_id, limit=limit)


@app.get("/scenarios/{scenario_id}/revisions/diff")
def scenario_revision_diff(scenario_id: str, left_revision: int, right_revision: int) -> dict:
    left = scenario_registry.revision(scenario_id, left_revision)
    right = scenario_registry.revision(scenario_id, right_revision)
    if not left or not right:
        raise HTTPException(status_code=404, detail='Scenario revision not found')
    payload = diff_payloads(left.get('payload', {}), right.get('payload', {}), left_id=left_revision, right_id=right_revision)
    payload['left_payload'] = left.get('payload', {})
    payload['right_payload'] = right.get('payload', {})
    return payload


@app.get("/scenarios/{scenario_id}/revisions/{revision_id}")
def scenario_revision(scenario_id: str, revision_id: int) -> dict:
    payload = scenario_registry.revision(scenario_id, revision_id)
    if not payload:
        raise HTTPException(status_code=404, detail="Scenario revision not found")
    return payload


@app.get("/scenarios/export/{scenario_id}")
def scenario_export(scenario_id: str) -> dict:
    try:
        return scenario_registry.export(scenario_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Scenario not found")


@app.post("/scenarios/import")
def scenario_import(req: ScenarioUpsertRequest, x_session_token: str | None = Header(default=None)) -> dict:
    sess = _require_action(x_session_token, 'scenario:mutate')
    try:
        payload = scenario_registry.import_payload(req.payload)
    except Exception as e:
        raise HTTPException(status_code=422, detail=str(e))
    _audit("scenario.import", sess, "scenario", payload.get("id", ""), {"name": payload.get("name", "")})
    return {"ok": True, "scenario": payload}


@app.post("/scenarios")
def create_scenario(req: ScenarioUpsertRequest, x_session_token: str | None = Header(default=None)) -> dict:
    sess = _require_action(x_session_token, 'scenario:mutate')
    try:
        payload = scenario_registry.save(req.payload, note='create')
    except Exception as e:
        raise HTTPException(status_code=422, detail=str(e))
    _audit("scenario.create", sess, "scenario", payload.get("id", ""), {"name": payload.get("name", "")})
    return {"ok": True, "scenario": payload}


@app.put("/scenarios/{scenario_id}")
def update_scenario(scenario_id: str, req: ScenarioUpsertRequest, x_session_token: str | None = Header(default=None)) -> dict:
    sess = _require_action(x_session_token, 'scenario:mutate')
    payload = dict(req.payload)
    payload['id'] = scenario_id
    try:
        payload = scenario_registry.save(payload, note='update')
    except Exception as e:
        raise HTTPException(status_code=422, detail=str(e))
    _audit("scenario.update", sess, "scenario", scenario_id, {"name": payload.get("name", "")})
    return {"ok": True, "scenario": payload}


@app.delete("/scenarios/{scenario_id}")
def delete_scenario(scenario_id: str, x_session_token: str | None = Header(default=None)) -> dict:
    sess = _require_action(x_session_token, 'scenario:delete')
    ok = scenario_registry.delete(scenario_id)
    if not ok:
        raise HTTPException(status_code=400, detail="Scenario cannot be deleted")
    _audit("scenario.soft_delete", sess, "scenario", scenario_id, {})
    return {"ok": True, "deleted": scenario_id}


@app.post("/scenarios/{scenario_id}/restore")
def restore_scenario(scenario_id: str, x_session_token: str | None = Header(default=None)) -> dict:
    sess = _require_action(x_session_token, 'scenario:restore')
    before = scenario_registry.load(scenario_id, include_deleted=True)
    ok = scenario_registry.restore(scenario_id)
    if not ok:
        raise HTTPException(status_code=400, detail='Scenario cannot be restored')
    after = scenario_registry.load(scenario_id, include_deleted=True)
    hist = restore_history_repo.save('', 'scenario.restore', 'scenario', scenario_id, before, after, {'mode': 'scenario_soft_delete'})
    _audit('scenario.restore', sess, 'scenario', scenario_id, {'restore_id': hist.get('id')})
    return {'ok': True, 'restored': scenario_id}


@app.post("/scenarios/{scenario_id}/activate")
def activate_scenario(scenario_id: str, x_session_token: str | None = Header(default=None)) -> dict:
    sess = _require_action(x_session_token, 'scenario:activate')
    try:
        payload = scenario_registry.set_current(scenario_id)
        _audit("scenario.activate", sess, "scenario", scenario_id, {"name": payload.get("name", "")})
        return {"ok": True, "scenario": payload}
    except KeyError:
        raise HTTPException(status_code=404, detail="Scenario not found")


@app.get("/scenarios/compare")

def compare_scenarios(left: str, right: str, x_session_token: str | None = Header(default=None), save: bool = True) -> dict:
    sess = _require_action(x_session_token, 'scenario:compare') if x_session_token else {'user_id': '', 'role': 'viewer'}
    left_state = make_world_state(persist=False, scenario_id=left)
    right_state = make_world_state(persist=False, scenario_id=right)
    result = compare_world_states(left_state, right_state)
    if save:
        compare_record = compare_history_repo.save(left, right, result)
        result = {**result, 'compare_record_id': compare_record.get('id')}
    _audit('scenario.compare', sess, 'scenario_pair', f'{left}:{right}', {'left': left, 'right': right})
    return result



@app.get("/analytics/compare/history")
def compare_history(limit: int = 20) -> list[dict]:
    return compare_history_repo.list(limit=limit)


@app.get("/analytics/compare/history/{compare_id}")
def compare_history_item(compare_id: int) -> dict:
    payload = compare_history_repo.load(compare_id)
    if not payload:
        raise HTTPException(status_code=404, detail="Compare history record not found")
    return payload


@app.get("/analytics/compare/baselines")
def compare_baselines() -> list[dict]:
    return compare_baseline_repo.list()


@app.get("/analytics/compare/baselines/{baseline_id}")
def compare_baseline_item(baseline_id: str) -> dict:
    payload = compare_baseline_repo.load(baseline_id)
    if not payload:
        raise HTTPException(status_code=404, detail="Compare baseline not found")
    return payload


@app.post("/analytics/compare/baselines/{baseline_id}")
def save_compare_baseline(baseline_id: str, left: str, right: str, x_session_token: str | None = Header(default=None)) -> dict:
    sess = _require_action(x_session_token, 'scenario:compare')
    left_state = make_world_state(persist=False, scenario_id=left)
    right_state = make_world_state(persist=False, scenario_id=right)
    result = compare_world_states(left_state, right_state)
    saved = compare_baseline_repo.save(baseline_id, left, right, result)
    _audit('scenario.compare.baseline.save', sess, 'compare_baseline', baseline_id, {'left': left, 'right': right})
    return saved


@app.get("/analytics/compare/baselines/{baseline_id}/run")
def run_compare_baseline(baseline_id: str, left: str | None = None, right: str | None = None) -> dict:
    baseline = compare_baseline_repo.load(baseline_id)
    if not baseline:
        raise HTTPException(status_code=404, detail="Compare baseline not found")
    left_id = left or baseline.get('left_scenario')
    right_id = right or baseline.get('right_scenario')
    current = compare_world_states(make_world_state(persist=False, scenario_id=left_id), make_world_state(persist=False, scenario_id=right_id))
    baseline_payload = baseline.get('payload', {})
    delta_diff = {}
    for k, v in (current.get('delta') or {}).items():
        try:
            delta_diff[k] = round(float(v) - float((baseline_payload.get('delta') or {}).get(k, 0)), 3)
        except Exception:
            delta_diff[k] = v
    compare_baseline_repo.record_run(baseline_id, left_id, right_id, {'current': current, 'delta': delta_diff})
    return {'baseline': baseline, 'current': current, 'delta_vs_baseline': delta_diff}


@app.get("/events/feed")
def event_feed(limit: int = 50) -> list[dict]:
    return event_repo.feed(limit=limit)


@app.get("/notifications/subscriptions")
def notification_subscription(x_session_token: str | None = Header(default=None)) -> dict:
    token = _session_token(x_session_token)
    if not token:
        raise HTTPException(status_code=400, detail="Missing X-Session-Token")
    return notification_repo.subscription(token)


@app.post("/notifications/subscriptions")
def notification_subscription_save(req: NotificationSubscriptionRequest, x_session_token: str | None = Header(default=None)) -> dict:
    token = _session_token(x_session_token)
    sess = _require_role(x_session_token, 'viewer')
    if not token:
        raise HTTPException(status_code=400, detail="Missing X-Session-Token")
    result = notification_repo.save_subscription(token, {'kinds': req.kinds, 'actions': req.actions, 'muted': req.muted, 'pause_until': req.pause_until, 'digest_mode': req.digest_mode})
    _audit('notification.subscription.save', sess, 'session', token, result.get('payload', {}))
    return result


@app.get("/notifications/preferences")
def notification_preferences(x_session_token: str | None = Header(default=None)) -> dict:
    token = _session_token(x_session_token)
    if not token:
        raise HTTPException(status_code=400, detail="Missing X-Session-Token")
    return notification_repo.subscription(token)


@app.put("/notifications/preferences")
def notification_preferences_save(req: NotificationSubscriptionRequest, x_session_token: str | None = Header(default=None)) -> dict:
    token = _session_token(x_session_token)
    sess = _require_role(x_session_token, 'viewer')
    if not token:
        raise HTTPException(status_code=400, detail="Missing X-Session-Token")
    result = notification_repo.save_subscription(token, {'kinds': req.kinds, 'actions': req.actions, 'muted': req.muted, 'pause_until': req.pause_until, 'digest_mode': req.digest_mode})
    _audit('notification.preferences.save', sess, 'session', token, result.get('payload', {}))
    return result


@app.get("/notifications/feed")
def notifications_feed(limit: int = 50, only_unread: bool = False, x_session_token: str | None = Header(default=None)) -> list[dict]:
    token = _session_token(x_session_token)
    if not token:
        raise HTTPException(status_code=400, detail="Missing X-Session-Token")
    return notification_repo.feed(token, limit=limit, only_unread=only_unread)


@app.post("/notifications/mark_read/{event_id}")
def notifications_mark_read(event_id: str, x_session_token: str | None = Header(default=None)) -> dict:
    token = _session_token(x_session_token)
    sess = _require_role(x_session_token, 'viewer')
    if not token:
        raise HTTPException(status_code=400, detail="Missing X-Session-Token")
    result = notification_repo.mark_read(token, event_id)
    _audit('notification.mark_read', sess, 'event', event_id, {})
    return result


@app.get("/notifications/unread_count")
def notifications_unread_count(x_session_token: str | None = Header(default=None)) -> dict:
    token = _session_token(x_session_token)
    if not token:
        raise HTTPException(status_code=400, detail="Missing X-Session-Token")
    return notification_repo.unread_count(token)


@app.get("/restore/history")
def restore_history(limit: int = 50, x_session_token: str | None = Header(default=None)) -> list[dict]:
    token = _session_token(x_session_token)
    return restore_history_repo.list(token=token, limit=limit)


@app.get("/restore/preview/{restore_id}")
def restore_preview(restore_id: int, x_session_token: str | None = Header(default=None)) -> dict:
    _require_role(x_session_token, 'viewer')
    record = restore_history_repo.load(restore_id)
    if not record:
        raise HTTPException(status_code=404, detail='Restore history item not found')
    before_payload = record.get('before_payload', {})
    after_payload = record.get('after_payload', {})
    summary = {
        'before_keys': sorted(before_payload.keys()) if isinstance(before_payload, dict) else [],
        'after_keys': sorted(after_payload.keys()) if isinstance(after_payload, dict) else [],
        'changed_key_count': len(set((before_payload or {}).keys()) ^ set((after_payload or {}).keys())) if isinstance(before_payload, dict) and isinstance(after_payload, dict) else 0,
        'undo_mode': (record.get('undo_payload') or {}).get('mode'),
    }
    return {'record': record, 'summary': summary}


@app.post("/restore/undo/{restore_id}")
def restore_undo(restore_id: int, x_session_token: str | None = Header(default=None)) -> dict:
    sess = _require_role(x_session_token, 'viewer')
    record = restore_history_repo.load(restore_id)
    if not record:
        raise HTTPException(status_code=404, detail='Restore history item not found')
    if record.get('undone_at'):
        raise HTTPException(status_code=400, detail='Restore item already undone')
    undo = record.get('undo_payload', {})
    mode = undo.get('mode')
    if mode == 'workspace_restore':
        token = record.get('token')
        workspace_repo.save(token, undo.get('payload', {}))
    elif mode == 'scenario_soft_delete':
        if not scenario_registry.delete(record.get('target_id')):
            raise HTTPException(status_code=400, detail='Scenario undo failed')
    elif mode == 'user_soft_delete':
        if not session_manager.soft_delete_user(record.get('target_id')):
            raise HTTPException(status_code=400, detail='User undo failed')
    else:
        raise HTTPException(status_code=400, detail='Unsupported undo mode')
    restore_history_repo.mark_undone(restore_id)
    _audit('restore.undo', sess, record.get('target_type', ''), record.get('target_id', ''), {'restore_id': restore_id})
    return {'ok': True, 'restore_id': restore_id, 'mode': mode}


@app.get("/policy/profiles")
def policy_profiles(x_session_token: str | None = Header(default=None)) -> list[dict]:
    _require_action(x_session_token, 'policy:read')
    return policy_repo.list()


@app.get("/policy/profiles/current")
def policy_profile_current(x_session_token: str | None = Header(default=None)) -> dict:
    _require_action(x_session_token, 'policy:read')
    return policy_repo.active()


@app.post("/policy/profiles")
def policy_profile_save(req: PolicyProfileRequest, x_session_token: str | None = Header(default=None)) -> dict:
    sess = _require_action(x_session_token, 'policy:mutate')
    result = policy_repo.save(req.profile_id, req.payload, activate=False)
    _audit('policy.save', sess, 'policy_profile', req.profile_id, {})
    return result


@app.post("/policy/profiles/{profile_id}/activate")
def policy_profile_activate(profile_id: str, x_session_token: str | None = Header(default=None)) -> dict:
    sess = _require_action(x_session_token, 'policy:activate')
    payload = policy_repo.activate(profile_id)
    if not payload:
        raise HTTPException(status_code=404, detail='Policy profile not found')
    _audit('policy.activate', sess, 'policy_profile', profile_id, {})
    return payload


@app.get("/audit")
def audit_entries(limit: int = 50, action: str | None = None, x_session_token: str | None = Header(default=None)) -> list[dict]:
    _require_action(x_session_token, 'audit:read')
    return audit_repo.list(limit=limit, action=action)


@app.get("/audit/{audit_id}")
def audit_entry(audit_id: int, x_session_token: str | None = Header(default=None)) -> dict:
    _require_action(x_session_token, 'audit:read')
    payload = audit_repo.load(audit_id)
    if not payload:
        raise HTTPException(status_code=404, detail="Audit entry not found")
    return payload


@app.get("/casualties")

def casualties(scenario_id: str | None = None) -> list[dict]:
    return [c.to_dict() for c in make_demo_casualties(scenario_id=scenario_id)]


@app.get("/casualties/{casualty_id}")
def casualty_detail(casualty_id: str, scenario_id: str | None = None) -> dict:
    for c in make_demo_casualties(scenario_id=scenario_id):
        if c.id == casualty_id:
            return c.to_dict()
    raise HTTPException(status_code=404, detail="Casualty not found")


@app.get("/casualties/{casualty_id}/history")
def casualty_history(casualty_id: str, scenario_id: str | None = None, limit: int = 20) -> list[dict]:
    return casualty_repo.list_history(casualty_id=casualty_id, scenario_id=scenario_id, limit=limit)


@app.get("/analytics/casualty_history")
def casualty_history_summary(scenario_id: str | None = None) -> dict:
    return casualty_repo.summary(scenario_id=scenario_id)


@app.get("/scene")
def scene(scenario_id: str | None = None) -> dict:
    casualties = make_demo_casualties(scenario_id=scenario_id)
    scenario = scenario_registry.load(scenario_id) if scenario_id else scenario_registry.get_current()
    scene = projector.project(casualties)
    scene["platforms"] = scenario.get('platforms', [])
    scene["markers"] = [marker_builder.build_marker(c) for c in casualties]
    scene["scenario"] = {"id": scenario['id'], "name": scenario['name']}
    return scene


@app.get("/coordination")
def coordination(scenario_id: str | None = None) -> dict:
    return make_coordination_plan(scenario_id=scenario_id)


@app.get("/replay")
def replay(persist: bool = True, session_id: str | None = None, scenario_id: str | None = None) -> dict:
    return make_replay_payload(persist=persist, session_id=session_id, scenario_id=scenario_id)


@app.get("/replay/latest")
def replay_latest() -> dict:
    payload = TimelineStore().load()
    if not payload.get("frames"):
        payload = make_replay_payload(persist=True)
    return payload


@app.get("/replay/sessions")
def replay_sessions() -> list[dict]:
    return ReplaySessionStore().list_sessions()


@app.get("/replay/export/{session_id}")
def replay_export(session_id: str) -> dict:
    payload = ReplaySessionStore().load_named(session_id)
    if not payload:
        raise HTTPException(status_code=404, detail="Replay session not found")
    return payload


@app.post("/replay/import")
def replay_import(req: ReplayImportRequest) -> dict:
    ReplaySessionStore().save_named(req.session_id, req.payload)
    return {"ok": True, "session_id": req.session_id}


@app.get("/handoff/{casualty_id}")
def handoff(casualty_id: str, scenario_id: str | None = None) -> dict:
    try:
        return make_handoff_payload(casualty_id, scenario_id=scenario_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Casualty not found")


@app.get("/world_state")
def world_state(persist: bool = True, scenario_id: str | None = None) -> dict:
    return make_world_state(persist=persist, scenario_id=scenario_id)


@app.get("/world_state/latest")
def world_state_latest() -> dict:
    payload = world_state_store.latest_from_history() or world_state_store.load()
    if not payload:
        payload = make_world_state(persist=True)
    return payload


@app.get("/world_state/history")
def world_state_history(limit: int = 20) -> list[dict]:
    return world_state_store.history(limit=limit)


@app.get("/world_state/history/{record_id}")
def world_state_history_item(record_id: int) -> dict:
    payload = world_state_store.load_history_item(record_id)
    if not payload:
        raise HTTPException(status_code=404, detail="World state record not found")
    return payload


@app.post("/jobs/recompute/replay")
def recompute_replay(payload: dict | None = None, x_session_token: str | None = Header(default=None)) -> dict:
    sess = _require_action(x_session_token, "jobs:queue") if x_session_token else {"user_id": "system", "role": "admin"}
    payload = payload or {}
    job = job_manager.queue_job('recompute_replay', payload)
    try:
        result = make_replay_payload(persist=True, scenario_id=payload.get('scenario_id'))
        out = job_manager.complete(job['id'], {'session': result})
        _audit("job.recompute_replay", sess, "job", job["id"], payload)
        return out
    except Exception as e:
        return job_manager.fail(job['id'], str(e))


@app.post("/jobs/recompute/world_state")
def recompute_world_state(payload: dict | None = None, x_session_token: str | None = Header(default=None)) -> dict:
    sess = _require_action(x_session_token, "jobs:queue") if x_session_token else {"user_id": "system", "role": "admin"}
    payload = payload or {}
    job = job_manager.queue_job('recompute_world_state', payload)
    try:
        result = make_world_state(persist=True, scenario_id=payload.get('scenario_id'))
        out = job_manager.complete(job['id'], {'world_state': result})
        _audit("job.recompute_world_state", sess, "job", job["id"], payload)
        return out
    except Exception as e:
        return job_manager.fail(job['id'], str(e))


@app.post("/jobs/async/replay")
def recompute_replay_async(payload: dict | None = None, x_session_token: str | None = Header(default=None)) -> dict:
    _require_action(x_session_token, 'scenario:mutate')
    payload = payload or {}
    return job_manager.submit_async(
        'recompute_replay_async',
        payload,
        lambda: {'session': make_replay_payload(persist=True, scenario_id=payload.get('scenario_id'))},
    )


@app.post("/jobs/async/world_state")
def recompute_world_state_async(payload: dict | None = None, x_session_token: str | None = Header(default=None)) -> dict:
    _require_action(x_session_token, 'scenario:mutate')
    payload = payload or {}
    return job_manager.submit_async(
        'recompute_world_state_async',
        payload,
        lambda: {'world_state': make_world_state(persist=True, scenario_id=payload.get('scenario_id'))},
    )


@app.get("/jobs/worker/status")
def worker_status() -> dict:
    async_status = job_manager.worker_status()
    durable_status = durable_worker.status()
    return {'queue_depth': async_status.get('queue_depth', 0), 'async': async_status, 'durable': durable_status}


@app.get("/jobs/queue_stats")
def jobs_queue_stats() -> dict:
    return job_manager.repo.queue_stats()


@app.post("/jobs/durable/replay")
def durable_replay_job(payload: dict | None = None, x_session_token: str | None = Header(default=None)) -> dict:
    sess = _require_action(x_session_token, 'jobs:queue') if x_session_token else {'user_id': 'system', 'role': 'admin'}
    payload = payload or {}
    job = job_manager.queue_job('durable_recompute_replay', payload)
    _audit('job.durable_replay.queue', sess, 'job', job['id'], payload)
    return job


@app.post("/jobs/durable/world_state")
def durable_world_state_job(payload: dict | None = None, x_session_token: str | None = Header(default=None)) -> dict:
    sess = _require_action(x_session_token, 'jobs:queue') if x_session_token else {'user_id': 'system', 'role': 'admin'}
    payload = payload or {}
    job = job_manager.queue_job('durable_recompute_world_state', payload)
    _audit('job.durable_world_state.queue', sess, 'job', job['id'], payload)
    return job


@app.post("/jobs/worker/run_once")
def durable_worker_run_once(x_session_token: str | None = Header(default=None)) -> dict:
    sess = _require_action(x_session_token, 'jobs:queue') if x_session_token else {'user_id': 'system', 'role': 'admin'}
    result = durable_worker.run_once()
    _audit('job.worker.run_once', sess, 'worker', 'durable', {'processed': result.get('processed', 0)})
    return result


@app.get("/jobs")
def list_jobs(limit: int = 50) -> list[dict]:
    return job_manager.list(limit=limit)


@app.get("/jobs/{job_id}")
def get_job(job_id: str) -> dict:
    payload = job_manager.load(job_id)
    if not payload:
        raise HTTPException(status_code=404, detail="Job not found")
    return payload


@app.get("/notifications/rules")
def notification_rules(x_session_token: str | None = Header(default=None)) -> dict:
    token = _session_token(x_session_token)
    if not token:
        raise HTTPException(status_code=400, detail="Missing X-Session-Token")
    from triage4.repositories.notification_rules_repository import NotificationRulesRepository
    return NotificationRulesRepository().load(token)


@app.put("/notifications/rules")
def notification_rules_save(payload: dict, x_session_token: str | None = Header(default=None)) -> dict:
    token = _session_token(x_session_token)
    sess = _require_role(x_session_token, 'viewer')
    if not token:
        raise HTTPException(status_code=400, detail="Missing X-Session-Token")
    from triage4.repositories.notification_rules_repository import NotificationRulesRepository
    result = NotificationRulesRepository().save(token, payload or {})
    _audit('notification.rules.save', sess, 'session', token, result.get('payload', {}))
    return result


@app.get("/notifications/digest_presets")
def notification_digest_presets(x_session_token: str | None = Header(default=None)) -> list[dict]:
    token = _session_token(x_session_token)
    if not token:
        raise HTTPException(status_code=400, detail="Missing X-Session-Token")
    from triage4.repositories.digest_preset_repository import DigestPresetRepository
    return DigestPresetRepository().list(token)


@app.post("/notifications/digest_presets")
def notification_digest_preset_save(payload: dict, x_session_token: str | None = Header(default=None)) -> dict:
    token = _session_token(x_session_token)
    sess = _require_role(x_session_token, 'viewer')
    if not token:
        raise HTTPException(status_code=400, detail="Missing X-Session-Token")
    from triage4.repositories.digest_preset_repository import DigestPresetRepository
    result = DigestPresetRepository().save(token, payload.get('name', 'preset'), payload.get('payload', {}))
    _audit('notification.digest_preset.save', sess, 'digest_preset', result.get('id', ''), {'name': result.get('name')})
    return result


@app.post("/notifications/digest_presets/{preset_id}/apply")
def notification_digest_preset_apply(preset_id: str, x_session_token: str | None = Header(default=None)) -> dict:
    token = _session_token(x_session_token)
    sess = _require_role(x_session_token, 'viewer')
    if not token:
        raise HTTPException(status_code=400, detail="Missing X-Session-Token")
    from triage4.repositories.digest_preset_repository import DigestPresetRepository
    from triage4.repositories.notification_rules_repository import NotificationRulesRepository
    preset = DigestPresetRepository().load(token, preset_id)
    if not preset:
        raise HTTPException(status_code=404, detail='Digest preset not found')
    body = preset.get('payload', {})
    current = notification_repo.subscription(token).get('payload', {})
    sub = notification_repo.save_subscription(token, {**current, 'digest_mode': body.get('digest_mode', current.get('digest_mode', 'realtime')), 'rules': body.get('rules', current.get('rules', {}))})
    rules = NotificationRulesRepository().save(token, body.get('rules', {}))
    _audit('notification.digest_preset.apply', sess, 'digest_preset', preset_id, {})
    return {'preset': preset, 'subscription': sub, 'rules': rules}


@app.get("/analytics/compare/baselines/{baseline_id}/history")
def compare_baseline_history(baseline_id: str) -> list[dict]:
    return compare_baseline_repo.history(baseline_id)


@app.get("/analytics/compare/baselines/{baseline_id}/trend")
def compare_baseline_trend(baseline_id: str) -> dict:
    return compare_baseline_repo.trend(baseline_id)


@app.post("/policy/profiles/validate")
def policy_profile_validate(payload: dict, x_session_token: str | None = Header(default=None)) -> dict:
    _require_action(x_session_token, 'policy:read')
    from triage4.analytics.policy_tools import validate_policy_profile
    return validate_policy_profile(payload or {})


@app.get("/policy/profiles/diff")
def policy_profile_diff(left: str, right: str, x_session_token: str | None = Header(default=None)) -> dict:
    _require_action(x_session_token, 'policy:read')
    from triage4.analytics.policy_tools import diff_policy_profiles
    lp = policy_repo.load(left)
    rp = policy_repo.load(right)
    if not lp or not rp:
        raise HTTPException(status_code=404, detail='Policy profile not found')
    return {'left': lp, 'right': rp, 'diff': diff_policy_profiles(lp.get('payload', {}), rp.get('payload', {}))}


@app.post("/jobs/{job_id}/cancel")
def cancel_job(job_id: str, x_session_token: str | None = Header(default=None)) -> dict:
    sess = _require_action(x_session_token, 'jobs:queue') if x_session_token else {'user_id': 'system', 'role': 'admin'}
    result = job_manager.repo.cancel(job_id)
    if not result:
        raise HTTPException(status_code=404, detail='Job not found')
    _audit('job.cancel', sess, 'job', job_id, {})
    return result


@app.post("/jobs/{job_id}/retry")
def retry_job(job_id: str, x_session_token: str | None = Header(default=None)) -> dict:
    sess = _require_action(x_session_token, 'jobs:queue') if x_session_token else {'user_id': 'system', 'role': 'admin'}
    result = job_manager.repo.retry(job_id)
    if not result:
        raise HTTPException(status_code=404, detail='Job not found')
    _audit('job.retry', sess, 'job', job_id, {'new_job_id': result.get('id')})
    return result


@app.get("/analytics/world_state/timeline")
def world_state_timeline(limit: int = 20) -> dict:
    from triage4.analytics.timeline import world_state_timeline as _timeline
    return _timeline(world_state_store.history(limit=limit))


@app.get("/analytics/casualty_history/{casualty_id}/timeline")
def casualty_timeline(casualty_id: str, scenario_id: str | None = None, limit: int = 20) -> dict:
    from triage4.analytics.timeline import casualty_timeline as _timeline
    return _timeline(casualty_repo.list_history(casualty_id=casualty_id, scenario_id=scenario_id, limit=limit))
