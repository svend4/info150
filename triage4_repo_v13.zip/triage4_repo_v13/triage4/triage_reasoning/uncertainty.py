from __future__ import annotations


class UncertaintyEngine:
    """Produces a transparent uncertainty summary for UI and handoff."""

    def estimate(
        self,
        confidence: float,
        deterioration_risk: float,
        hypothesis_count: int,
        signal_quality: float,
    ) -> dict:
        uncertainty_score = 1.0 - (
            confidence * 0.45
            + signal_quality * 0.30
            + max(0.0, 1.0 - deterioration_risk) * 0.15
            + min(1.0, hypothesis_count / 4.0) * 0.10
        )
        uncertainty_score = round(min(max(uncertainty_score, 0.0), 1.0), 3)

        if uncertainty_score >= 0.66:
            band = "high"
        elif uncertainty_score >= 0.33:
            band = "medium"
        else:
            band = "low"

        return {
            "score": uncertainty_score,
            "band": band,
            "signal_quality": round(signal_quality, 3),
            "confidence": round(confidence, 3),
            "deterioration_risk": round(deterioration_risk, 3),
            "hypothesis_count": hypothesis_count,
        }
