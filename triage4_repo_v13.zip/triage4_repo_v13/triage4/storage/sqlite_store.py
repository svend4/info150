from __future__ import annotations

import json
import secrets
import sqlite3
from pathlib import Path
from typing import Any


class SQLiteStore:
    def __init__(self, db_path: str | Path | None = None) -> None:
        if db_path is None:
            root = Path(__file__).resolve().parents[2]
            db_path = root / "data" / "triage4.sqlite"
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _ensure_column(self, conn: sqlite3.Connection, table: str, column: str, ddl: str) -> None:
        cols = {row[1] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}
        if column not in cols:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {ddl}")

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS scenarios (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    description TEXT DEFAULT '',
                    payload TEXT NOT NULL,
                    is_active INTEGER DEFAULT 0,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS scenario_revisions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    scenario_id TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    note TEXT DEFAULT '',
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS replay_sessions (
                    session_id TEXT PRIMARY KEY,
                    payload TEXT NOT NULL,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS world_state_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    scenario_id TEXT,
                    payload TEXT NOT NULL,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS casualty_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    scenario_id TEXT,
                    casualty_id TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS user_profiles (
                    user_id TEXT PRIMARY KEY,
                    role TEXT NOT NULL,
                    display_name TEXT DEFAULT '',
                    payload TEXT NOT NULL,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS sessions (
                    token TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS dashboard_presets (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    token TEXT NOT NULL,
                    name TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS user_workspaces (
                    token TEXT PRIMARY KEY,
                    payload TEXT NOT NULL,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS jobs (
                    id TEXT PRIMARY KEY,
                    kind TEXT NOT NULL,
                    status TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    result TEXT DEFAULT '{}',
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS audit_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    actor_user_id TEXT DEFAULT '',
                    actor_role TEXT DEFAULT '',
                    action TEXT NOT NULL,
                    target_type TEXT DEFAULT '',
                    target_id TEXT DEFAULT '',
                    payload TEXT NOT NULL,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS workspace_snapshots (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    token TEXT NOT NULL,
                    name TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS compare_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    left_scenario TEXT NOT NULL,
                    right_scenario TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS compare_baselines (
                    id TEXT PRIMARY KEY,
                    left_scenario TEXT NOT NULL,
                    right_scenario TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
                );
                

                CREATE TABLE IF NOT EXISTS notification_subscriptions (
                    token TEXT PRIMARY KEY,
                    payload TEXT NOT NULL,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS notification_reads (
                    token TEXT NOT NULL,
                    event_id TEXT NOT NULL,
                    read_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (token, event_id)
                );

                CREATE TABLE IF NOT EXISTS restore_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    token TEXT DEFAULT '',
                    action TEXT NOT NULL,
                    target_type TEXT NOT NULL,
                    target_id TEXT NOT NULL,
                    before_payload TEXT NOT NULL,
                    after_payload TEXT NOT NULL,
                    undo_payload TEXT NOT NULL,
                    undone_at TEXT DEFAULT NULL,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS policy_profiles (
                    id TEXT PRIMARY KEY,
                    payload TEXT NOT NULL,
                    is_active INTEGER DEFAULT 0,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
                );
                """
            )
            self._ensure_column(conn, 'scenarios', 'deleted_at', "deleted_at TEXT DEFAULT NULL")
            self._ensure_column(conn, 'user_profiles', 'deleted_at', "deleted_at TEXT DEFAULT NULL")

    # Scenario methods
    def upsert_scenario(self, payload: dict[str, Any], active: bool = False, note: str = '') -> dict[str, Any]:
        scenario_id = payload.get('id') or 'custom_scenario'
        name = payload.get('name') or scenario_id
        description = payload.get('description') or ''
        serialized = json.dumps(payload, indent=2)
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO scenarios (id, name, description, payload, is_active)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    name=excluded.name,
                    description=excluded.description,
                    payload=excluded.payload,
                    updated_at=CURRENT_TIMESTAMP
                """,
                (scenario_id, name, description, serialized, 1 if active else 0),
            )
            conn.execute(
                "INSERT INTO scenario_revisions (scenario_id, payload, note) VALUES (?, ?, ?)",
                (scenario_id, serialized, note or 'save'),
            )
            if active:
                conn.execute("UPDATE scenarios SET is_active=CASE WHEN id=? THEN 1 ELSE 0 END", (scenario_id,))
        return payload

    def list_scenarios(self, include_deleted: bool = False) -> list[dict[str, Any]]:
        sql = "SELECT id, name, description, is_active, payload, deleted_at FROM scenarios"
        if not include_deleted:
            sql += " WHERE deleted_at IS NULL"
        sql += " ORDER BY id"
        with self._connect() as conn:
            rows = conn.execute(sql).fetchall()
        items = []
        for row in rows:
            payload = json.loads(row['payload'])
            items.append({
                'id': row['id'],
                'name': row['name'],
                'description': row['description'],
                'casualty_count': len(payload.get('casualties', [])),
                'platform_count': len(payload.get('platforms', [])),
                'is_active': bool(row['is_active']),
                'deleted': bool(row['deleted_at']),
                'deleted_at': row['deleted_at'],
            })
        return items

    def load_scenario(self, scenario_id: str, include_deleted: bool = True) -> dict[str, Any]:
        sql = "SELECT payload, deleted_at FROM scenarios WHERE id=?"
        with self._connect() as conn:
            row = conn.execute(sql, (scenario_id,)).fetchone()
        if not row:
            raise KeyError(scenario_id)
        if row['deleted_at'] and not include_deleted:
            raise KeyError(scenario_id)
        payload = json.loads(row['payload'])
        if row['deleted_at']:
            payload['_deleted_at'] = row['deleted_at']
        return payload

    def delete_scenario(self, scenario_id: str) -> bool:
        with self._connect() as conn:
            row = conn.execute("SELECT is_active, deleted_at FROM scenarios WHERE id=?", (scenario_id,)).fetchone()
            if not row:
                return False
            if row['is_active']:
                return False
            if row['deleted_at']:
                return True
            conn.execute("UPDATE scenarios SET deleted_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP WHERE id=?", (scenario_id,))
        return True

    def restore_scenario(self, scenario_id: str) -> bool:
        with self._connect() as conn:
            row = conn.execute("SELECT id, deleted_at FROM scenarios WHERE id=?", (scenario_id,)).fetchone()
            if not row or not row['deleted_at']:
                return False
            conn.execute("UPDATE scenarios SET deleted_at=NULL, updated_at=CURRENT_TIMESTAMP WHERE id=?", (scenario_id,))
        return True

    def set_active_scenario(self, scenario_id: str) -> dict[str, Any]:
        payload = self.load_scenario(scenario_id, include_deleted=False)
        with self._connect() as conn:
            conn.execute("UPDATE scenarios SET is_active=CASE WHEN id=? THEN 1 ELSE 0 END", (scenario_id,))
        return payload

    def get_active_scenario_id(self) -> str | None:
        with self._connect() as conn:
            row = conn.execute("SELECT id FROM scenarios WHERE is_active=1 AND deleted_at IS NULL LIMIT 1").fetchone()
        return row['id'] if row else None

    def list_scenario_revisions(self, scenario_id: str, limit: int = 50) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT id, note, created_at, payload FROM scenario_revisions WHERE scenario_id=? ORDER BY id DESC LIMIT ?",
                (scenario_id, limit),
            ).fetchall()
        return [
            {
                'id': int(r['id']),
                'scenario_id': scenario_id,
                'note': r['note'],
                'created_at': r['created_at'],
                'payload': json.loads(r['payload']),
            }
            for r in rows
        ]

    def load_scenario_revision(self, scenario_id: str, revision_id: int) -> dict[str, Any]:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT id, note, created_at, payload FROM scenario_revisions WHERE scenario_id=? AND id=?",
                (scenario_id, revision_id),
            ).fetchone()
        if not row:
            return {}
        return {
            'id': int(row['id']),
            'scenario_id': scenario_id,
            'note': row['note'],
            'created_at': row['created_at'],
            'payload': json.loads(row['payload']),
        }

    # Replay sessions
    def save_replay_session(self, session_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO replay_sessions (session_id, payload)
                VALUES (?, ?)
                ON CONFLICT(session_id) DO UPDATE SET
                    payload=excluded.payload,
                    updated_at=CURRENT_TIMESTAMP
                """,
                (session_id, json.dumps(payload, indent=2)),
            )
        return payload

    def load_replay_session(self, session_id: str) -> dict[str, Any]:
        with self._connect() as conn:
            row = conn.execute("SELECT payload FROM replay_sessions WHERE session_id=?", (session_id,)).fetchone()
        return json.loads(row['payload']) if row else {}

    def list_replay_sessions(self) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute("SELECT session_id, payload, updated_at FROM replay_sessions ORDER BY updated_at DESC, session_id DESC").fetchall()
        out = []
        for row in rows:
            payload = json.loads(row['payload'])
            out.append({
                'id': row['session_id'],
                'frame_count': len(payload.get('frames', [])),
                'kind': 'replay_session',
                'updated_at': row['updated_at'],
            })
        return out

    # World state history
    def add_world_state(self, scenario_id: str | None, payload: dict[str, Any]) -> int:
        with self._connect() as conn:
            cur = conn.execute(
                "INSERT INTO world_state_history (scenario_id, payload) VALUES (?, ?)",
                (scenario_id, json.dumps(payload, indent=2)),
            )
            return int(cur.lastrowid)

    def list_world_states(self, limit: int = 50) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT id, scenario_id, payload, created_at FROM world_state_history ORDER BY id DESC LIMIT ?",
                (limit,),
            ).fetchall()
        out = []
        for row in rows:
            payload = json.loads(row['payload'])
            out.append({
                'id': row['id'],
                'scenario_id': row['scenario_id'],
                'created_at': row['created_at'],
                'summary': payload.get('summary', {}),
            })
        return out

    def load_world_state(self, record_id: int) -> dict[str, Any]:
        with self._connect() as conn:
            row = conn.execute("SELECT payload FROM world_state_history WHERE id=?", (record_id,)).fetchone()
        return json.loads(row['payload']) if row else {}

    def latest_world_state(self) -> dict[str, Any]:
        with self._connect() as conn:
            row = conn.execute("SELECT payload FROM world_state_history ORDER BY id DESC LIMIT 1").fetchone()
        return json.loads(row['payload']) if row else {}

    # Casualty history
    def add_casualty_history(self, scenario_id: str | None, casualty_id: str, payload: dict[str, Any]) -> int:
        with self._connect() as conn:
            cur = conn.execute(
                "INSERT INTO casualty_history (scenario_id, casualty_id, payload) VALUES (?, ?, ?)",
                (scenario_id, casualty_id, json.dumps(payload, indent=2)),
            )
            return int(cur.lastrowid)

    def list_casualty_history(self, casualty_id: str, scenario_id: str | None = None, limit: int = 50) -> list[dict[str, Any]]:
        sql = "SELECT id, scenario_id, payload, created_at FROM casualty_history WHERE casualty_id=?"
        params: list[Any] = [casualty_id]
        if scenario_id:
            sql += " AND scenario_id=?"
            params.append(scenario_id)
        sql += " ORDER BY id DESC LIMIT ?"
        params.append(limit)
        with self._connect() as conn:
            rows = conn.execute(sql, tuple(params)).fetchall()
        out = []
        for row in rows:
            payload = json.loads(row['payload'])
            out.append({
                'id': row['id'],
                'scenario_id': row['scenario_id'],
                'created_at': row['created_at'],
                'payload': payload,
            })
        return out

    def casualty_history_summary(self, scenario_id: str | None = None) -> dict[str, Any]:
        sql = "SELECT casualty_id, payload FROM casualty_history"
        params: list[Any] = []
        if scenario_id:
            sql += " WHERE scenario_id=?"
            params.append(scenario_id)
        with self._connect() as conn:
            rows = conn.execute(sql, tuple(params)).fetchall()
        per_casualty: dict[str, dict[str, Any]] = {}
        for row in rows:
            payload = json.loads(row['payload'])
            cid = row['casualty_id']
            per_casualty.setdefault(cid, {'samples': 0, 'max_deterioration': 0.0, 'latest_priority': 'unknown'})
            per_casualty[cid]['samples'] += 1
            per_casualty[cid]['max_deterioration'] = max(per_casualty[cid]['max_deterioration'], payload.get('deterioration_risk', 0.0))
            per_casualty[cid]['latest_priority'] = payload.get('triage_priority', per_casualty[cid]['latest_priority'])
        items = [
            {'casualty_id': cid, **vals}
            for cid, vals in sorted(per_casualty.items())
        ]
        return {'count': len(items), 'items': items}

    # User profiles
    def save_user_profile(self, user_id: str, role: str, display_name: str = '', payload: dict[str, Any] | None = None) -> dict[str, Any]:
        body = payload or {}
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO user_profiles (user_id, role, display_name, payload)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(user_id) DO UPDATE SET
                    role=excluded.role,
                    display_name=excluded.display_name,
                    payload=excluded.payload,
                    updated_at=CURRENT_TIMESTAMP
                """,
                (user_id, role, display_name, json.dumps(body, indent=2)),
            )
        return self.load_user_profile(user_id)

    def load_user_profile(self, user_id: str, include_deleted: bool = True) -> dict[str, Any]:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM user_profiles WHERE user_id=?", (user_id,)).fetchone()
        if not row:
            return {}
        if row['deleted_at'] and not include_deleted:
            return {}
        return {
            'user_id': row['user_id'],
            'role': row['role'],
            'display_name': row['display_name'],
            'payload': json.loads(row['payload']),
            'created_at': row['created_at'],
            'updated_at': row['updated_at'],
            'deleted_at': row['deleted_at'],
            'deleted': bool(row['deleted_at']),
        }

    def list_user_profiles(self, include_deleted: bool = False) -> list[dict[str, Any]]:
        sql = "SELECT user_id FROM user_profiles"
        if not include_deleted:
            sql += " WHERE deleted_at IS NULL"
        sql += " ORDER BY user_id"
        with self._connect() as conn:
            rows = conn.execute(sql).fetchall()
        return [self.load_user_profile(r['user_id'], include_deleted=True) for r in rows]

    def soft_delete_user(self, user_id: str) -> bool:
        with self._connect() as conn:
            row = conn.execute("SELECT user_id, deleted_at FROM user_profiles WHERE user_id=?", (user_id,)).fetchone()
            if not row:
                return False
            if row['deleted_at']:
                return True
            conn.execute("UPDATE user_profiles SET deleted_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP WHERE user_id=?", (user_id,))
        return True

    def restore_user(self, user_id: str) -> bool:
        with self._connect() as conn:
            row = conn.execute("SELECT user_id, deleted_at FROM user_profiles WHERE user_id=?", (user_id,)).fetchone()
            if not row or not row['deleted_at']:
                return False
            conn.execute("UPDATE user_profiles SET deleted_at=NULL, updated_at=CURRENT_TIMESTAMP WHERE user_id=?", (user_id,))
        return True

    # Session methods
    def create_session(self, user_id: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        token = secrets.token_hex(16)
        body = payload or {}
        body.setdefault('filters', {})
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO sessions (token, user_id, payload) VALUES (?, ?, ?)",
                (token, user_id, json.dumps(body, indent=2)),
            )
        return self.load_session(token)

    def load_session(self, token: str) -> dict[str, Any]:
        with self._connect() as conn:
            row = conn.execute("SELECT user_id, payload, created_at, updated_at FROM sessions WHERE token=?", (token,)).fetchone()
        if not row:
            return {}
        profile = self.load_user_profile(row['user_id'], include_deleted=True)
        return {
            'token': token,
            'user_id': row['user_id'],
            'role': profile.get('role', 'analyst'),
            'display_name': profile.get('display_name', row['user_id']),
            'payload': json.loads(row['payload']),
            'created_at': row['created_at'],
            'updated_at': row['updated_at'],
        }

    def update_session(self, token: str, payload: dict[str, Any]) -> dict[str, Any]:
        sess = self.load_session(token)
        if not sess:
            raise KeyError(token)
        with self._connect() as conn:
            conn.execute(
                "UPDATE sessions SET payload=?, updated_at=CURRENT_TIMESTAMP WHERE token=?",
                (json.dumps(payload, indent=2), token),
            )
        return self.load_session(token)

    def list_sessions(self) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute("SELECT token FROM sessions ORDER BY updated_at DESC").fetchall()
        return [self.load_session(r['token']) for r in rows]

    # Dashboard presets
    def save_dashboard_preset(self, token: str, name: str, payload: dict[str, Any]) -> dict[str, Any]:
        with self._connect() as conn:
            existing = conn.execute("SELECT id FROM dashboard_presets WHERE token=? AND name=?", (token, name)).fetchone()
            if existing:
                conn.execute(
                    "UPDATE dashboard_presets SET payload=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                    (json.dumps(payload, indent=2), existing['id']),
                )
                preset_id = int(existing['id'])
            else:
                cur = conn.execute(
                    "INSERT INTO dashboard_presets (token, name, payload) VALUES (?, ?, ?)",
                    (token, name, json.dumps(payload, indent=2)),
                )
                preset_id = int(cur.lastrowid)
        return {'id': preset_id, 'token': token, 'name': name, 'payload': payload}

    def list_dashboard_presets(self, token: str) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute("SELECT id, name, payload, updated_at FROM dashboard_presets WHERE token=? ORDER BY updated_at DESC, id DESC", (token,)).fetchall()
        return [
            {'id': int(r['id']), 'name': r['name'], 'payload': json.loads(r['payload']), 'updated_at': r['updated_at']}
            for r in rows
        ]

    def load_dashboard_preset(self, token: str, preset_id: int) -> dict[str, Any]:
        with self._connect() as conn:
            row = conn.execute("SELECT id, name, payload, updated_at FROM dashboard_presets WHERE token=? AND id=?", (token, preset_id)).fetchone()
        if not row:
            return {}
        return {'id': int(row['id']), 'name': row['name'], 'payload': json.loads(row['payload']), 'updated_at': row['updated_at']}

    # Workspace
    def save_workspace(self, token: str, payload: dict[str, Any]) -> dict[str, Any]:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO user_workspaces (token, payload)
                VALUES (?, ?)
                ON CONFLICT(token) DO UPDATE SET payload=excluded.payload, updated_at=CURRENT_TIMESTAMP
                """,
                (token, json.dumps(payload, indent=2)),
            )
        return self.load_workspace(token)

    def load_workspace(self, token: str) -> dict[str, Any]:
        with self._connect() as conn:
            row = conn.execute("SELECT token, payload, updated_at FROM user_workspaces WHERE token=?", (token,)).fetchone()
        if not row:
            return {}
        return {'token': row['token'], 'payload': json.loads(row['payload']), 'updated_at': row['updated_at']}

    # Jobs
    def create_job(self, kind: str, payload: dict[str, Any]) -> dict[str, Any]:
        job_id = secrets.token_hex(8)
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO jobs (id, kind, status, payload, result) VALUES (?, ?, 'queued', ?, '{}')",
                (job_id, kind, json.dumps(payload, indent=2)),
            )
        return self.load_job(job_id)

    def update_job(self, job_id: str, status: str, result: dict[str, Any] | None = None) -> dict[str, Any]:
        with self._connect() as conn:
            conn.execute(
                "UPDATE jobs SET status=?, result=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                (status, json.dumps(result or {}, indent=2), job_id),
            )
        return self.load_job(job_id)

    def load_job(self, job_id: str) -> dict[str, Any]:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
        if not row:
            return {}
        return {
            'id': row['id'], 'kind': row['kind'], 'status': row['status'],
            'payload': json.loads(row['payload']), 'result': json.loads(row['result']),
            'created_at': row['created_at'], 'updated_at': row['updated_at'],
        }

    def list_jobs(self, limit: int = 50) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute("SELECT id FROM jobs ORDER BY created_at DESC, id DESC LIMIT ?", (limit,)).fetchall()
        return [self.load_job(r['id']) for r in rows]

    def job_queue_stats(self) -> dict[str, Any]:
        with self._connect() as conn:
            rows = conn.execute("SELECT status, COUNT(*) AS c FROM jobs GROUP BY status").fetchall()
        counts = {r['status']: int(r['c']) for r in rows}
        total = sum(counts.values())
        return {'total': total, 'by_status': counts}



    # Audit log
    def add_audit_entry(
        self,
        action: str,
        actor_user_id: str = '',
        actor_role: str = '',
        target_type: str = '',
        target_id: str = '',
        payload: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body = payload or {}
        with self._connect() as conn:
            cur = conn.execute(
                "INSERT INTO audit_log (actor_user_id, actor_role, action, target_type, target_id, payload) VALUES (?, ?, ?, ?, ?, ?)",
                (actor_user_id, actor_role, action, target_type, target_id, json.dumps(body, indent=2)),
            )
            audit_id = int(cur.lastrowid)
        return self.load_audit_entry(audit_id)

    def list_audit_entries(self, limit: int = 100, action: str | None = None) -> list[dict[str, Any]]:
        sql = "SELECT id FROM audit_log"
        params: list[Any] = []
        if action:
            sql += " WHERE action=?"
            params.append(action)
        sql += " ORDER BY id DESC LIMIT ?"
        params.append(limit)
        with self._connect() as conn:
            rows = conn.execute(sql, tuple(params)).fetchall()
        return [self.load_audit_entry(int(r['id'])) for r in rows]

    def load_audit_entry(self, audit_id: int) -> dict[str, Any]:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM audit_log WHERE id=?", (audit_id,)).fetchone()
        if not row:
            return {}
        return {
            'id': int(row['id']),
            'actor_user_id': row['actor_user_id'],
            'actor_role': row['actor_role'],
            'action': row['action'],
            'target_type': row['target_type'],
            'target_id': row['target_id'],
            'payload': json.loads(row['payload']),
            'created_at': row['created_at'],
        }

    # Workspace snapshots
    def save_workspace_snapshot(self, token: str, name: str, payload: dict[str, Any]) -> dict[str, Any]:
        with self._connect() as conn:
            cur = conn.execute(
                "INSERT INTO workspace_snapshots (token, name, payload) VALUES (?, ?, ?)",
                (token, name, json.dumps(payload, indent=2)),
            )
            snapshot_id = int(cur.lastrowid)
        return self.load_workspace_snapshot(snapshot_id, token=token)

    def list_workspace_snapshots(self, token: str, limit: int = 50) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT id FROM workspace_snapshots WHERE token=? ORDER BY id DESC LIMIT ?",
                (token, limit),
            ).fetchall()
        return [self.load_workspace_snapshot(int(r['id']), token=token) for r in rows]

    def load_workspace_snapshot(self, snapshot_id: int, token: str | None = None) -> dict[str, Any]:
        sql = "SELECT * FROM workspace_snapshots WHERE id=?"
        params: list[Any] = [snapshot_id]
        if token is not None:
            sql += " AND token=?"
            params.append(token)
        with self._connect() as conn:
            row = conn.execute(sql, tuple(params)).fetchone()
        if not row:
            return {}
        return {
            'id': int(row['id']),
            'token': row['token'],
            'name': row['name'],
            'payload': json.loads(row['payload']),
            'created_at': row['created_at'],
        }

    # Compare history
    def save_compare_history(self, left_scenario: str, right_scenario: str, payload: dict[str, Any]) -> dict[str, Any]:
        with self._connect() as conn:
            cur = conn.execute(
                "INSERT INTO compare_history (left_scenario, right_scenario, payload) VALUES (?, ?, ?)",
                (left_scenario, right_scenario, json.dumps(payload, indent=2)),
            )
            compare_id = int(cur.lastrowid)
        return self.load_compare_history(compare_id)

    def list_compare_history(self, limit: int = 50) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute("SELECT id FROM compare_history ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [self.load_compare_history(int(r['id'])) for r in rows]

    def load_compare_history(self, compare_id: int) -> dict[str, Any]:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM compare_history WHERE id=?", (compare_id,)).fetchone()
        if not row:
            return {}
        return {
            'id': int(row['id']),
            'left_scenario': row['left_scenario'],
            'right_scenario': row['right_scenario'],
            'payload': json.loads(row['payload']),
            'created_at': row['created_at'],
        }

    def save_compare_baseline(self, baseline_id: str, left_scenario: str, right_scenario: str, payload: dict[str, Any]) -> dict[str, Any]:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO compare_baselines (id, left_scenario, right_scenario, payload)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    left_scenario=excluded.left_scenario,
                    right_scenario=excluded.right_scenario,
                    payload=excluded.payload,
                    updated_at=CURRENT_TIMESTAMP
                """,
                (baseline_id, left_scenario, right_scenario, json.dumps(payload, indent=2)),
            )
        return self.load_compare_baseline(baseline_id)

    def list_compare_baselines(self) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute("SELECT id FROM compare_baselines ORDER BY id").fetchall()
        return [self.load_compare_baseline(r['id']) for r in rows]

    def load_compare_baseline(self, baseline_id: str) -> dict[str, Any]:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM compare_baselines WHERE id=?", (baseline_id,)).fetchone()
        if not row:
            return {}
        return {
            'id': row['id'],
            'left_scenario': row['left_scenario'],
            'right_scenario': row['right_scenario'],
            'payload': json.loads(row['payload']),
            'created_at': row['created_at'],
            'updated_at': row['updated_at'],
        }


    # Notification subscriptions / unread state
    def save_notification_subscription(self, token: str, payload: dict[str, Any]) -> dict[str, Any]:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO notification_subscriptions (token, payload)
                VALUES (?, ?)
                ON CONFLICT(token) DO UPDATE SET payload=excluded.payload, updated_at=CURRENT_TIMESTAMP
                """,
                (token, json.dumps(payload, indent=2)),
            )
        return self.load_notification_subscription(token)

    def load_notification_subscription(self, token: str) -> dict[str, Any]:
        with self._connect() as conn:
            row = conn.execute("SELECT token, payload, updated_at FROM notification_subscriptions WHERE token=?", (token,)).fetchone()
        if not row:
            return {'token': token, 'payload': {'kinds': ['audit', 'job'], 'actions': [], 'muted': False, 'pause_until': None, 'digest_mode': 'realtime'}, 'updated_at': None}
        return {'token': row['token'], 'payload': json.loads(row['payload']), 'updated_at': row['updated_at']}

    def mark_notification_read(self, token: str, event_id: str) -> dict[str, Any]:
        with self._connect() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO notification_reads (token, event_id) VALUES (?, ?)",
                (token, event_id),
            )
        return {'token': token, 'event_id': event_id, 'read': True}

    def list_notification_reads(self, token: str) -> set[str]:
        with self._connect() as conn:
            rows = conn.execute("SELECT event_id FROM notification_reads WHERE token=?", (token,)).fetchall()
        return {r['event_id'] for r in rows}

    # Restore history with undo semantics
    def save_restore_history(self, token: str, action: str, target_type: str, target_id: str, before_payload: dict[str, Any], after_payload: dict[str, Any], undo_payload: dict[str, Any]) -> dict[str, Any]:
        with self._connect() as conn:
            cur = conn.execute(
                "INSERT INTO restore_history (token, action, target_type, target_id, before_payload, after_payload, undo_payload) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (token, action, target_type, target_id, json.dumps(before_payload, indent=2), json.dumps(after_payload, indent=2), json.dumps(undo_payload, indent=2)),
            )
            rid = int(cur.lastrowid)
        return self.load_restore_history_item(rid)

    def list_restore_history(self, token: str | None = None, limit: int = 50) -> list[dict[str, Any]]:
        sql = "SELECT id FROM restore_history"
        params: list[Any] = []
        if token:
            sql += " WHERE token=?"
            params.append(token)
        sql += " ORDER BY id DESC LIMIT ?"
        params.append(limit)
        with self._connect() as conn:
            rows = conn.execute(sql, tuple(params)).fetchall()
        return [self.load_restore_history_item(int(r['id'])) for r in rows]

    def load_restore_history_item(self, restore_id: int) -> dict[str, Any]:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM restore_history WHERE id=?", (restore_id,)).fetchone()
        if not row:
            return {}
        return {
            'id': int(row['id']),
            'token': row['token'],
            'action': row['action'],
            'target_type': row['target_type'],
            'target_id': row['target_id'],
            'before_payload': json.loads(row['before_payload']),
            'after_payload': json.loads(row['after_payload']),
            'undo_payload': json.loads(row['undo_payload']),
            'undone_at': row['undone_at'],
            'created_at': row['created_at'],
        }

    def mark_restore_undone(self, restore_id: int) -> dict[str, Any]:
        with self._connect() as conn:
            conn.execute("UPDATE restore_history SET undone_at=CURRENT_TIMESTAMP WHERE id=?", (restore_id,))
        return self.load_restore_history_item(restore_id)

    # Policy profiles
    def save_policy_profile(self, profile_id: str, payload: dict[str, Any], activate: bool = False) -> dict[str, Any]:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO policy_profiles (id, payload, is_active)
                VALUES (?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET payload=excluded.payload, updated_at=CURRENT_TIMESTAMP
                """,
                (profile_id, json.dumps(payload, indent=2), 1 if activate else 0),
            )
            if activate:
                conn.execute("UPDATE policy_profiles SET is_active=CASE WHEN id=? THEN 1 ELSE 0 END", (profile_id,))
        return self.load_policy_profile(profile_id)

    def list_policy_profiles(self) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute("SELECT id FROM policy_profiles ORDER BY id").fetchall()
        return [self.load_policy_profile(r['id']) for r in rows]

    def load_policy_profile(self, profile_id: str) -> dict[str, Any]:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM policy_profiles WHERE id=?", (profile_id,)).fetchone()
        if not row:
            return {}
        return {
            'id': row['id'],
            'payload': json.loads(row['payload']),
            'is_active': bool(row['is_active']),
            'created_at': row['created_at'],
            'updated_at': row['updated_at'],
        }

    def active_policy_profile(self) -> dict[str, Any]:
        with self._connect() as conn:
            row = conn.execute("SELECT id FROM policy_profiles WHERE is_active=1 ORDER BY id LIMIT 1").fetchone()
        return self.load_policy_profile(row['id']) if row else {}

    def activate_policy_profile(self, profile_id: str) -> dict[str, Any]:
        with self._connect() as conn:
            row = conn.execute("SELECT id FROM policy_profiles WHERE id=?", (profile_id,)).fetchone()
            if not row:
                return {}
            conn.execute("UPDATE policy_profiles SET is_active=CASE WHEN id=? THEN 1 ELSE 0 END", (profile_id,))
        return self.load_policy_profile(profile_id)

    # Durable job queue helpers
    def list_jobs_by_status(self, status: str, limit: int = 50) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute("SELECT id FROM jobs WHERE status=? ORDER BY created_at ASC, id ASC LIMIT ?", (status, limit)).fetchall()
        return [self.load_job(r['id']) for r in rows]
