from __future__ import annotations

from statistics import mean

from triage4.autonomy.human_handoff import HumanHandoffBuilder
from triage4.core.models import BodyRegion, CasualtyNode, GeoPose
from triage4.dynamic.dynamic_body_graph import DynamicBodyGraphBuilder
from triage4.mission_coordination.assignment_engine import AssignmentEngine
from triage4.perception.body_regions import BodyRegionPolygonizer
from triage4.perception.wound_candidates import WoundCandidateBuilder
from triage4.repositories.casualty_repository import CasualtyRepository
from triage4.signatures.bleeding_signature import BleedingSignatureExtractor
from triage4.signatures.breathing_signature import BreathingSignatureExtractor
from triage4.signatures.perfusion_signature import PerfusionSignatureExtractor
from triage4.signatures.thermal_signature import ThermalSignatureExtractor
from triage4.semantic.signal_semantics import SignalSemanticsEngine
from triage4.sim.scenario_registry import ScenarioRegistry
from triage4.state_graph.body_state_graph import BodyStateGraphBuilder
from triage4.state_graph.hypothesis_builder import HypothesisBuilder
from triage4.triage_reasoning.uncertainty import UncertaintyEngine
from triage4.triage_temporal.deterioration_model import DeteriorationModel
from triage4.triage_temporal.priority_engine import TemporalPriorityEngine
from triage4.triage_temporal.revisit_logic import RevisitLogic
from triage4.world_replay.replay_engine import ReplayEngine
from triage4.world_replay.world_state_store import WorldStateStore


def _load_scenario(scenario_id: str | None = None) -> dict:
    registry = ScenarioRegistry()
    if scenario_id:
        return registry.load(scenario_id)
    return registry.get_current()


def make_demo_casualties(scenario_id: str | None = None) -> list[CasualtyNode]:
    scenario = _load_scenario(scenario_id)
    breathing = BreathingSignatureExtractor()
    perfusion = PerfusionSignatureExtractor()
    bleeding = BleedingSignatureExtractor()
    thermal = ThermalSignatureExtractor()
    semantics = SignalSemanticsEngine()
    polygonizer = BodyRegionPolygonizer()
    wound_builder = WoundCandidateBuilder()
    hyp_builder = HypothesisBuilder()
    graph_builder = BodyStateGraphBuilder()
    dynamic_builder = DynamicBodyGraphBuilder()
    priority_engine = TemporalPriorityEngine()
    deterioration_model = DeteriorationModel()
    uncertainty_engine = UncertaintyEngine()
    revisit_logic = RevisitLogic()

    out: list[CasualtyNode] = []

    for row in scenario['casualties']:
        breathing_line = breathing.extract(row['breathing'])
        perfusion_line = perfusion.extract(row['perfusion'])

        chest_score = breathing.chest_motion_score(row['breathing'])
        perf_score = perfusion.perfusion_drop_score(row['perfusion'])

        tokens = semantics.from_signal_scores(
            chest_motion_score=chest_score,
            perfusion_drop_score=perf_score,
        )

        regions_dict = polygonizer.build_from_center(row['x'], row['y'])
        body_regions = [BodyRegion(name=name, polygon=poly) for name, poly in regions_dict.items()]
        wound_candidates = wound_builder.from_priority_hint(row['hint'], regions_dict)
        hypotheses = hyp_builder.build(tokens, wound_candidates)

        wound_score = max((w.score for w in wound_candidates), default=0.0)
        bleeding_score = bleeding.score(wound_score, perf_score, row['hint'])
        thermal_score = thermal.score(row['hint'], wound_score)

        priority, confidence = priority_engine.infer(
            hypotheses=hypotheses,
            chest_motion_score=chest_score,
            perfusion_drop_score=perf_score,
        )
        deterioration_risk = deterioration_model.estimate(
            chest_motion_score=chest_score,
            perfusion_drop_score=perf_score,
            hypothesis_count=len(hypotheses),
        )

        signal_quality = round((breathing_line.confidence + perfusion_line.confidence) / 2, 3)
        uncertainty = uncertainty_engine.estimate(
            confidence=confidence,
            deterioration_risk=deterioration_risk,
            hypothesis_count=len(hypotheses),
            signal_quality=signal_quality,
        )

        node = CasualtyNode(
            id=row['id'],
            location=GeoPose(x=row['x'], y=row['y']),
            signal_lines=[breathing_line, perfusion_line],
            evidence_tokens=tokens,
            body_regions=body_regions,
            wound_candidates=wound_candidates,
            state_hypotheses=hypotheses,
            triage_priority=priority,
            confidence=confidence,
            deterioration_risk=deterioration_risk,
            bleeding_score=bleeding_score,
            thermal_anomaly_score=thermal_score,
            uncertainty=uncertainty,
            status='observed',
        )

        node.body_state_graph = graph_builder.build(node, hypotheses)
        node.dynamic_body_graph = dynamic_builder.build(
            casualty_id=node.id,
            body_regions=body_regions,
            chest_motion_score=chest_score,
            perfusion_drop_score=perf_score,
        )
        node.revisit_required = revisit_logic.should_revisit(
            priority=priority,
            confidence=confidence,
            deterioration_risk=deterioration_risk,
        )
        node.priority_history = [
            {'t': 0, 'priority': 'unknown', 'confidence': 0.0},
            {'t': 1, 'priority': 'delayed' if priority == 'immediate' else priority, 'confidence': round(max(confidence - 0.15, 0.1), 3)},
            {'t': 2, 'priority': priority, 'confidence': confidence},
        ]
        out.append(node)

    plan = AssignmentEngine().plan(out)
    plan_map = {a['casualty_id']: a['asset'] for a in plan['assignments']}
    for node in out:
        node.assigned_asset = plan_map.get(node.id, node.assigned_asset)

    return out


def persist_casualty_histories(casualties: list[CasualtyNode], scenario_id: str | None = None) -> None:
    repo = CasualtyRepository()
    for c in casualties:
        repo.add(
            scenario_id=scenario_id,
            casualty_id=c.id,
            payload={
                'id': c.id,
                'triage_priority': c.triage_priority,
                'confidence': c.confidence,
                'deterioration_risk': c.deterioration_risk,
                'assigned_asset': c.assigned_asset,
                'revisit_required': c.revisit_required,
                'uncertainty': c.uncertainty,
            },
        )


def make_coordination_plan(scenario_id: str | None = None) -> dict:
    casualties = make_demo_casualties(scenario_id=scenario_id)
    return AssignmentEngine().plan(casualties)


def make_replay_payload(persist: bool = True, session_id: str | None = None, scenario_id: str | None = None) -> dict:
    return ReplayEngine().build(make_demo_casualties(scenario_id=scenario_id), persist=persist, session_id=session_id)


def make_handoff_payload(casualty_id: str, scenario_id: str | None = None) -> dict:
    casualties = make_demo_casualties(scenario_id=scenario_id)
    builder = HumanHandoffBuilder()
    for c in casualties:
        if c.id == casualty_id:
            return builder.build(c)
    raise KeyError(casualty_id)


def make_world_state(persist: bool = True, scenario_id: str | None = None) -> dict:
    scenario = _load_scenario(scenario_id)
    casualties = make_demo_casualties(scenario_id=scenario_id)
    coordination = make_coordination_plan(scenario_id=scenario_id)
    priorities = [c.triage_priority for c in casualties]
    asset_load = {}
    for c in casualties:
        if c.assigned_asset:
            asset_load[c.assigned_asset] = asset_load.get(c.assigned_asset, 0) + 1
    risk_bands = {
        'high': sum(1 for c in casualties if c.deterioration_risk >= 0.66),
        'medium': sum(1 for c in casualties if 0.33 <= c.deterioration_risk < 0.66),
        'low': sum(1 for c in casualties if c.deterioration_risk < 0.33),
    }
    world_state = {
        'scenario': {
            'id': scenario['id'],
            'name': scenario['name'],
            'description': scenario.get('description', ''),
        },
        'summary': {
            'casualty_count': len(casualties),
            'immediate_count': priorities.count('immediate'),
            'delayed_count': priorities.count('delayed'),
            'minimal_count': priorities.count('minimal'),
            'avg_deterioration_risk': round(mean(c.deterioration_risk for c in casualties), 3),
            'avg_confidence': round(mean(c.confidence for c in casualties), 3),
            'revisit_count': sum(1 for c in casualties if c.revisit_required),
        },
        'analytics': {
            'asset_load': asset_load,
            'risk_bands': risk_bands,
            'priority_histogram': {
                'immediate': priorities.count('immediate'),
                'delayed': priorities.count('delayed'),
                'minimal': priorities.count('minimal'),
            },
        },
        'platforms': scenario.get('platforms', []),
        'casualties': [
            {
                'id': c.id,
                'priority': c.triage_priority,
                'confidence': c.confidence,
                'deterioration_risk': c.deterioration_risk,
                'assigned_asset': c.assigned_asset,
                'revisit_required': c.revisit_required,
                'uncertainty_band': c.uncertainty.get('band') if isinstance(c.uncertainty, dict) else None,
            }
            for c in casualties
        ],
        'coordination': coordination,
    }
    if persist:
        WorldStateStore().save(world_state)
        persist_casualty_histories(casualties, scenario_id=scenario['id'])
    return world_state
