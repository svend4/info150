from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from triage4.repositories.scenario_repository import ScenarioRepository
from triage4.schemas.scenario_schema import ScenarioPayloadModel


class ScenarioRegistry:
    """Repository-backed registry for synthetic triage scenarios with file seeding."""

    def __init__(self, scenarios_dir: str | Path | None = None, db_path: str | Path | None = None) -> None:
        if scenarios_dir is None:
            root = Path(__file__).resolve().parents[2]
            scenarios_dir = root / "data" / "scenarios"
        self.scenarios_dir = Path(scenarios_dir)
        self.scenarios_dir.mkdir(parents=True, exist_ok=True)
        self.current_path = self.scenarios_dir / "current_scenario.txt"
        self.repo = ScenarioRepository(db_path)
        self._seed_from_files()

    def _validate(self, payload: dict[str, Any]) -> dict[str, Any]:
        return ScenarioPayloadModel.model_validate(payload).model_dump()

    def _seed_from_files(self) -> None:
        current = None
        if self.current_path.exists():
            txt = self.current_path.read_text(encoding='utf-8').strip()
            if txt:
                current = txt
        for path in sorted(self.scenarios_dir.glob('*.json')):
            payload = json.loads(path.read_text(encoding='utf-8'))
            payload = self._validate(payload)
            note = 'seed' if payload.get('id') != current else 'seed_active'
            self.repo.save(payload, active=(payload.get('id') == current), note=note)
        if not self.repo.active_id():
            try:
                self.repo.activate('default_triage')
            except KeyError:
                pass

    def list_scenarios(self, include_deleted: bool = False) -> list[dict[str, Any]]:
        return self.repo.list(include_deleted=include_deleted)

    def load(self, scenario_id: str, include_deleted: bool = True) -> dict[str, Any]:
        return self.repo.load(scenario_id, include_deleted=include_deleted)

    def get_current_id(self) -> str:
        current = self.repo.active_id()
        return current or 'default_triage'

    def get_current(self) -> dict[str, Any]:
        return self.load(self.get_current_id(), include_deleted=False)

    def set_current(self, scenario_id: str) -> dict[str, Any]:
        payload = self.repo.activate(scenario_id)
        self.current_path.write_text(scenario_id, encoding='utf-8')
        return payload

    def save(self, payload: dict[str, Any], note: str = 'save') -> dict[str, Any]:
        payload = self._validate(payload)
        scenario_id = payload.get('id') or 'custom_scenario'
        path = self.scenarios_dir / f'{scenario_id}.json'
        path.write_text(json.dumps(payload, indent=2), encoding='utf-8')
        return self.repo.save(payload, note=note)

    def delete(self, scenario_id: str) -> bool:
        return self.repo.delete(scenario_id)

    def restore(self, scenario_id: str) -> bool:
        return self.repo.restore(scenario_id)

    def export(self, scenario_id: str) -> dict[str, Any]:
        return self.load(scenario_id)

    def import_payload(self, payload: dict[str, Any]) -> dict[str, Any]:
        payload = self._validate(payload)
        return self.save(payload, note='import')

    def revisions(self, scenario_id: str, limit: int = 50) -> list[dict[str, Any]]:
        return self.repo.list_revisions(scenario_id, limit)

    def revision(self, scenario_id: str, revision_id: int) -> dict[str, Any]:
        return self.repo.load_revision(scenario_id, revision_id)
