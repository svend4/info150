# triage4 — ROADMAP

## Development principles

1. simulation first
2. explainability first
3. graph persistence first
4. build diagonally
5. replaceability of modules

## Phases

### Phase 1 — Repository scaffold
- root docs
- package config
- core models
- first tests

### Phase 2 — First diagonal MVP
- breathing signal proxy
- perfusion proxy
- evidence tokens
- tactical scene map

### Phase 3 — Structural expansion
- body polygons
- wound regions
- state graph
- mission coordination

### Phase 4 — Dynamic triage expansion
- dynamic body graph
- deterioration model
- revisit logic
- replay timeline

### Phase 5 — Hardening
- uncertainty
- thermal signatures
- cleaner UI split
- richer API detail endpoints

## Success criteria

The MVP is successful when it can:
1. generate synthetic casualties
2. extract signals
3. build evidence tokens
4. build body regions and wound candidates
5. produce hypotheses and triage priority
6. produce deterioration and revisit decisions
7. expose scene, coordination, and replay via API
8. render all of it in the UI
