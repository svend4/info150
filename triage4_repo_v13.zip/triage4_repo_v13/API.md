# API

## Auth and sessions
- `POST /auth/session`
- `GET /auth/sessions`
- `GET /auth/session/{token}`
- `PUT /auth/session/{token}/filters`

## Presets
- `GET /presets` (requires `X-Session-Token`)
- `POST /presets` (requires `X-Session-Token`)
- `GET /presets/{preset_id}` (requires `X-Session-Token`)

## Scenarios
- `GET /scenarios`
- `GET /scenarios/current`
- `GET /scenarios/{scenario_id}`
- `GET /scenarios/export/{scenario_id}`
- `POST /scenarios/import`
- `POST /scenarios`
- `PUT /scenarios/{scenario_id}`
- `DELETE /scenarios/{scenario_id}`
- `POST /scenarios/{scenario_id}/activate`
- `GET /scenarios/compare?left=...&right=...`

## Casualties
- `GET /casualties`
- `GET /casualties/{casualty_id}`
- `GET /casualties/{casualty_id}/history`
- `GET /analytics/casualty_history`
- `GET /handoff/{casualty_id}`

## Scene and world
- `GET /scene`
- `GET /coordination`
- `GET /world_state`
- `GET /world_state/latest`
- `GET /world_state/history`
- `GET /world_state/history/{record_id}`

## Replay
- `GET /replay`
- `GET /replay/latest`
- `GET /replay/sessions`
- `GET /replay/export/{session_id}`
- `POST /replay/import`

## Jobs
- `POST /jobs/recompute/replay`
- `POST /jobs/recompute/world_state`
- `GET /jobs`
- `GET /jobs/{job_id}`

## v8 additions

- `POST /auth/users`
- `GET /auth/users`
- `GET /auth/users/{user_id}`
- `GET /scenarios/{scenario_id}/revisions`
- `GET /scenarios/{scenario_id}/revisions/{revision_id}`
- `GET /workspace/export`
- `POST /workspace/import`
- `PUT /workspace/layout`
- `POST /jobs/async/replay`
- `POST /jobs/async/world_state`


## v9 additions

- audit log
- workspace snapshot history
- compare history
- granular action permissions
- user profile update endpoint

## v11 endpoints

- `GET /events/feed`
- `GET /jobs/worker/status`
- `GET /scenarios/{scenario_id}/revisions/diff?left_revision=&right_revision=`
- `DELETE /auth/users/{user_id}`
- `POST /auth/users/{user_id}/restore`
- `POST /scenarios/{scenario_id}/restore`
- `GET /workspace/snapshots/diff?left_snapshot_id=&right_snapshot_id=`


## v11 highlights

- notification subscriptions and unread state
- restore history with undo semantics
- data-configurable policy profiles
- durable worker process and durable job queue
- side-by-side diff payload views


## v12 additions

- notification preferences with mute/pause rules
- compare baselines and baseline reruns
- restore preview endpoint
- job queue stats endpoint
- policy profile editor page
- compare baselines page


## v13 additions

- `GET /notifications/rules`
- `PUT /notifications/rules`
- `GET /notifications/digest_presets`
- `POST /notifications/digest_presets`
- `POST /notifications/digest_presets/{preset_id}/apply`
- `GET /analytics/compare/baselines/{baseline_id}/history`
- `GET /analytics/compare/baselines/{baseline_id}/trend`
- `POST /policy/profiles/validate`
- `GET /policy/profiles/diff?left=&right=`
- `POST /jobs/{job_id}/cancel`
- `POST /jobs/{job_id}/retry`
- `GET /analytics/world_state/timeline`
- `GET /analytics/casualty_history/{casualty_id}/timeline`
