# triage4

Minimal but structured stand-off triage demonstrator.

## Current state

This repository includes:

- synthetic casualty generation
- signal-level signatures
- body-region mapping
- state hypotheses
- temporal triage priority
- deterioration risk
- uncertainty summary
- mission coordination
- medic handoff payload
- replay view
- minimal React/Vite dashboard

## Backend

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .
uvicorn triage4.ui.dashboard_api:app --reload
```

## Frontend

```bash
cd web_ui
npm install
npm run dev
```

## API endpoints

- `/health`
- `/casualties`
- `/casualties/{id}`
- `/scene`
- `/coordination`
- `/replay`
- `/handoff/{id}`


## Additional docs
- `API.md`
- `CONTRIBUTING.md`


## v5 additions

- SQLite-backed persistence
- scenario CRUD and compare
- world-state history
- analytics dashboard


## v6 additions
- repository/DAO layer over SQLite
- persistent casualty history
- scenario import/export endpoints
- scenario editor UI
- analytics charts


## v7 additions

- session-based presets and filters
- scenario validation schema
- background recompute jobs
- Recharts-based analytics dashboard


## v8 additions

- role-based auth / permissions
- persistent user profiles
- scenario revision history
- async job queue endpoints
- workspace export/import and layout persistence


## v9 additions

- audit log
- workspace snapshot history
- compare history
- granular action permissions
- user profile update endpoint

## v11 additions

- diff views for scenario revisions and workspace snapshots
- soft-delete / restore for scenarios and users
- policy-engine based permissions
- background worker loop status
- event feed over audit and jobs


## v11 highlights

- notification subscriptions and unread state
- restore history with undo semantics
- data-configurable policy profiles
- durable worker process and durable job queue
- side-by-side diff payload views


## v12 additions

- notification preferences with mute/pause rules
- compare baselines and baseline reruns
- restore preview endpoint
- job queue stats endpoint
- policy profile editor page
- compare baselines page


## v13 additions

- per-user notification rules and digest presets
- baseline history and trend endpoints
- policy profile diff and validation
- job retry/cancel semantics
- timeline drill-down for world-state and casualty history
