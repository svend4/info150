# Contributing

## Principles
- keep data contracts stable
- validate scenarios before saving
- prefer repository/DAO access over direct SQLite usage in API code
- keep background jobs idempotent for demo recomputation
- preserve explainability in all triage-facing outputs

## Frontend
- use page-level components for tabs
- keep analytics widgets readable in dark theme
- prefer typed payloads over `any` where practical

## v8 notes

- use session tokens for workspace and preset flows
- operator role required for scenario mutation and async recompute jobs
- admin role required for scenario deletion


## v9 additions

- audit log
- workspace snapshot history
- compare history
- granular action permissions
- user profile update endpoint

## v11 notes

- permissions should be added through `triage4/auth/policy_engine.py`
- avoid hardcoding role->action logic directly in endpoints
- prefer repositories and store methods that preserve auditability


## v11 highlights

- notification subscriptions and unread state
- restore history with undo semantics
- data-configurable policy profiles
- durable worker process and durable job queue
- side-by-side diff payload views
