# triage4 — BOOTSTRAP

## Repository tree
See `MASTER_INDEX.md` and the repository tree itself.

## Assembly order
1. root files
2. `core/`
3. first diagonal
4. second diagonal
5. third diagonal
6. simulation and API
7. frontend
8. tests

## Minimal run order
1. install backend
2. run FastAPI
3. install frontend
4. run Vite
5. run tests

## MVP-complete state
The repo reaches MVP-complete state when:
- synthetic scene works,
- all three diagonals exist,
- API exposes scene/coordination/replay,
- UI renders overview and replay,
- tests pass.
