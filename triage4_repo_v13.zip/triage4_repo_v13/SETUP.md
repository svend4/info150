# triage4 — SETUP

## Requirements
- Python 3.11+
- Node.js 18+
- npm
- git

## Backend

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .
uvicorn triage4.ui.dashboard_api:app --reload
```

## Frontend

```bash
cd web_ui
npm install
npm run dev
```

## Tests

```bash
pytest
```

## Endpoints
- `/health`
- `/casualties`
- `/scene`
- `/coordination`
- `/replay`

## Successful local run
A local run is successful when:
- backend starts,
- frontend starts,
- casualties load,
- coordination loads,
- replay loads,
- tests pass.
