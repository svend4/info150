# SCENARIOS

## v5 scenario management

Scenarios are seeded from JSON files in `data/scenarios/` and mirrored into SQLite for CRUD operations.

### Supported operations
- list
- load
- create
- update
- activate
- compare
- delete (non-active only)
