from triage4.triage_temporal.priority_engine import TemporalPriorityEngine
from triage4.triage_temporal.deterioration_model import DeteriorationModel
from triage4.triage_temporal.revisit_logic import RevisitLogic
from triage4.core.models import StateHypothesis
from triage4.world_replay.replay_engine import ReplayEngine
from triage4.core.models import CasualtyNode, GeoPose


def test_temporal_priority_engine():
    hypotheses = [StateHypothesis(name="respiratory_distress", score=0.8)]
    priority, confidence = TemporalPriorityEngine().infer(
        hypotheses=hypotheses,
        chest_motion_score=0.05,
        perfusion_drop_score=0.30,
    )
    assert priority in {"immediate", "delayed", "minimal"}
    assert confidence >= 0.0


def test_deterioration_risk():
    risk = DeteriorationModel().estimate(
        chest_motion_score=0.05,
        perfusion_drop_score=0.85,
        hypothesis_count=2,
    )
    assert risk > 0.0


def test_revisit_logic():
    assert RevisitLogic().should_revisit("immediate", 0.70, 0.30) is True
    assert RevisitLogic().should_revisit("minimal", 0.90, 0.10) is False


def test_replay_engine():
    node = CasualtyNode(id="C1", location=GeoPose(10, 10), triage_priority="immediate", confidence=0.8, deterioration_risk=0.6)
    payload = ReplayEngine().build([node])
    assert "frames" in payload
    assert len(payload["frames"]) == 6
