from __future__ import annotations

from datetime import datetime, timedelta, timezone
import uuid

from fastapi.testclient import TestClient

from triage4.auth.session_manager import SessionManager
from triage4.repositories.policy_repository import PolicyRepository
from triage4.auth.policy_engine import DEFAULT_ROLE_ACTIONS
from triage4.ui.dashboard_api import app


client = TestClient(app)


def _session(user_id: str, role: str):
    prepo = PolicyRepository()
    prepo.save('default', {'role_actions': {k: sorted(v) for k, v in DEFAULT_ROLE_ACTIONS.items()}}, activate=True)
    sm = SessionManager()
    sm.create_user('admin_seed_v12', 'admin', 'Admin Seed')
    sm.create_user(user_id, role, user_id)
    return client.post('/auth/session', json={'user_id': user_id}).json()


def test_notification_preferences_pause_hides_feed():
    sess = _session(f'notif_v12_{uuid.uuid4().hex[:6]}', 'analyst')
    token = sess['token']
    future = (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
    resp = client.put('/notifications/preferences', headers={'X-Session-Token': token}, json={'kinds': ['audit', 'job'], 'actions': [], 'muted': False, 'pause_until': future, 'digest_mode': 'batched'})
    assert resp.status_code == 200
    payload = resp.json()['payload']
    assert payload['pause_until'] == future
    feed = client.get('/notifications/feed', headers={'X-Session-Token': token}).json()
    assert feed == []
    unread = client.get('/notifications/unread_count', headers={'X-Session-Token': token}).json()
    assert unread['unread'] == 0


def test_compare_baseline_save_and_run():
    sess = _session(f'cmp_v12_{uuid.uuid4().hex[:6]}', 'analyst')
    token = sess['token']
    baseline_id = f'baseline_{uuid.uuid4().hex[:6]}'
    save = client.post(f'/analytics/compare/baselines/{baseline_id}?left=default_triage&right=mass_casualty_dense', headers={'X-Session-Token': token})
    assert save.status_code == 200
    listed = client.get('/analytics/compare/baselines').json()
    assert any(item['id'] == baseline_id for item in listed)
    run = client.get(f'/analytics/compare/baselines/{baseline_id}/run').json()
    assert run['baseline']['id'] == baseline_id
    assert 'delta_vs_baseline' in run


def test_restore_preview_endpoint():
    sess = _session(f'preview_v12_{uuid.uuid4().hex[:6]}', 'analyst')
    token = sess['token']
    client.post('/workspace/import', headers={'X-Session-Token': token}, json={'payload': {'layout': {'tab': 'overview'}}})
    snap = client.post('/workspace/snapshot', headers={'X-Session-Token': token}, json={'name': 'before'}).json()
    client.put('/workspace/layout', headers={'X-Session-Token': token}, json={'layout': {'tab': 'world'}})
    client.post(f'/workspace/restore/{snap["id"]}', headers={'X-Session-Token': token})
    hist = client.get('/restore/history', headers={'X-Session-Token': token}).json()
    preview = client.get(f'/restore/preview/{hist[0]["id"]}', headers={'X-Session-Token': token})
    assert preview.status_code == 200
    assert 'summary' in preview.json()
    assert 'undo_mode' in preview.json()['summary']


def test_jobs_queue_stats_endpoint():
    before = client.get('/jobs/queue_stats').json()
    assert 'total' in before and 'by_status' in before
    client.post('/jobs/durable/replay', json={})
    after = client.get('/jobs/queue_stats').json()
    assert after['total'] >= before['total']
    assert 'queued' in after['by_status'] or after['total'] >= 1
