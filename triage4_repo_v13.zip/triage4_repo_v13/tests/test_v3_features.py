from pathlib import Path

from triage4.sim.demo_scene import make_replay_payload, make_world_state
from triage4.world_replay.timeline_store import TimelineStore
from triage4.world_replay.world_state_store import WorldStateStore


def test_persistent_replay_written(tmp_path):
    store_path = tmp_path / "replay.json"
    store = TimelineStore(store_path)
    store.add_frame({"t": 0})
    payload = store.save()
    assert store_path.exists()
    assert payload["frames"][0]["t"] == 0
    assert store.load()["frames"][0]["t"] == 0


def test_world_state_store_written(tmp_path):
    store_path = tmp_path / "world.json"
    payload = {"summary": {"casualty_count": 1}}
    store = WorldStateStore(store_path)
    store.save(payload)
    assert store_path.exists()
    assert store.load()["summary"]["casualty_count"] == 1


def test_make_world_state_contains_summary():
    payload = make_world_state(persist=False)
    assert "summary" in payload
    assert payload["summary"]["casualty_count"] >= 1


def test_make_replay_payload_has_frames():
    payload = make_replay_payload(persist=False)
    assert "frames" in payload
    assert len(payload["frames"]) == 6
