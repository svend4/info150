
from __future__ import annotations

import uuid
from fastapi.testclient import TestClient

from triage4.auth.policy_engine import DEFAULT_ROLE_ACTIONS
from triage4.repositories.policy_repository import PolicyRepository
from triage4.auth.session_manager import SessionManager
from triage4.ui.dashboard_api import app

client = TestClient(app)


def _session(user_id: str, role: str):
    prepo = PolicyRepository()
    prepo.save('default', {'role_actions': {k: sorted(v) for k, v in DEFAULT_ROLE_ACTIONS.items()}}, activate=True)
    sm = SessionManager()
    sm.create_user('admin_seed_v13', 'admin', 'Admin Seed')
    sm.create_user(user_id, role, user_id)
    return client.post('/auth/session', json={'user_id': user_id}).json()


def test_notification_rules_and_digest_presets():
    sess = _session(f'notif13_{uuid.uuid4().hex[:6]}', 'analyst')
    token = sess['token']
    r = client.put('/notifications/rules', headers={'X-Session-Token': token}, json={'only_unread': True, 'include_kinds': ['audit']})
    assert r.status_code == 200
    assert r.json()['payload']['only_unread'] is True
    p = client.post('/notifications/digest_presets', headers={'X-Session-Token': token}, json={'name': 'daily', 'payload': {'digest_mode': 'daily', 'rules': {'only_unread': True}}})
    assert p.status_code == 200
    preset_id = p.json()['id']
    apply = client.post(f'/notifications/digest_presets/{preset_id}/apply', headers={'X-Session-Token': token})
    assert apply.status_code == 200
    prefs = client.get('/notifications/preferences', headers={'X-Session-Token': token}).json()
    assert prefs['payload']['digest_mode'] == 'daily'


def test_baseline_history_and_trend():
    sess = _session(f'base13_{uuid.uuid4().hex[:6]}', 'analyst')
    token = sess['token']
    baseline_id = f'baseline13_{uuid.uuid4().hex[:6]}'
    client.post(f'/analytics/compare/baselines/{baseline_id}?left=default_triage&right=mass_casualty_dense', headers={'X-Session-Token': token})
    client.get(f'/analytics/compare/baselines/{baseline_id}/run')
    client.get(f'/analytics/compare/baselines/{baseline_id}/run?left=mass_casualty_dense&right=default_triage')
    hist = client.get(f'/analytics/compare/baselines/{baseline_id}/history').json()
    trend = client.get(f'/analytics/compare/baselines/{baseline_id}/trend').json()
    assert len(hist) >= 2
    assert trend['baseline_id'] == baseline_id
    assert trend['runs'] >= 2


def test_policy_validate_and_diff():
    admin = _session(f'policy13_{uuid.uuid4().hex[:6]}', 'admin')
    token = admin['token']
    invalid = client.post('/policy/profiles/validate', headers={'X-Session-Token': token}, json={'role_actions': {'viewer': []}}).json()
    assert invalid['valid'] is False
    client.post('/policy/profiles', headers={'X-Session-Token': token}, json={'profile_id': 'p13a', 'payload': {'role_actions': {k: sorted(v) for k, v in DEFAULT_ROLE_ACTIONS.items()}}})
    client.post('/policy/profiles', headers={'X-Session-Token': token}, json={'profile_id': 'p13b', 'payload': {'role_actions': {**{k: sorted(v) for k, v in DEFAULT_ROLE_ACTIONS.items()}, 'admin': sorted(set(DEFAULT_ROLE_ACTIONS['admin']) | {'jobs:queue'})}}})
    diff = client.get('/policy/profiles/diff?left=p13a&right=p13b', headers={'X-Session-Token': token})
    assert diff.status_code == 200
    assert 'diff' in diff.json()


def test_job_retry_cancel_and_timeline_drilldown():
    before = client.post('/jobs/durable/replay', json={}).json()
    cancel = client.post(f"/jobs/{before['id']}/cancel")
    assert cancel.status_code == 200
    assert cancel.json()['status'] == 'canceled'
    retry = client.post(f"/jobs/{before['id']}/retry")
    assert retry.status_code == 200
    assert retry.json()['payload']['retry_of'] == before['id']
    wt = client.get('/analytics/world_state/timeline').json()
    ct = client.get('/analytics/casualty_history/C1/timeline').json()
    assert 'points' in wt
    assert 'points' in ct
