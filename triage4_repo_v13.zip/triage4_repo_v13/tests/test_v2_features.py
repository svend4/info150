from triage4.autonomy.human_handoff import HumanHandoffBuilder
from triage4.core.models import CasualtyNode, GeoPose, StateHypothesis
from triage4.signatures.bleeding_signature import BleedingSignatureExtractor
from triage4.signatures.thermal_signature import ThermalSignatureExtractor
from triage4.triage_reasoning.uncertainty import UncertaintyEngine


def test_bleeding_signature_score():
    score = BleedingSignatureExtractor().score(0.8, 0.7, "immediate")
    assert 0.0 <= score <= 1.0
    assert score > 0.7


def test_thermal_signature_score():
    score = ThermalSignatureExtractor().score("delayed", 0.4)
    assert 0.0 <= score <= 1.0


def test_uncertainty_engine():
    payload = UncertaintyEngine().estimate(0.7, 0.4, 2, 0.8)
    assert payload["band"] in {"low", "medium", "high"}
    assert 0.0 <= payload["score"] <= 1.0


def test_handoff_builder():
    casualty = CasualtyNode(
        id="C1",
        location=GeoPose(10, 10),
        triage_priority="immediate",
        confidence=0.8,
        deterioration_risk=0.6,
        uncertainty={"score": 0.3, "band": "low"},
        state_hypotheses=[StateHypothesis(name="respiratory_distress", score=0.8, explanation="test")],
    )
    payload = HumanHandoffBuilder().build(casualty)
    assert payload["casualty_id"] == "C1"
    assert payload["recommended_action"]
