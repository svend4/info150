from triage4.perception.body_regions import BodyRegionPolygonizer
from triage4.perception.wound_candidates import WoundCandidateBuilder
from triage4.semantic.evidence_tokens import EvidenceBuilder
from triage4.state_graph.hypothesis_builder import HypothesisBuilder
from triage4.mission_coordination.assignment_engine import AssignmentEngine
from triage4.core.models import CasualtyNode, GeoPose


def test_body_regions_exist():
    regions = BodyRegionPolygonizer().build_from_center(50, 50)
    assert "torso" in regions
    assert "head" in regions


def test_hypothesis_builder_from_wound_and_evidence():
    evidence = [EvidenceBuilder().poor_perfusion(0.9)]
    wound = WoundCandidateBuilder().from_priority_hint(
        "immediate",
        BodyRegionPolygonizer().build_from_center(50, 50),
    )
    hypotheses = HypothesisBuilder().build(evidence, wound)
    assert len(hypotheses) >= 1


def test_assignment_engine_outputs_plan():
    node = CasualtyNode(id="C1", location=GeoPose(10, 10), triage_priority="immediate", confidence=0.7)
    plan = AssignmentEngine().plan([node])
    assert "assignments" in plan
    assert len(plan["assignments"]) == 1
