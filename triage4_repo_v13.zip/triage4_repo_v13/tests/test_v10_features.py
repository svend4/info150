import uuid
from fastapi.testclient import TestClient

from triage4.analytics.diffing import diff_payloads
from triage4.auth.policy_engine import PolicyEngine
from triage4.repositories.scenario_repository import ScenarioRepository
from triage4.repositories.user_repository import UserRepository
from triage4.repositories.workspace_snapshot_repository import WorkspaceSnapshotRepository
from triage4.repositories.workspace_repository import WorkspaceRepository
from triage4.auth.session_manager import SessionManager
from triage4.ui.dashboard_api import app


client = TestClient(app)


def _session(user_id: str, role: str):
    sm = SessionManager()
    sm.create_user(user_id, role, user_id)
    return client.post('/auth/session', json={'user_id': user_id}).json()


def test_diff_payloads_detect_changes():
    left = {'name': 'A', 'items': [1, 2], 'meta': {'x': 1}}
    right = {'name': 'B', 'items': [1, 3], 'meta': {'x': 1, 'y': 2}}
    payload = diff_payloads(left, right)
    assert payload['change_count'] >= 2


def test_scenario_soft_delete_restore(tmp_path):
    repo = ScenarioRepository(db_path=tmp_path / 'triage4.sqlite')
    repo.save({'id': 'soft_case', 'name': 'Soft Case', 'casualties': [], 'platforms': []})
    assert repo.delete('soft_case') is True
    items = repo.list(include_deleted=True)
    target = [x for x in items if x['id'] == 'soft_case'][0]
    assert target['deleted'] is True
    assert repo.restore('soft_case') is True
    target2 = [x for x in repo.list(include_deleted=True) if x['id'] == 'soft_case'][0]
    assert target2['deleted'] is False


def test_user_soft_delete_restore(tmp_path):
    repo = UserRepository(db_path=tmp_path / 'triage4.sqlite')
    repo.save('soft_user', 'analyst', 'Soft User')
    assert repo.soft_delete('soft_user') is True
    assert repo.load('soft_user', include_deleted=True)['deleted'] is True
    assert repo.restore('soft_user') is True
    assert repo.load('soft_user', include_deleted=True)['deleted'] is False


def test_policy_engine_actions():
    policy = PolicyEngine()
    assert policy.can('admin', 'users:delete') is True
    assert policy.can('viewer', 'users:delete') is False
    assert policy.can('analyst', 'scenario:compare') is True


def test_workspace_snapshot_diff(tmp_path):
    wrepo = WorkspaceRepository(db_path=tmp_path / 'triage4.sqlite')
    srepo = WorkspaceSnapshotRepository(db_path=tmp_path / 'triage4.sqlite')
    token = 'tokx'
    wrepo.save(token, {'layout': {'tab': 'overview'}, 'filters': {'priority': 'all'}})
    a = srepo.save(token, 'A', {'layout': {'tab': 'overview'}, 'filters': {'priority': 'all'}})
    b = srepo.save(token, 'B', {'layout': {'tab': 'world'}, 'filters': {'priority': 'immediate'}})
    diff = srepo.diff(a['id'], b['id'], token=token)
    assert diff['change_count'] >= 1


def test_event_feed_endpoint():
    resp = client.get('/events/feed')
    assert resp.status_code == 200
    payload = resp.json()
    assert isinstance(payload, list)


def test_scenario_revision_diff_endpoint_and_restore_flow():
    op = _session('op_v10', 'operator')
    admin = _session('admin_v10', 'admin')
    scenario_id = f"v10_case_{uuid.uuid4().hex[:8]}"
    base = {'payload': {'id': scenario_id, 'name': 'V10 Case', 'description': 'a', 'casualties': [], 'platforms': []}}
    assert client.post('/scenarios', headers={'X-Session-Token': op['token']}, json=base).status_code == 200
    upd = {'payload': {'id': scenario_id, 'name': 'V10 Case', 'description': 'b', 'casualties': [{'id': 'C1', 'x': 1, 'y': 1, 'breathing': [0.1,0.2,0.1,0.2], 'perfusion': [0.5,0.5,0.5,0.5], 'hint': 'delayed'}], 'platforms': []}}
    assert client.put(f'/scenarios/{scenario_id}', headers={'X-Session-Token': op['token']}, json=upd).status_code == 200
    revs = client.get(f'/scenarios/{scenario_id}/revisions').json()
    assert len(revs) >= 2
    diff = client.get(f"/scenarios/{scenario_id}/revisions/diff?left_revision={revs[-1]['id']}&right_revision={revs[0]['id']}").json()
    assert diff['change_count'] >= 1
    assert client.delete(f'/scenarios/{scenario_id}', headers={'X-Session-Token': admin['token']}).status_code == 200
    listed = client.get('/scenarios?include_deleted=true').json()
    row = [x for x in listed if x['id'] == scenario_id][0]
    assert row['deleted'] is True
    assert client.post(f'/scenarios/{scenario_id}/restore', headers={'X-Session-Token': op['token']}).status_code == 200


def test_worker_status_and_user_restore_endpoints():
    admin = _session('admin_v10_user', 'admin')
    assert client.delete('/auth/users/admin_v10_user', headers={'X-Session-Token': admin['token']}).status_code == 200
    assert client.post('/auth/users/admin_v10_user/restore', headers={'X-Session-Token': admin['token']}).status_code == 200
    worker = client.get('/jobs/worker/status').json()
    assert 'queue_depth' in worker
