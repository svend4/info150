
from triage4.sim.scenario_registry import ScenarioRegistry
from triage4.sim.demo_scene import make_demo_casualties, make_replay_payload, make_world_state
from triage4.world_replay.session_store import ReplaySessionStore


def test_scenario_registry_lists_scenarios():
    items = ScenarioRegistry().list_scenarios()
    ids = {item['id'] for item in items}
    assert 'default_triage' in ids
    assert 'mass_casualty_dense' in ids


def test_dense_scenario_has_more_casualties():
    casualties = make_demo_casualties(scenario_id='mass_casualty_dense')
    assert len(casualties) == 6


def test_replay_session_export_roundtrip(tmp_path):
    store = ReplaySessionStore(tmp_path)
    payload = {'frames': [{'t': 0}, {'t': 1}]}
    store.save_named('unit_test_session', payload)
    loaded = store.load_named('unit_test_session')
    assert loaded['frames'][1]['t'] == 1


def test_make_replay_payload_persists_named_session():
    session_id = 'v4_test_session'
    payload = make_replay_payload(persist=True, session_id=session_id, scenario_id='default_triage')
    loaded = ReplaySessionStore().load_named(session_id)
    assert payload['frames']
    assert loaded['frames']


def test_world_state_contains_analytics():
    payload = make_world_state(persist=False, scenario_id='mass_casualty_dense')
    assert payload['analytics']['asset_load']
    assert payload['analytics']['risk_bands']
    assert payload['scenario']['id'] == 'mass_casualty_dense'
