from triage4.signatures.breathing_signature import BreathingSignatureExtractor
from triage4.signatures.perfusion_signature import PerfusionSignatureExtractor
from triage4.semantic.signal_semantics import SignalSemanticsEngine


def test_first_diagonal_generates_tokens():
    breathing = BreathingSignatureExtractor()
    perfusion = PerfusionSignatureExtractor()
    semantics = SignalSemanticsEngine()

    chest = breathing.chest_motion_score([0.01, 0.02, 0.01, 0.02])
    perf = perfusion.perfusion_drop_score([0.20, 0.18, 0.17, 0.19])

    tokens = semantics.from_signal_scores(chest_motion_score=chest, perfusion_drop_score=perf)
    assert len(tokens) >= 1


def test_first_diagonal_priority():
    semantics = SignalSemanticsEngine()
    tokens = semantics.from_signal_scores(chest_motion_score=0.05, perfusion_drop_score=0.80)
    priority, confidence = semantics.triage_from_tokens(tokens)

    assert priority in {"immediate", "delayed", "minimal"}
    assert confidence >= 0.0
