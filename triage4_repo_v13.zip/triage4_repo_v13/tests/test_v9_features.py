
from pathlib import Path

from triage4.auth.permissions import PermissionGuard
from triage4.auth.session_manager import SessionManager
from triage4.repositories.audit_repository import AuditRepository
from triage4.repositories.workspace_snapshot_repository import WorkspaceSnapshotRepository
from triage4.repositories.workspace_repository import WorkspaceRepository
from triage4.repositories.compare_history_repository import CompareHistoryRepository


def _db(tmp_path: Path) -> Path:
    return tmp_path / "v9.sqlite"


def test_audit_repository_records_entries(tmp_path):
    repo = AuditRepository(_db(tmp_path))
    row = repo.add("scenario.compare", actor_user_id="u1", actor_role="analyst", target_type="scenario_pair", target_id="a:b", payload={"left": "a", "right": "b"})
    assert row["action"] == "scenario.compare"
    items = repo.list()
    assert len(items) >= 1


def test_workspace_snapshot_roundtrip(tmp_path):
    db = _db(tmp_path)
    wrepo = WorkspaceRepository(db)
    srepo = WorkspaceSnapshotRepository(db)
    token = "tok1"
    wrepo.save(token, {"layout": {"tab": "overview"}})
    snap = srepo.save(token, "first", {"layout": {"tab": "overview"}})
    loaded = srepo.load(snap["id"], token=token)
    assert loaded["name"] == "first"


def test_compare_history_repository(tmp_path):
    repo = CompareHistoryRepository(_db(tmp_path))
    row = repo.save("left_a", "right_b", {"delta": {"immediate": 1}})
    assert row["left_scenario"] == "left_a"
    assert repo.load(row["id"])["right_scenario"] == "right_b"


def test_permission_guard_actions(tmp_path):
    db = _db(tmp_path)
    sm = SessionManager(db)
    sm.create_user("admin_1", "admin", "Admin")
    admin = sm.create("admin_1")
    sm.create_user("viewer_1", "viewer", "Viewer")
    viewer = sm.create("viewer_1")
    guard = PermissionGuard(db)
    ok = guard.require_action(admin["token"], "users:mutate")
    assert ok["role"] == "admin"
    try:
        guard.require_action(viewer["token"], "users:mutate")
        assert False, "viewer should not mutate users"
    except Exception:
        assert True


def test_session_manager_update_user(tmp_path):
    db = _db(tmp_path)
    sm = SessionManager(db)
    sm.create_user("u1", "analyst", "A")
    updated = sm.update_user("u1", display_name="Analyst One", payload={"theme": "dark"})
    assert updated["display_name"] == "Analyst One"
    assert updated["payload"]["theme"] == "dark"
