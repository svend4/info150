import time

from fastapi.testclient import TestClient

from triage4.auth.session_manager import SessionManager
from triage4.repositories.user_repository import UserRepository
from triage4.repositories.workspace_repository import WorkspaceRepository
from triage4.sim.scenario_registry import ScenarioRegistry
from triage4.ui.dashboard_api import app


client = TestClient(app)


def _make_session(user_id: str, role: str):
    client.post('/auth/users', json={'user_id': user_id, 'role': role, 'display_name': user_id})
    return client.post('/auth/session', json={'user_id': user_id}).json()


def test_user_profiles_roundtrip(tmp_path):
    repo = UserRepository(db_path=tmp_path / 'triage4.sqlite')
    saved = repo.save('alice', 'operator', 'Alice')
    assert saved['role'] == 'operator'
    listed = repo.list()
    assert any(item['user_id'] == 'alice' for item in listed)


def test_role_permissions_for_scenario_mutation():
    analyst = _make_session('analyst_v8', 'analyst')
    admin = _make_session('admin_v8', 'admin')
    payload = {
        'payload': {
            'id': 'v8_scenario_case',
            'name': 'v8 scenario case',
            'description': 'created in test',
            'casualties': [
                {'id': 'C1', 'x': 1, 'y': 2, 'breathing': [0.1,0.2,0.1,0.2], 'perfusion': [0.5,0.5,0.5,0.5], 'hint': 'delayed'}
            ],
            'platforms': [{'id': 'u1', 'x': 0, 'y': 0, 'kind': 'uav'}],
        }
    }
    denied = client.post('/scenarios', headers={'X-Session-Token': analyst['token']}, json=payload)
    assert denied.status_code == 403
    allowed = client.post('/scenarios', headers={'X-Session-Token': admin['token']}, json=payload)
    assert allowed.status_code == 200


def test_scenario_revision_history_exists():
    admin = _make_session('operator_v8', 'operator')
    base = {
        'payload': {
            'id': 'rev_case_v8',
            'name': 'rev case v8',
            'description': 'first',
            'casualties': [
                {'id': 'C1', 'x': 5, 'y': 6, 'breathing': [0.1,0.2,0.1,0.2], 'perfusion': [0.5,0.5,0.5,0.5], 'hint': 'delayed'}
            ],
            'platforms': [{'id': 'u1', 'x': 0, 'y': 0, 'kind': 'uav'}],
        }
    }
    client.post('/scenarios', headers={'X-Session-Token': admin['token']}, json=base)
    updated = {'payload': dict(base['payload'])}
    updated['payload']['description'] = 'second'
    client.put('/scenarios/rev_case_v8', headers={'X-Session-Token': admin['token']}, json=updated)
    revisions = client.get('/scenarios/rev_case_v8/revisions').json()
    assert len(revisions) >= 2
    one = client.get(f"/scenarios/rev_case_v8/revisions/{revisions[0]['id']}").json()
    assert one['scenario_id'] == 'rev_case_v8'


def test_workspace_export_import_roundtrip(tmp_path):
    mgr = SessionManager()
    mgr.create_user('w_user', 'analyst', 'W User')
    sess = mgr.create('w_user')
    repo = WorkspaceRepository(db_path=tmp_path / 'triage4.sqlite')
    saved = repo.save(sess['token'], {'layout': {'tab': 'world'}, 'filters': {'priority': 'immediate'}})
    loaded = repo.load(sess['token'])
    assert loaded['payload']['layout']['tab'] == 'world'


def test_async_job_endpoint_completes():
    op = _make_session('job_operator_v8', 'operator')
    resp = client.post('/jobs/async/world_state', headers={'X-Session-Token': op['token']}, json={})
    assert resp.status_code == 200
    job = resp.json()
    for _ in range(20):
        loaded = client.get(f"/jobs/{job['id']}").json()
        if loaded['status'] in {'completed', 'failed'}:
            break
        time.sleep(0.05)
    assert loaded['status'] == 'completed'


def test_workspace_api_flow():
    sess = _make_session('workspace_api_v8', 'analyst')
    token = sess['token']
    put = client.put('/workspace/layout', headers={'X-Session-Token': token}, json={'layout': {'tab': 'analytics', 'leftPanel': 360}})
    assert put.status_code == 200
    exported = client.get('/workspace/export', headers={'X-Session-Token': token}).json()
    assert exported['workspace']['layout']['tab'] == 'analytics'
