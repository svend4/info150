import uuid
from fastapi.testclient import TestClient

from triage4.auth.policy_engine import PolicyEngine
from triage4.jobs.worker_process import DurableWorkerProcess
from triage4.repositories.notification_repository import NotificationRepository
from triage4.repositories.policy_repository import PolicyRepository
from triage4.auth.policy_engine import DEFAULT_ROLE_ACTIONS
from triage4.auth.session_manager import SessionManager
from triage4.repositories.restore_history_repository import RestoreHistoryRepository
from triage4.repositories.workspace_repository import WorkspaceRepository
from triage4.repositories.workspace_snapshot_repository import WorkspaceSnapshotRepository
from triage4.ui.dashboard_api import app


client = TestClient(app)


def _session(user_id: str, role: str):
    # reset active policy profile and user roles directly for deterministic API tests
    prepo = PolicyRepository()
    prepo.save('default', {'role_actions': {k: sorted(v) for k, v in DEFAULT_ROLE_ACTIONS.items()}}, activate=True)
    sm = SessionManager()
    sm.create_user('admin_seed_v11', 'admin', 'Admin Seed')
    sm.create_user(user_id, role, user_id)
    return client.post('/auth/session', json={'user_id': user_id}).json()


def test_notification_subscription_and_mark_read(tmp_path):
    repo = NotificationRepository(db_path=tmp_path / 'triage4.sqlite')
    repo.save_subscription('tok1', {'kinds': ['audit'], 'actions': []})
    assert repo.subscription('tok1')['payload']['kinds'] == ['audit']


def test_policy_profiles_data_driven(tmp_path):
    repo = PolicyRepository(db_path=tmp_path / 'triage4.sqlite')
    repo.save('custom', {'role_actions': {'viewer': ['events:read'], 'analyst': ['events:read'], 'operator': ['events:read'], 'admin': ['events:read', 'users:delete']}}, activate=True)
    engine = PolicyEngine(db_path=tmp_path / 'triage4.sqlite')
    assert engine.can('viewer', 'events:read') is True
    assert engine.can('viewer', 'scenario:compare') is False


def test_restore_history_workspace_undo_endpoint():
    sess = _session(f'user_v11_{uuid.uuid4().hex[:6]}', 'analyst')
    token = sess['token']
    client.post('/workspace/import', headers={'X-Session-Token': token}, json={'payload': {'layout': {'tab': 'overview'}}})
    snap = client.post('/workspace/snapshot', headers={'X-Session-Token': token}, json={'name': 'before'}).json()
    client.put('/workspace/layout', headers={'X-Session-Token': token}, json={'layout': {'tab': 'world'}})
    resp = client.post(f'/workspace/restore/{snap["id"]}', headers={'X-Session-Token': token})
    assert resp.status_code == 200
    hist = client.get('/restore/history', headers={'X-Session-Token': token}).json()
    assert len(hist) >= 1
    undo = client.post(f'/restore/undo/{hist[0]["id"]}', headers={'X-Session-Token': token})
    assert undo.status_code == 200


def test_diff_endpoints_include_payloads():
    op = _session(f'op_v11_{uuid.uuid4().hex[:6]}', 'operator')
    scenario_id = f'v11_case_{uuid.uuid4().hex[:8]}'
    base = {'payload': {'id': scenario_id, 'name': 'V11 Case', 'description': 'a', 'casualties': [], 'platforms': []}}
    assert client.post('/scenarios', headers={'X-Session-Token': op['token']}, json=base).status_code == 200
    upd = {'payload': {'id': scenario_id, 'name': 'V11 Case', 'description': 'b', 'casualties': [{'id': 'C1', 'x': 1, 'y': 1, 'breathing': [0.1,0.2,0.1,0.2], 'perfusion': [0.5,0.5,0.5,0.5], 'hint': 'delayed'}], 'platforms': []}}
    assert client.put(f'/scenarios/{scenario_id}', headers={'X-Session-Token': op['token']}, json=upd).status_code == 200
    revs = client.get(f'/scenarios/{scenario_id}/revisions').json()
    diff = client.get(f"/scenarios/{scenario_id}/revisions/diff?left_revision={revs[-1]['id']}&right_revision={revs[0]['id']}").json()
    assert 'left_payload' in diff and 'right_payload' in diff


def test_durable_worker_queue_flow():
    admin = _session(f'admin_v11_{uuid.uuid4().hex[:6]}', 'admin')
    queued = client.post('/jobs/durable/world_state', headers={'X-Session-Token': admin['token']}, json={}).json()
    assert queued['status'] == 'queued'
    run = client.post('/jobs/worker/run_once', headers={'X-Session-Token': admin['token']}).json()
    assert run['processed'] >= 1
    status = client.get('/jobs/worker/status').json()
    assert 'durable' in status


def test_notifications_endpoints():
    sess = _session(f'notif_v11_{uuid.uuid4().hex[:6]}', 'analyst')
    token = sess['token']
    sub = client.post('/notifications/subscriptions', headers={'X-Session-Token': token}, json={'kinds': ['audit'], 'actions': []})
    assert sub.status_code == 200
    feed = client.get('/notifications/feed', headers={'X-Session-Token': token}).json()
    assert isinstance(feed, list)
    if feed:
        mr = client.post(f"/notifications/mark_read/{feed[0]['id']}", headers={'X-Session-Token': token})
        assert mr.status_code == 200
        count = client.get('/notifications/unread_count', headers={'X-Session-Token': token}).json()
        assert 'unread' in count
