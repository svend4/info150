from fastapi.testclient import TestClient

from triage4.ui.dashboard_api import app
from triage4.repositories.session_repository import SessionRepository
from triage4.repositories.preset_repository import PresetRepository
from triage4.schemas.scenario_schema import ScenarioPayloadModel
from triage4.jobs.job_manager import JobManager


def test_session_repository_roundtrip(tmp_path):
    repo = SessionRepository(db_path=tmp_path / "triage4.sqlite")
    sess = repo.create("user_a", {"filters": {"priority": "all"}})
    loaded = repo.load(sess["token"])
    assert loaded["user_id"] == "user_a"


def test_preset_repository_roundtrip(tmp_path):
    session_repo = SessionRepository(db_path=tmp_path / "triage4.sqlite")
    sess = session_repo.create("user_b", {"filters": {}})
    repo = PresetRepository(db_path=tmp_path / "triage4.sqlite")
    saved = repo.save(sess["token"], "critical_only", {"filters": {"priority": "immediate"}})
    loaded = repo.load(sess["token"], saved["id"])
    assert loaded["name"] == "critical_only"


def test_scenario_schema_validation():
    payload = ScenarioPayloadModel.model_validate({
        "id": "schema_case",
        "name": "Schema Case",
        "casualties": [{"id": "C1", "x": 1, "y": 2, "breathing": [0.1,0.2,0.1,0.2], "perfusion": [0.7,0.7,0.7,0.7], "hint": "delayed"}],
        "platforms": [{"id": "u1", "x": 0, "y": 0, "kind": "uav"}],
    })
    assert payload.id == "schema_case"


def test_job_manager_roundtrip(tmp_path):
    mgr = JobManager()
    job = mgr.queue("recompute_world_state", {"scenario_id": "default_triage"})
    done = mgr.complete(job["id"], {"ok": True})
    assert done["status"] == "completed"


def test_api_session_and_preset_flow():
    client = TestClient(app)
    sess = client.post("/auth/session", json={"user_id": "analyst_api"}).json()
    token = sess["token"]
    save = client.post("/presets", headers={"X-Session-Token": token}, json={"name": "p1", "payload": {"filters": {"priority": "immediate"}}})
    assert save.status_code == 200
    listed = client.get("/presets", headers={"X-Session-Token": token}).json()
    assert len(listed) >= 1


def test_api_job_endpoint():
    client = TestClient(app)
    resp = client.post("/jobs/recompute/world_state", json={})
    assert resp.status_code == 200
    payload = resp.json()
    assert payload["status"] in {"completed", "failed"}
