from triage4.repositories.scenario_repository import ScenarioRepository
from triage4.repositories.casualty_repository import CasualtyRepository
from triage4.repositories.world_state_repository import WorldStateRepository
from triage4.sim.demo_scene import make_world_state
from triage4.sim.scenario_registry import ScenarioRegistry


def test_scenario_repository_roundtrip(tmp_path):
    repo = ScenarioRepository(db_path=tmp_path / "triage4.sqlite")
    payload = {"id": "unit_case", "name": "Unit Case", "casualties": [], "platforms": []}
    repo.save(payload)
    loaded = repo.load("unit_case")
    assert loaded["id"] == "unit_case"


def test_casualty_repository_history(tmp_path):
    repo = CasualtyRepository(db_path=tmp_path / "triage4.sqlite")
    repo.add("scenario_x", "C1", {"triage_priority": "immediate", "deterioration_risk": 0.7})
    history = repo.list_history("C1", scenario_id="scenario_x")
    assert len(history) == 1
    summary = repo.summary("scenario_x")
    assert summary["count"] == 1


def test_world_state_repository_latest(tmp_path):
    repo = WorldStateRepository(db_path=tmp_path / "triage4.sqlite")
    rid = repo.add("scenario_x", {"summary": {"casualty_count": 1}})
    assert rid >= 1
    latest = repo.latest()
    assert latest["summary"]["casualty_count"] == 1


def test_scenario_registry_import_export(tmp_path):
    scenarios_dir = tmp_path / "scenarios"
    scenarios_dir.mkdir()
    (scenarios_dir / "default_triage.json").write_text('{"id":"default_triage","name":"Default","casualties":[],"platforms":[]}', encoding='utf-8')
    (scenarios_dir / "current_scenario.txt").write_text('default_triage', encoding='utf-8')
    reg = ScenarioRegistry(scenarios_dir=scenarios_dir, db_path=tmp_path / "triage4.sqlite")
    reg.import_payload({"id": "imported_case", "name": "Imported", "casualties": [], "platforms": []})
    exported = reg.export("imported_case")
    assert exported["id"] == "imported_case"


def test_make_world_state_persists_history():
    payload = make_world_state(persist=True)
    assert "summary" in payload
