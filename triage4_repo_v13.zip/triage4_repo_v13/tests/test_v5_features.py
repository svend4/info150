from triage4.analytics.comparison import compare_world_states
from triage4.sim.demo_scene import make_world_state
from triage4.sim.scenario_registry import ScenarioRegistry
from triage4.storage.sqlite_store import SQLiteStore
from triage4.world_replay.world_state_store import WorldStateStore


def test_sqlite_store_initializes(tmp_path):
    db = SQLiteStore(tmp_path / 'triage4.sqlite')
    assert db.db_path.exists()


def test_scenario_crud_roundtrip(tmp_path):
    scenarios_dir = tmp_path / 'scenarios'
    scenarios_dir.mkdir()
    (scenarios_dir / 'default_triage.json').write_text('{"id":"default_triage","name":"Default","description":"seed","casualties":[],"platforms":[]}')
    (scenarios_dir / 'current_scenario.txt').write_text('default_triage')
    reg = ScenarioRegistry(scenarios_dir, tmp_path / 'triage4.sqlite')
    payload = {'id': 'crud_case', 'name': 'CRUD Case', 'description': 'test', 'casualties': [], 'platforms': []}
    reg.save(payload)
    assert reg.load('crud_case')['name'] == 'CRUD Case'
    reg.save({'id': 'crud_case', 'name': 'CRUD Updated', 'description': 'test2', 'casualties': [], 'platforms': []})
    assert reg.load('crud_case')['name'] == 'CRUD Updated'
    assert reg.delete('crud_case') is True


def test_world_state_history_persists():
    payload = make_world_state(persist=True, scenario_id='default_triage')
    store = WorldStateStore()
    history = store.history(limit=5)
    assert history
    latest = store.latest_from_history()
    assert latest.get('scenario', {}).get('id') == payload.get('scenario', {}).get('id')


def test_compare_world_states_between_scenarios():
    left = make_world_state(persist=False, scenario_id='default_triage')
    right = make_world_state(persist=False, scenario_id='mass_casualty_dense')
    cmp = compare_world_states(left, right)
    assert 'delta' in cmp
    assert cmp['right']['scenario']['id'] == 'mass_casualty_dense'
