# triage4 — MASTER INDEX

## What each file is for

- `README.md` — project entry point
- `ARCHITECTURE.md` — system design and K3 matrix
- `ROADMAP.md` — staged implementation plan
- `SETUP.md` — local install and run guide
- `BOOTSTRAP.md` — assembly order
- `CODE_PACK.md` — code pack note
- `MASTER_INDEX.md` — this navigation file

## Recommended reading order
1. `MASTER_INDEX.md`
2. `README.md`
3. `ARCHITECTURE.md`
4. `ROADMAP.md`

## Recommended practical order
1. `BOOTSTRAP.md`
2. `SETUP.md`
3. run backend/frontend/tests

## One-line summary
README explains the project, ARCHITECTURE explains the system, ROADMAP explains growth, BOOTSTRAP explains assembly, SETUP runs it, MASTER_INDEX ties everything together.


## v4 additions

Additional docs now included:

- `DATA_MODEL.md`
- `SCENARIOS.md`
- updated `API.md`
- updated `CONTRIBUTING.md`
