# triage4 — CODE PACK

This repository already contains the current code pack in actual files.

Use:
- `BOOTSTRAP.md` for assembly order
- `SETUP.md` for launch order
- `MASTER_INDEX.md` for document navigation
