# DATA MODEL

## v5 additions

### SQLite tables
- `scenarios`
- `replay_sessions`
- `world_state_history`

### Core persistence objects
- Scenario payload
- Replay session payload
- World-state snapshot payload
