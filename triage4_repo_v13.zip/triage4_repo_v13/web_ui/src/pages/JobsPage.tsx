import { useEffect, useState } from "react";

type Job = { id: string; kind: string; status: string; created_at?: string; updated_at?: string };

export default function JobsPage() {
  const [items, setItems] = useState<Job[]>([]);

  function reload() {
    fetch("http://127.0.0.1:8000/jobs").then((r) => r.json()).then(setItems);
  }

  useEffect(() => { reload(); }, []);

  async function run(kind: "replay" | "world_state") {
    const path = kind === "replay" ? "/jobs/recompute/replay" : "/jobs/recompute/world_state";
    await fetch(`http://127.0.0.1:8000${path}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({}) });
    reload();
  }

  return (
    <section style={{ background: "#0e1528", borderRadius: 12, padding: 16, gridColumn: "1 / span 2" }}>
      <h3 style={{ marginTop: 0 }}>Background Jobs</h3>
      <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
        <button onClick={() => run("replay")}>Recompute Replay</button>
        <button onClick={() => run("world_state")}>Recompute World State</button>
        <button onClick={reload}>Refresh Jobs</button>
      </div>
      {items.map((job) => (
        <div key={job.id} style={{ marginBottom: 8, padding: 10, background: "#121a30", borderRadius: 8 }}>
          <div><b>{job.kind}</b> — {job.status}</div>
          <div style={{ opacity: 0.8 }}>{job.id}</div>
          <div style={{ opacity: 0.8 }}>{job.updated_at}</div>
        </div>
      ))}
    </section>
  );
}
