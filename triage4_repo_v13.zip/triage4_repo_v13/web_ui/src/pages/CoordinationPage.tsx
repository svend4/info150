type Coordination = {
  assignments: { asset: string; casualty_id: string; action: string; priority: string }[];
  revisit_queue: { casualty_id: string; reason: string }[];
};

export default function CoordinationPage({ coordination }: { coordination: Coordination | null }) {
  return (
    <section style={{ background: "#0e1528", borderRadius: 12, padding: 16 }}>
      <h3 style={{ marginTop: 0 }}>Coordination</h3>
      {!coordination ? (
        <div>Loading…</div>
      ) : (
        <>
          <div style={{ marginBottom: 12 }}><b>Assignments</b></div>
          {coordination.assignments.map((a, idx) => (
            <div key={idx} style={{ marginBottom: 8, padding: 10, background: "#121a30", borderRadius: 8 }}>
              <div>{a.asset} → {a.casualty_id}</div>
              <div style={{ opacity: 0.8 }}>{a.action}</div>
            </div>
          ))}

          <div style={{ marginTop: 14, marginBottom: 8 }}><b>Revisit Queue</b></div>
          {coordination.revisit_queue.length === 0 ? (
            <div style={{ opacity: 0.7 }}>No revisit items</div>
          ) : (
            coordination.revisit_queue.map((r, idx) => (
              <div key={idx} style={{ marginBottom: 8, padding: 10, background: "#121a30", borderRadius: 8 }}>
                <div>{r.casualty_id}</div>
                <div style={{ opacity: 0.8 }}>{r.reason}</div>
              </div>
            ))
          )}
        </>
      )}
    </section>
  );
}
