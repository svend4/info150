type StateHypothesis = {
  name: string;
  score: number;
  explanation: string;
};

type Casualty = {
  id: string;
  triage_priority: string;
  confidence: number;
  deterioration_risk: number;
  assigned_asset?: string | null;
  revisit_required: boolean;
  bleeding_score: number;
  thermal_anomaly_score: number;
  uncertainty: { score: number; band: string; signal_quality: number };
  state_hypotheses: StateHypothesis[];
  priority_history: { t: number; priority: string; confidence: number }[];
};

function color(priority: string) {
  if (priority === "immediate") return "#ff5c5c";
  if (priority === "delayed") return "#ffb84d";
  return "#63d471";
}

export default function CasualtyPage({ selected, handoff }: { selected: Casualty | null; handoff: any | null }) {
  return (
    <section style={{ background: "#0e1528", borderRadius: 12, padding: 16, gridColumn: "1 / span 2" }}>
      <h3 style={{ marginTop: 0 }}>Selected Casualty</h3>
      {selected ? (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16 }}>
          <div>
            <div>ID: <b>{selected.id}</b></div>
            <div>Priority: <b style={{ color: color(selected.triage_priority) }}>{selected.triage_priority}</b></div>
            <div>Confidence: {selected.confidence}</div>
            <div>Deterioration risk: {selected.deterioration_risk}</div>
            <div>Assigned asset: {selected.assigned_asset ?? "—"}</div>
            <div>Revisit required: {selected.revisit_required ? "yes" : "no"}</div>
          </div>
          <div>
            <div>Bleeding score: {selected.bleeding_score}</div>
            <div>Thermal anomaly: {selected.thermal_anomaly_score}</div>
            <div>Uncertainty: {selected.uncertainty?.score} ({selected.uncertainty?.band})</div>
            <div>Signal quality: {selected.uncertainty?.signal_quality}</div>

            <h4>State Hypotheses</h4>
            {selected.state_hypotheses.map((h, idx) => (
              <div key={idx} style={{ marginBottom: 8, padding: 10, background: "#121a30", borderRadius: 8 }}>
                <div><b>{h.name}</b> — {h.score}</div>
                <div style={{ opacity: 0.8 }}>{h.explanation}</div>
              </div>
            ))}
          </div>
          <div>
            <h4>Priority History</h4>
            {selected.priority_history.map((p, idx) => (
              <div key={idx} style={{ marginBottom: 8, padding: 10, background: "#121a30", borderRadius: 8 }}>
                <div>t={p.t}</div>
                <div>{p.priority}</div>
                <div style={{ opacity: 0.8 }}>confidence: {p.confidence}</div>
              </div>
            ))}

            <h4>Medic Handoff</h4>
            {handoff ? (
              <div style={{ padding: 10, background: "#121a30", borderRadius: 8 }}>
                <div><b>Recommended action:</b> {handoff.recommended_action}</div>
                <div><b>Top hypotheses:</b></div>
                {handoff.top_hypotheses?.map((h: any, idx: number) => (
                  <div key={idx} style={{ opacity: 0.85 }}>{h.name} — {h.score}</div>
                ))}
              </div>
            ) : <div style={{ opacity: 0.7 }}>Loading handoff…</div>}
          </div>
        </div>
      ) : <div>Loading…</div>}
    </section>
  );
}
