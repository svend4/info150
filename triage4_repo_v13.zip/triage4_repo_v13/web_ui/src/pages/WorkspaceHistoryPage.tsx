
import { useEffect, useState } from "react";

type Props = { sessionToken: string };

export default function WorkspaceHistoryPage({ sessionToken }: Props) {
  const [items, setItems] = useState<any[]>([]);

  async function load() {
    if (!sessionToken) return;
    const data = await fetch("http://127.0.0.1:8000/workspace/snapshots", { headers: { "X-Session-Token": sessionToken } }).then((r) => r.json());
    setItems(Array.isArray(data) ? data : []);
  }

  async function saveSnapshot() {
    if (!sessionToken) return;
    await fetch("http://127.0.0.1:8000/workspace/snapshot", {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Session-Token": sessionToken },
      body: JSON.stringify({ name: `snapshot-${Date.now()}` })
    });
    await load();
  }

  async function restore(id: number) {
    if (!sessionToken) return;
    await fetch(`http://127.0.0.1:8000/workspace/restore/${id}`, {
      method: "POST",
      headers: { "X-Session-Token": sessionToken }
    });
    await load();
  }

  useEffect(() => { load(); }, [sessionToken]);

  if (!sessionToken) return <div style={{ background: "#0e1528", borderRadius: 12, padding: 16 }}>Create a session first.</div>;

  return (
    <div style={{ background: "#0e1528", borderRadius: 12, padding: 16 }}>
      <h3 style={{ marginTop: 0 }}>Workspace Snapshots</h3>
      <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
        <button onClick={saveSnapshot}>Save Snapshot</button>
        <button onClick={load}>Reload</button>
      </div>
      {items.map((item) => (
        <div key={item.id} style={{ marginBottom: 8, padding: 10, background: "#121a30", borderRadius: 8 }}>
          <div><b>{item.name}</b> #{item.id}</div>
          <div style={{ opacity: 0.8 }}>{item.created_at}</div>
          <button onClick={() => restore(item.id)} style={{ marginTop: 8 }}>Restore</button>
        </div>
      ))}
    </div>
  );
}
