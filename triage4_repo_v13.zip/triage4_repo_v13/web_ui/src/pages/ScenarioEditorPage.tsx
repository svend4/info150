import { useEffect, useState } from "react";

type ScenarioPayload = {
  id: string;
  name: string;
  description?: string;
  casualties: any[];
  platforms: any[];
};

export default function ScenarioEditorPage() {
  const [scenarioId, setScenarioId] = useState("default_triage");
  const [text, setText] = useState("");
  const [status, setStatus] = useState("");

  async function loadScenario(id: string) {
    setScenarioId(id);
    const payload = await fetch(`http://127.0.0.1:8000/scenarios/${id}`).then((r) => r.json());
    setText(JSON.stringify(payload, null, 2));
  }

  useEffect(() => {
    loadScenario(scenarioId);
  }, []);

  async function saveScenario() {
    try {
      const payload: ScenarioPayload = JSON.parse(text);
      const method = payload.id === scenarioId ? "PUT" : "POST";
      const url = method === "PUT" ? `http://127.0.0.1:8000/scenarios/${payload.id}` : "http://127.0.0.1:8000/scenarios";
      await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ payload }),
      });
      setStatus("Saved");
      setScenarioId(payload.id);
    } catch (e) {
      setStatus("Invalid JSON");
    }
  }

  async function importScenario() {
    try {
      const payload = JSON.parse(text);
      await fetch("http://127.0.0.1:8000/scenarios/import", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ payload }),
      });
      setStatus("Imported");
      setScenarioId(payload.id);
    } catch {
      setStatus("Import failed");
    }
  }

  async function exportScenario() {
    const payload = await fetch(`http://127.0.0.1:8000/scenarios/export/${scenarioId}`).then((r) => r.json());
    setText(JSON.stringify(payload, null, 2));
    setStatus("Exported");
  }

  return (
    <section style={{ background: "#0e1528", borderRadius: 12, padding: 16, gridColumn: "1 / span 2" }}>
      <h3 style={{ marginTop: 0 }}>Scenario Editor</h3>
      <div style={{ display: "flex", gap: 8, marginBottom: 10 }}>
        <input value={scenarioId} onChange={(e) => setScenarioId(e.target.value)} />
        <button onClick={() => loadScenario(scenarioId)}>Load</button>
        <button onClick={exportScenario}>Export</button>
        <button onClick={importScenario}>Import</button>
        <button onClick={saveScenario}>Save</button>
      </div>
      <div style={{ opacity: 0.8, marginBottom: 8 }}>{status}</div>
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        style={{ width: "100%", minHeight: 420, background: "#121a30", color: "#e5ecff", border: "1px solid #223056", borderRadius: 8, padding: 12, fontFamily: "monospace" }}
      />
    </section>
  );
}
