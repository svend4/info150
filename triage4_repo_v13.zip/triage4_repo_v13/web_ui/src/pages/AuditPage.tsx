
import { useEffect, useState } from "react";

type Props = { sessionToken: string };

export default function AuditPage({ sessionToken }: Props) {
  const [items, setItems] = useState<any[]>([]);

  async function load() {
    if (!sessionToken) return;
    const data = await fetch("http://127.0.0.1:8000/audit", { headers: { "X-Session-Token": sessionToken } }).then((r) => r.json());
    setItems(Array.isArray(data) ? data : []);
  }

  useEffect(() => { load(); }, [sessionToken]);

  if (!sessionToken) return <div style={{ background: "#0e1528", borderRadius: 12, padding: 16 }}>Create a session first.</div>;

  return (
    <div style={{ background: "#0e1528", borderRadius: 12, padding: 16 }}>
      <h3 style={{ marginTop: 0 }}>Audit Log</h3>
      <button onClick={load} style={{ marginBottom: 12 }}>Reload</button>
      {items.map((item) => (
        <div key={item.id} style={{ marginBottom: 8, padding: 10, background: "#121a30", borderRadius: 8 }}>
          <div><b>{item.action}</b> #{item.id}</div>
          <div style={{ opacity: 0.8 }}>actor: {item.actor_user_id || 'system'} ({item.actor_role || '—'})</div>
          <div style={{ opacity: 0.8 }}>target: {item.target_type}:{item.target_id}</div>
          <div style={{ opacity: 0.7 }}>{item.created_at}</div>
        </div>
      ))}
    </div>
  );
}
