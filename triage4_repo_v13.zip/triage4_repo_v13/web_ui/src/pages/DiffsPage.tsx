import { useEffect, useState } from "react";

type ScenarioItem = { id: string; name: string; deleted?: boolean };
type RevisionItem = { id: number; note: string; created_at: string };
type SnapshotItem = { id: number; name: string; created_at: string };

function Pretty({ value }: { value: any }) {
  return <pre style={{ whiteSpace: 'pre-wrap', fontSize: 12, background: '#121a30', padding: 10, borderRadius: 8, overflow: 'auto', maxHeight: 360 }}>{JSON.stringify(value ?? {}, null, 2)}</pre>;
}

export default function DiffsPage({ sessionToken }: { sessionToken: string }) {
  const [scenarios, setScenarios] = useState<ScenarioItem[]>([]);
  const [scenarioId, setScenarioId] = useState<string>("");
  const [revisions, setRevisions] = useState<RevisionItem[]>([]);
  const [leftRev, setLeftRev] = useState<number | "">("");
  const [rightRev, setRightRev] = useState<number | "">("");
  const [snapshots, setSnapshots] = useState<SnapshotItem[]>([]);
  const [leftSnap, setLeftSnap] = useState<number | "">("");
  const [rightSnap, setRightSnap] = useState<number | "">("");
  const [diffResult, setDiffResult] = useState<any>(null);
  const [snapDiff, setSnapDiff] = useState<any>(null);

  useEffect(() => {
    fetch("http://127.0.0.1:8000/scenarios?include_deleted=true").then((r) => r.json()).then((data) => {
      setScenarios(data);
      if (data.length) setScenarioId(data[0].id);
    });
  }, []);

  useEffect(() => {
    if (!scenarioId) return;
    fetch(`http://127.0.0.1:8000/scenarios/${scenarioId}/revisions?limit=20`).then((r) => r.json()).then((data) => {
      setRevisions(data);
      if (data.length > 1) {
        setLeftRev(data[data.length - 1].id);
        setRightRev(data[0].id);
      }
    });
  }, [scenarioId]);

  useEffect(() => {
    if (!sessionToken) return;
    fetch(`http://127.0.0.1:8000/workspace/snapshots?limit=20`, { headers: { 'X-Session-Token': sessionToken } }).then((r) => r.json()).then((data) => {
      setSnapshots(data);
      if (data.length > 1) {
        setLeftSnap(data[data.length - 1].id);
        setRightSnap(data[0].id);
      }
    });
  }, [sessionToken]);

  async function loadScenarioDiff() {
    if (!scenarioId || leftRev === "" || rightRev === "") return;
    const payload = await fetch(`http://127.0.0.1:8000/scenarios/${scenarioId}/revisions/diff?left_revision=${leftRev}&right_revision=${rightRev}`).then((r) => r.json());
    setDiffResult(payload);
  }

  async function loadSnapshotDiff() {
    if (!sessionToken || leftSnap === "" || rightSnap === "") return;
    const payload = await fetch(`http://127.0.0.1:8000/workspace/snapshots/diff?left_snapshot_id=${leftSnap}&right_snapshot_id=${rightSnap}`, { headers: { 'X-Session-Token': sessionToken } }).then((r) => r.json());
    setSnapDiff(payload);
  }

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: 16 }}>
      <section style={{ background: '#0e1528', borderRadius: 12, padding: 16 }}>
        <h3 style={{ marginTop: 0 }}>Scenario Revision Diff</h3>
        <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
          <select value={scenarioId} onChange={(e) => setScenarioId(e.target.value)}>
            {scenarios.map((s) => <option key={s.id} value={s.id}>{s.id}{s.deleted ? ' (deleted)' : ''}</option>)}
          </select>
          <select value={leftRev} onChange={(e) => setLeftRev(Number(e.target.value))}>
            {revisions.map((r) => <option key={r.id} value={r.id}>{r.id}:{r.note}</option>)}
          </select>
          <select value={rightRev} onChange={(e) => setRightRev(Number(e.target.value))}>
            {revisions.map((r) => <option key={r.id} value={r.id}>{r.id}:{r.note}</option>)}
          </select>
          <button onClick={loadScenarioDiff}>Diff</button>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
          <div><div style={{ marginBottom: 6 }}><b>Left payload</b></div><Pretty value={diffResult?.left_payload} /></div>
          <div><div style={{ marginBottom: 6 }}><b>Right payload</b></div><Pretty value={diffResult?.right_payload} /></div>
        </div>
        <div style={{ maxHeight: 240, overflow: 'auto' }}>
          {(diffResult?.changes || []).map((c:any, idx:number) => (
            <div key={idx} style={{ marginBottom: 6, padding: 8, background: '#121a30', borderRadius: 8 }}>
              <div><b>{c.kind}</b> — {c.path}</div>
            </div>
          ))}
        </div>
      </section>
      <section style={{ background: '#0e1528', borderRadius: 12, padding: 16 }}>
        <h3 style={{ marginTop: 0 }}>Workspace Snapshot Diff</h3>
        {!sessionToken ? <div>Create a session first.</div> : (
          <>
            <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
              <select value={leftSnap} onChange={(e) => setLeftSnap(Number(e.target.value))}>
                {snapshots.map((s) => <option key={s.id} value={s.id}>{s.id}:{s.name}</option>)}
              </select>
              <select value={rightSnap} onChange={(e) => setRightSnap(Number(e.target.value))}>
                {snapshots.map((s) => <option key={s.id} value={s.id}>{s.id}:{s.name}</option>)}
              </select>
              <button onClick={loadSnapshotDiff}>Diff</button>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
              <div><div style={{ marginBottom: 6 }}><b>Left payload</b></div><Pretty value={snapDiff?.left_payload} /></div>
              <div><div style={{ marginBottom: 6 }}><b>Right payload</b></div><Pretty value={snapDiff?.right_payload} /></div>
            </div>
            <div style={{ maxHeight: 240, overflow: 'auto' }}>
              {(snapDiff?.changes || []).map((c:any, idx:number) => (
                <div key={idx} style={{ marginBottom: 6, padding: 8, background: '#121a30', borderRadius: 8 }}>
                  <div><b>{c.kind}</b> — {c.path}</div>
                </div>
              ))}
            </div>
          </>
        )}
      </section>
    </div>
  );
}
