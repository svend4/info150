import { useEffect, useState } from "react";

type ScenarioItem = { id: string; name: string; description: string; casualty_count: number; platform_count: number; is_active?: boolean };

export default function ScenariosPage() {
  const [items, setItems] = useState<ScenarioItem[]>([]);
  const [currentId, setCurrentId] = useState<string>("");
  const [busy, setBusy] = useState<string>("");

  function reload() {
    fetch("http://127.0.0.1:8000/scenarios").then((r) => r.json()).then(setItems);
    fetch("http://127.0.0.1:8000/scenarios/current").then((r) => r.json()).then((d) => setCurrentId(d.id));
  }

  useEffect(() => {
    reload();
  }, []);

  async function activate(id: string) {
    setBusy(id);
    await fetch(`http://127.0.0.1:8000/scenarios/${id}/activate`, { method: "POST" });
    setBusy("");
    reload();
  }

  async function exportScenario(id: string) {
    const payload = await fetch(`http://127.0.0.1:8000/scenarios/export/${id}`).then((r) => r.json());
    navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
  }

  return (
    <section style={{ background: "#0e1528", borderRadius: 12, padding: 16, gridColumn: "1 / span 2" }}>
      <h3 style={{ marginTop: 0 }}>Scenario Registry</h3>
      {items.map((s) => (
        <div key={s.id} style={{ marginBottom: 10, padding: 12, background: "#121a30", borderRadius: 8 }}>
          <div><b>{s.name}</b> {currentId === s.id ? "(active)" : ""}</div>
          <div style={{ opacity: 0.85 }}>{s.description}</div>
          <div style={{ opacity: 0.8 }}>casualties: {s.casualty_count}, platforms: {s.platform_count}</div>
          <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
            <button disabled={busy === s.id || currentId === s.id} onClick={() => activate(s.id)}>
              {busy === s.id ? "Activating…" : currentId === s.id ? "Active" : "Activate"}
            </button>
            <button onClick={() => exportScenario(s.id)}>Copy Export JSON</button>
          </div>
        </div>
      ))}
    </section>
  );
}
