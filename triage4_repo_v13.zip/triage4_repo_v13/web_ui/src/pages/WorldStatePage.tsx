
type WorldState = {
  scenario?: { id: string; name: string; description?: string };
  summary: {
    casualty_count: number;
    immediate_count: number;
    delayed_count: number;
    minimal_count: number;
    avg_deterioration_risk: number;
    avg_confidence?: number;
    revisit_count?: number;
  };
  analytics?: {
    asset_load?: Record<string, number>;
    risk_bands?: Record<string, number>;
    priority_histogram?: Record<string, number>;
  };
  casualties: {
    id: string;
    priority: string;
    confidence: number;
    deterioration_risk: number;
    assigned_asset?: string | null;
    revisit_required: boolean;
    uncertainty_band?: string | null;
  }[];
};

function color(priority: string) {
  if (priority === "immediate") return "#ff5c5c";
  if (priority === "delayed") return "#ffb84d";
  return "#63d471";
}

export default function WorldStatePage({ worldState }: { worldState: WorldState | null }) {
  return (
    <section style={{ background: "#0e1528", borderRadius: 12, padding: 16, gridColumn: "1 / span 2" }}>
      <h3 style={{ marginTop: 0 }}>World State</h3>
      {!worldState ? (
        <div>Loading world state…</div>
      ) : (
        <>
          <div style={{ marginBottom: 12, opacity: 0.85 }}>
            Scenario: <b>{worldState.scenario?.name ?? "—"}</b> ({worldState.scenario?.id ?? "n/a"})
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 12, marginBottom: 16 }}>
            <div style={{ background: "#121a30", padding: 12, borderRadius: 8 }}><div style={{ opacity: 0.8 }}>Casualties</div><div><b>{worldState.summary.casualty_count}</b></div></div>
            <div style={{ background: "#121a30", padding: 12, borderRadius: 8 }}><div style={{ opacity: 0.8 }}>Immediate</div><div><b>{worldState.summary.immediate_count}</b></div></div>
            <div style={{ background: "#121a30", padding: 12, borderRadius: 8 }}><div style={{ opacity: 0.8 }}>Delayed</div><div><b>{worldState.summary.delayed_count}</b></div></div>
            <div style={{ background: "#121a30", padding: 12, borderRadius: 8 }}><div style={{ opacity: 0.8 }}>Minimal</div><div><b>{worldState.summary.minimal_count}</b></div></div>
            <div style={{ background: "#121a30", padding: 12, borderRadius: 8 }}><div style={{ opacity: 0.8 }}>Avg conf.</div><div><b>{worldState.summary.avg_confidence ?? "—"}</b></div></div>
            <div style={{ background: "#121a30", padding: 12, borderRadius: 8 }}><div style={{ opacity: 0.8 }}>Revisits</div><div><b>{worldState.summary.revisit_count ?? "—"}</b></div></div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
            <div style={{ background: "#121a30", padding: 12, borderRadius: 8 }}>
              <div><b>Asset Load</b></div>
              {Object.entries(worldState.analytics?.asset_load ?? {}).map(([k,v]) => (
                <div key={k} style={{ opacity: 0.85 }}>{k}: {v}</div>
              ))}
            </div>
            <div style={{ background: "#121a30", padding: 12, borderRadius: 8 }}>
              <div><b>Risk Bands</b></div>
              {Object.entries(worldState.analytics?.risk_bands ?? {}).map(([k,v]) => (
                <div key={k} style={{ opacity: 0.85 }}>{k}: {v}</div>
              ))}
            </div>
          </div>

          {worldState.casualties.map((c) => (
            <div key={c.id} style={{ marginBottom: 8, padding: 10, background: "#121a30", borderRadius: 8 }}>
              <div><b>{c.id}</b> — <span style={{ color: color(c.priority) }}>{c.priority}</span></div>
              <div style={{ opacity: 0.8 }}>
                confidence: {c.confidence}, deterioration: {c.deterioration_risk}, asset: {c.assigned_asset ?? "—"}, revisit: {c.revisit_required ? "yes" : "no"}, uncertainty: {c.uncertainty_band ?? "—"}
              </div>
            </div>
          ))}
        </>
      )}
    </section>
  );
}
