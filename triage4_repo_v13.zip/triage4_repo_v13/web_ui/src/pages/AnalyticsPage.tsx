import { useEffect, useState } from "react";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, LineChart, Line } from "recharts";

type ComparePayload = {
  left: { scenario?: { id?: string; name?: string }; summary?: Record<string, number> };
  right: { scenario?: { id?: string; name?: string }; summary?: Record<string, number> };
  delta: Record<string, number>;
};

type HistoryItem = {
  id: number;
  scenario_id: string;
  created_at: string;
  summary: { casualty_count: number; immediate_count: number; delayed_count: number; minimal_count: number; avg_deterioration_risk: number };
};

type ScenarioItem = { id: string; name: string; is_active?: boolean };
type CasualtyHistorySummary = { count: number; items: { casualty_id: string; samples: number; max_deterioration: number; latest_priority: string }[] };

export default function AnalyticsPage() {
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [scenarios, setScenarios] = useState<ScenarioItem[]>([]);
  const [left, setLeft] = useState<string>("default_triage");
  const [right, setRight] = useState<string>("mass_casualty_dense");
  const [compare, setCompare] = useState<ComparePayload | null>(null);
  const [casualtySummary, setCasualtySummary] = useState<CasualtyHistorySummary | null>(null);

  function reload() {
    fetch("http://127.0.0.1:8000/world_state/history?limit=12").then((r) => r.json()).then(setHistory);
    fetch("http://127.0.0.1:8000/scenarios").then((r) => r.json()).then((items: ScenarioItem[]) => setScenarios(items));
    fetch("http://127.0.0.1:8000/analytics/casualty_history").then((r) => r.json()).then(setCasualtySummary);
  }

  async function runCompare() {
    const payload = await fetch(`http://127.0.0.1:8000/scenarios/compare?left=${left}&right=${right}`).then((r) => r.json());
    setCompare(payload);
  }

  useEffect(() => { reload(); }, []);
  useEffect(() => { if (left && right) runCompare(); }, [left, right]);

  const deltaData = Object.entries(compare?.delta || {}).map(([k, v]) => ({ name: k, value: Number(v) }));
  const historyData = history.map((h) => ({ id: `#${h.id}`, immediate: h.summary?.immediate_count || 0, delayed: h.summary?.delayed_count || 0, risk: h.summary?.avg_deterioration_risk || 0 }));
  const casualtyData = casualtySummary?.items?.map((item) => ({ name: item.casualty_id, samples: item.samples, maxDeterioration: item.max_deterioration })) || [];

  return (
    <section style={{ background: "#0e1528", borderRadius: 12, padding: 16, gridColumn: "1 / span 2" }}>
      <h3 style={{ marginTop: 0 }}>Analytics Dashboard</h3>
      <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
        <select value={left} onChange={(e) => setLeft(e.target.value)}>{scenarios.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select>
        <select value={right} onChange={(e) => setRight(e.target.value)}>{scenarios.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        <div style={{ background: "#121a30", padding: 12, borderRadius: 8, height: 300 }}>
          <div><b>Scenario Delta</b></div>
          <ResponsiveContainer width="100%" height="90%">
            <BarChart data={deltaData}><CartesianGrid stroke="#223056" /><XAxis dataKey="name" hide /><YAxis /><Tooltip /><Bar dataKey="value" fill="#4fc3f7" /></BarChart>
          </ResponsiveContainer>
        </div>
        <div style={{ background: "#121a30", padding: 12, borderRadius: 8, height: 300 }}>
          <div><b>World-State History</b></div>
          <ResponsiveContainer width="100%" height="90%">
            <LineChart data={historyData}><CartesianGrid stroke="#223056" /><XAxis dataKey="id" /><YAxis /><Tooltip /><Line type="monotone" dataKey="immediate" stroke="#ff5c5c" /><Line type="monotone" dataKey="delayed" stroke="#ffb84d" /><Line type="monotone" dataKey="risk" stroke="#63d471" /></LineChart>
          </ResponsiveContainer>
        </div>
        <div style={{ background: "#121a30", padding: 12, borderRadius: 8, gridColumn: "1 / span 2", height: 320 }}>
          <div><b>Casualty History Summary</b></div>
          <ResponsiveContainer width="100%" height="90%">
            <BarChart data={casualtyData}><CartesianGrid stroke="#223056" /><XAxis dataKey="name" /><YAxis /><Tooltip /><Bar dataKey="samples" fill="#4fc3f7" /><Bar dataKey="maxDeterioration" fill="#ffb84d" /></BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </section>
  );
}
