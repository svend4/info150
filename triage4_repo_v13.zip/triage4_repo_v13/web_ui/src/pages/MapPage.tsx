type Scene = {
  casualties: { id: string; x: number; y: number; priority: string; confidence: number }[];
  platforms: { id: string; x: number; y: number; kind: string }[];
};

function color(priority: string) {
  if (priority === "immediate") return "#ff5c5c";
  if (priority === "delayed") return "#ffb84d";
  return "#63d471";
}

function scale(v: number) {
  return v * 5;
}

export default function MapPage({ scene }: { scene: Scene | null }) {
  return (
    <section style={{ background: "#0e1528", borderRadius: 12, padding: 16 }}>
      <h3 style={{ marginTop: 0 }}>Tactical Scene</h3>
      {scene ? (
        <svg width="100%" viewBox="0 0 520 520" style={{ background: "#0a1020", borderRadius: 10 }}>
          <rect x="0" y="0" width="520" height="520" fill="#0a1020" />
          {scene.casualties.map((c) => (
            <g key={c.id}>
              <circle cx={scale(c.x)} cy={scale(c.y)} r={8} fill={color(c.priority)} />
              <text x={scale(c.x) + 10} y={scale(c.y) - 8} fill="#e5ecff" fontSize="12">{c.id}</text>
            </g>
          ))}
          {scene.platforms.map((p) => (
            <g key={p.id}>
              <rect x={scale(p.x) - 7} y={scale(p.y) - 7} width={14} height={14} fill="#4fc3f7" rx={3} />
              <text x={scale(p.x) + 10} y={scale(p.y) + 4} fill="#9cc7ff" fontSize="12">{p.id}</text>
            </g>
          ))}
        </svg>
      ) : <div>Loading scene…</div>}
    </section>
  );
}
