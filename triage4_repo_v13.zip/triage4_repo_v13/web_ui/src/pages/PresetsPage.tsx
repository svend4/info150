import { useEffect, useState } from "react";

type Preset = { id: number; name: string; payload: any; updated_at?: string };

export default function PresetsPage({ sessionToken, onApply }: { sessionToken: string; onApply?: (payload: any) => void }) {
  const [items, setItems] = useState<Preset[]>([]);
  const [name, setName] = useState("My Preset");
  const [payloadText, setPayloadText] = useState('{"filters":{"priority":"all"}}');
  const [status, setStatus] = useState("");

  function reload() {
    if (!sessionToken) return;
    fetch("http://127.0.0.1:8000/presets", { headers: { "X-Session-Token": sessionToken } }).then((r) => r.json()).then(setItems);
  }

  useEffect(() => { reload(); }, [sessionToken]);

  async function save() {
    try {
      const payload = JSON.parse(payloadText);
      await fetch("http://127.0.0.1:8000/presets", {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-Session-Token": sessionToken },
        body: JSON.stringify({ name, payload }),
      });
      setStatus("Saved");
      reload();
    } catch {
      setStatus("Invalid preset JSON");
    }
  }

  async function apply(id: number) {
    const preset = await fetch(`http://127.0.0.1:8000/presets/${id}`, { headers: { "X-Session-Token": sessionToken } }).then((r) => r.json());
    setPayloadText(JSON.stringify(preset.payload, null, 2));
    onApply?.(preset.payload);
  }

  return (
    <section style={{ background: "#0e1528", borderRadius: 12, padding: 16, gridColumn: "1 / span 2" }}>
      <h3 style={{ marginTop: 0 }}>Dashboard Presets</h3>
      <div style={{ display: "flex", gap: 8, marginBottom: 10 }}>
        <input value={name} onChange={(e) => setName(e.target.value)} />
        <button disabled={!sessionToken} onClick={save}>Save Preset</button>
      </div>
      <div style={{ opacity: 0.8, marginBottom: 8 }}>{status || (sessionToken ? `Session: ${sessionToken.slice(0,8)}…` : 'Create session first')}</div>
      <textarea value={payloadText} onChange={(e) => setPayloadText(e.target.value)} style={{ width: "100%", minHeight: 180, background: "#121a30", color: "#e5ecff", border: "1px solid #223056", borderRadius: 8, padding: 12, fontFamily: "monospace" }} />
      <div style={{ marginTop: 12 }}>
        {items.map((item) => (
          <div key={item.id} style={{ marginBottom: 8, padding: 10, background: "#121a30", borderRadius: 8 }}>
            <div><b>{item.name}</b></div>
            <div style={{ opacity: 0.8 }}>{item.updated_at}</div>
            <button onClick={() => apply(item.id)}>Apply</button>
          </div>
        ))}
      </div>
    </section>
  );
}
