import { useEffect, useState } from "react";

type EventItem = { id: string; kind: string; title: string; created_at: string; payload: any };

export default function EventsPage() {
  const [items, setItems] = useState<EventItem[]>([]);
  useEffect(() => {
    fetch("http://127.0.0.1:8000/events/feed?limit=50").then((r) => r.json()).then(setItems);
  }, []);
  return (
    <div style={{ background: "#0e1528", borderRadius: 12, padding: 16 }}>
      <h3 style={{ marginTop: 0 }}>Event Feed</h3>
      {items.map((it) => (
        <div key={it.id} style={{ marginBottom: 8, padding: 10, background: "#121a30", borderRadius: 8 }}>
          <div><b>{it.kind}</b> — {it.title}</div>
          <div style={{ opacity: 0.8 }}>{it.created_at}</div>
        </div>
      ))}
    </div>
  );
}
