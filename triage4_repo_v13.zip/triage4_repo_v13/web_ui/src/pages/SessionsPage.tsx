
import { useEffect, useState } from "react";

type SessionItem = { id: string; frame_count: number; kind: string };

export default function SessionsPage() {
  const [items, setItems] = useState<SessionItem[]>([]);
  const [exported, setExported] = useState<string>("");

  function reload() {
    fetch("http://127.0.0.1:8000/replay/sessions").then((r) => r.json()).then(setItems);
  }

  useEffect(() => {
    reload();
  }, []);

  async function exportSession(id: string) {
    const payload = await fetch(`http://127.0.0.1:8000/replay/export/${id}`).then((r) => r.json());
    setExported(JSON.stringify(payload, null, 2));
  }

  async function createSnapshot() {
    await fetch("http://127.0.0.1:8000/replay?persist=true&session_id=manual_snapshot");
    reload();
  }

  return (
    <section style={{ background: "#0e1528", borderRadius: 12, padding: 16, gridColumn: "1 / span 2" }}>
      <h3 style={{ marginTop: 0 }}>Replay Sessions</h3>
      <button onClick={createSnapshot} style={{ marginBottom: 12 }}>Create snapshot</button>
      {items.map((s) => (
        <div key={s.id} style={{ marginBottom: 10, padding: 12, background: "#121a30", borderRadius: 8 }}>
          <div><b>{s.id}</b></div>
          <div style={{ opacity: 0.8 }}>frames: {s.frame_count}</div>
          <button onClick={() => exportSession(s.id)} style={{ marginTop: 8 }}>Export</button>
        </div>
      ))}
      {exported && (
        <pre style={{ whiteSpace: "pre-wrap", background: "#121a30", padding: 12, borderRadius: 8, overflow: "auto" }}>{exported}</pre>
      )}
    </section>
  );
}
