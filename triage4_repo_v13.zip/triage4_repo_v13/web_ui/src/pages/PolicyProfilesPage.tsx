import { useEffect, useState } from "react";

export default function PolicyProfilesPage({ sessionToken }: { sessionToken: string }) {
  const [profiles, setProfiles] = useState<any[]>([]);
  const [profileId, setProfileId] = useState("custom_v12");
  const [jsonText, setJsonText] = useState('{\n  "role_actions": {\n    "viewer": ["events:read"],\n    "analyst": ["scenario:compare", "workspace:edit"],\n    "operator": ["jobs:queue", "scenario:activate"],\n    "admin": ["users:mutate", "policy:activate"]\n  }\n}');

  async function load() {
    if (!sessionToken) return;
    const data = await fetch("http://127.0.0.1:8000/policy/profiles", { headers: { 'X-Session-Token': sessionToken } }).then(r => r.json());
    setProfiles(data);
  }

  useEffect(() => { load(); }, [sessionToken]);

  async function save() {
    await fetch("http://127.0.0.1:8000/policy/profiles", {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Session-Token': sessionToken },
      body: JSON.stringify({ profile_id: profileId, payload: JSON.parse(jsonText) })
    });
    load();
  }

  async function activate(id: string) {
    await fetch(`http://127.0.0.1:8000/policy/profiles/${id}/activate`, { method: 'POST', headers: { 'X-Session-Token': sessionToken } });
    load();
  }

  if (!sessionToken) return <div style={{ background: '#0e1528', borderRadius: 12, padding: 16 }}>Create an admin session first.</div>;

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '360px 1fr', gap: 16 }}>
      <section style={{ background: '#0e1528', borderRadius: 12, padding: 16 }}>
        <h3 style={{ marginTop: 0 }}>Policy Profiles</h3>
        {profiles.map((p) => (
          <div key={p.id} style={{ marginBottom: 8, padding: 10, background: '#121a30', borderRadius: 8 }}>
            <div><b>{p.id}</b> {p.is_active ? '(active)' : ''}</div>
            <button onClick={() => activate(p.id)} disabled={p.is_active}>Activate</button>
          </div>
        ))}
      </section>
      <section style={{ background: '#0e1528', borderRadius: 12, padding: 16 }}>
        <h3 style={{ marginTop: 0 }}>Editor</h3>
        <input value={profileId} onChange={(e) => setProfileId(e.target.value)} style={{ width: '100%', marginBottom: 8 }} />
        <textarea value={jsonText} onChange={(e) => setJsonText(e.target.value)} style={{ width: '100%', minHeight: 320 }} />
        <div style={{ marginTop: 10 }}><button onClick={save}>Save Profile</button></div>
      </section>
    </div>
  );
}
