import { useEffect, useState } from "react";

export default function NotificationsPage({ sessionToken }: { sessionToken: string }) {
  const [feed, setFeed] = useState<any[]>([]);
  const [sub, setSub] = useState<any>({ kinds: ["audit", "job"], actions: [], muted: false, pause_until: "", digest_mode: "realtime" });

  async function load() {
    if (!sessionToken) return;
    const s = await fetch("http://127.0.0.1:8000/notifications/preferences", { headers: { 'X-Session-Token': sessionToken } }).then(r => r.json());
    setSub(s.payload || s);
    const f = await fetch("http://127.0.0.1:8000/notifications/feed?only_unread=false", { headers: { 'X-Session-Token': sessionToken } }).then(r => r.json());
    setFeed(f);
  }

  useEffect(() => { load(); }, [sessionToken]);

  async function saveSub() {
    await fetch("http://127.0.0.1:8000/notifications/preferences", {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Session-Token': sessionToken },
      body: JSON.stringify(sub)
    });
    load();
  }

  async function markRead(eventId: string) {
    await fetch(`http://127.0.0.1:8000/notifications/mark_read/${encodeURIComponent(eventId)}`, { method: 'POST', headers: { 'X-Session-Token': sessionToken } });
    load();
  }

  if (!sessionToken) return <div style={{ background: '#0e1528', borderRadius: 12, padding: 16 }}>Create a session first.</div>;

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '320px 1fr', gap: 16 }}>
      <section style={{ background: '#0e1528', borderRadius: 12, padding: 16 }}>
        <h3 style={{ marginTop: 0 }}>Subscriptions</h3>
        <div style={{ marginBottom: 8 }}>Kinds</div>
        <label><input type='checkbox' checked={sub.kinds?.includes('audit')} onChange={(e) => setSub((prev:any) => ({ ...prev, kinds: e.target.checked ? [...new Set([...(prev.kinds||[]), 'audit'])] : (prev.kinds||[]).filter((x:string)=>x!=='audit') }))} /> audit</label><br />
        <label><input type='checkbox' checked={sub.kinds?.includes('job')} onChange={(e) => setSub((prev:any) => ({ ...prev, kinds: e.target.checked ? [...new Set([...(prev.kinds||[]), 'job'])] : (prev.kinds||[]).filter((x:string)=>x!=='job') }))} /> job</label>
        <label><input type='checkbox' checked={!!sub.muted} onChange={(e) => setSub((prev:any) => ({ ...prev, muted: e.target.checked }))} /> muted</label>
        <div style={{ marginTop: 12, marginBottom: 8 }}>Pause until (ISO timestamp or blank)</div>
        <input value={sub.pause_until || ""} onChange={(e) => setSub((prev:any) => ({ ...prev, pause_until: e.target.value }))} style={{ width: '100%' }} />
        <div style={{ marginTop: 12, marginBottom: 8 }}>Digest mode</div>
        <select value={sub.digest_mode || "realtime"} onChange={(e) => setSub((prev:any) => ({ ...prev, digest_mode: e.target.value }))}><option value='realtime'>realtime</option><option value='batched'>batched</option></select>
        <div style={{ marginTop: 12, marginBottom: 8 }}>Audit actions filter (comma separated)</div>
        <input value={(sub.actions || []).join(',')} onChange={(e) => setSub((prev:any) => ({ ...prev, actions: e.target.value.split(',').map(s => s.trim()).filter(Boolean) }))} style={{ width: '100%' }} />
        <div style={{ marginTop: 12 }}><button onClick={saveSub}>Save</button></div>
      </section>
      <section style={{ background: '#0e1528', borderRadius: 12, padding: 16 }}>
        <h3 style={{ marginTop: 0 }}>Notifications</h3>
        {feed.map((item) => (
          <div key={item.id} style={{ marginBottom: 8, padding: 10, background: item.unread ? '#16213a' : '#121a30', borderRadius: 8 }}>
            <div><b>{item.kind}</b> — {item.title}</div>
            <div style={{ opacity: 0.8, fontSize: 12 }}>{item.created_at}</div>
            <div style={{ marginTop: 6 }}><button onClick={() => markRead(item.id)} disabled={!item.unread}>{item.unread ? 'Mark read' : 'Read'}</button></div>
          </div>
        ))}
      </section>
    </div>
  );
}
