import { useEffect, useState } from "react";

type Props = {
  sessionToken: string;
};

export default function WorkspacePage({ sessionToken }: Props) {
  const [workspace, setWorkspace] = useState<any>(null);
  const [layoutJson, setLayoutJson] = useState('{"leftPanel":340,"tab":"overview"}');

  async function loadWorkspace() {
    if (!sessionToken) return;
    const data = await fetch("http://127.0.0.1:8000/workspace/export", { headers: { "X-Session-Token": sessionToken } }).then((r) => r.json());
    setWorkspace(data.workspace);
    if (data.workspace?.layout) {
      setLayoutJson(JSON.stringify(data.workspace.layout));
    }
  }

  useEffect(() => {
    loadWorkspace();
  }, [sessionToken]);

  async function saveLayout() {
    if (!sessionToken) return;
    const layout = JSON.parse(layoutJson || '{}');
    await fetch("http://127.0.0.1:8000/workspace/layout", {
      method: "PUT",
      headers: { "Content-Type": "application/json", "X-Session-Token": sessionToken },
      body: JSON.stringify({ layout })
    });
    await loadWorkspace();
  }

  async function importWorkspace() {
    if (!sessionToken) return;
    const payload = { layout: JSON.parse(layoutJson || '{}') };
    await fetch("http://127.0.0.1:8000/workspace/import", {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Session-Token": sessionToken },
      body: JSON.stringify({ payload })
    });
    await loadWorkspace();
  }

  if (!sessionToken) return <div style={{ background: "#0e1528", borderRadius: 12, padding: 16 }}>Create a session first.</div>;

  return (
    <div style={{ background: "#0e1528", borderRadius: 12, padding: 16 }}>
      <h3 style={{ marginTop: 0 }}>Workspace</h3>
      <textarea value={layoutJson} onChange={(e) => setLayoutJson(e.target.value)} rows={6} style={{ width: "100%", marginBottom: 12 }} />
      <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
        <button onClick={saveLayout}>Save Layout</button>
        <button onClick={importWorkspace}>Import Workspace</button>
        <button onClick={loadWorkspace}>Reload</button>
      </div>
      <pre style={{ background: "#121a30", padding: 12, borderRadius: 8, overflowX: "auto" }}>{JSON.stringify(workspace, null, 2)}</pre>
    </div>
  );
}
