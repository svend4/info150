import { useEffect, useState } from "react";

export default function CompareBaselinesPage({ sessionToken }: { sessionToken: string }) {
  const [items, setItems] = useState<any[]>([]);
  const [baselineId, setBaselineId] = useState('default_baseline');
  const [left, setLeft] = useState('default_triage');
  const [right, setRight] = useState('mass_casualty_dense');
  const [result, setResult] = useState<any>(null);

  async function load() {
    const data = await fetch('http://127.0.0.1:8000/analytics/compare/baselines').then(r => r.json());
    setItems(data);
  }
  useEffect(() => { load(); }, []);

  async function save() {
    await fetch(`http://127.0.0.1:8000/analytics/compare/baselines/${baselineId}?left=${encodeURIComponent(left)}&right=${encodeURIComponent(right)}`, {
      method: 'POST',
      headers: { 'X-Session-Token': sessionToken }
    });
    load();
  }

  async function run(id: string) {
    const data = await fetch(`http://127.0.0.1:8000/analytics/compare/baselines/${id}/run`).then(r => r.json());
    setResult(data);
  }

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '320px 1fr', gap: 16 }}>
      <section style={{ background: '#0e1528', borderRadius: 12, padding: 16 }}>
        <h3 style={{ marginTop: 0 }}>Compare Baselines</h3>
        <input value={baselineId} onChange={(e) => setBaselineId(e.target.value)} style={{ width: '100%', marginBottom: 8 }} />
        <input value={left} onChange={(e) => setLeft(e.target.value)} style={{ width: '100%', marginBottom: 8 }} />
        <input value={right} onChange={(e) => setRight(e.target.value)} style={{ width: '100%', marginBottom: 8 }} />
        <button onClick={save} disabled={!sessionToken}>Save Baseline</button>
        <div style={{ marginTop: 16 }}>
          {items.map((item) => (
            <div key={item.id} style={{ marginBottom: 8, padding: 10, background: '#121a30', borderRadius: 8 }}>
              <div><b>{item.id}</b></div>
              <div style={{ opacity: 0.8, fontSize: 12 }}>{item.left_scenario} vs {item.right_scenario}</div>
              <button onClick={() => run(item.id)}>Run</button>
            </div>
          ))}
        </div>
      </section>
      <section style={{ background: '#0e1528', borderRadius: 12, padding: 16 }}>
        <h3 style={{ marginTop: 0 }}>Baseline Run Result</h3>
        <pre style={{ whiteSpace: 'pre-wrap', fontSize: 12, background: '#121a30', padding: 10, borderRadius: 8, overflow: 'auto', maxHeight: 560 }}>{JSON.stringify(result ?? {}, null, 2)}</pre>
      </section>
    </div>
  );
}
