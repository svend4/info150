import { useEffect, useMemo, useState } from "react";

type ReplayFrame = {
  t: number;
  platforms: { id: string; x: number; y: number; kind: string }[];
  casualties: { id: string; x: number; y: number; priority: string; confidence: number; deterioration_risk: number }[];
};

type ReplayData = {
  frames: ReplayFrame[];
};

function color(priority: string) {
  if (priority === "immediate") return "#ff5c5c";
  if (priority === "delayed") return "#ffb84d";
  return "#63d471";
}

function scale(v: number) {
  return v * 5;
}

export default function ReplayPage() {
  const [data, setData] = useState<ReplayData | null>(null);
  const [idx, setIdx] = useState(0);

  useEffect(() => {
    fetch("http://127.0.0.1:8000/replay/latest")
      .then((r) => r.json())
      .then(setData);
  }, []);

  useEffect(() => {
    if (!data?.frames?.length) return;
    const timer = setInterval(() => {
      setIdx((prev) => (prev + 1) % data.frames.length);
    }, 1100);
    return () => clearInterval(timer);
  }, [data]);

  const frame = useMemo(() => {
    if (!data?.frames?.length) return null;
    return data.frames[Math.min(idx, data.frames.length - 1)];
  }, [data, idx]);

  if (!frame) return <div>Loading replay…</div>;

  return (
    <div style={{ background: "#0e1528", borderRadius: 12, padding: 16 }}>
      <h3 style={{ marginTop: 0 }}>Replay Timeline</h3>
      <div style={{ opacity: 0.85, marginBottom: 10 }}>Frame: {frame.t}</div>

      <svg width="100%" viewBox="0 0 520 520" style={{ background: "#0a1020", borderRadius: 10 }}>
        <rect x="0" y="0" width="520" height="520" fill="#0a1020" />

        {frame.casualties.map((c) => (
          <g key={c.id}>
            <circle cx={scale(c.x)} cy={scale(c.y)} r={8} fill={color(c.priority)} />
            <text x={scale(c.x) + 10} y={scale(c.y) - 8} fill="#e5ecff" fontSize="12">
              {c.id}
            </text>
          </g>
        ))}

        {frame.platforms.map((p) => (
          <g key={p.id}>
            <rect x={scale(p.x) - 7} y={scale(p.y) - 7} width={14} height={14} fill="#4fc3f7" rx={3} />
            <text x={scale(p.x) + 10} y={scale(p.y) + 4} fill="#9cc7ff" fontSize="12">
              {p.id}
            </text>
          </g>
        ))}
      </svg>

      <div style={{ marginTop: 12 }}>
        {frame.casualties.map((c) => (
          <div key={c.id} style={{ marginBottom: 8, padding: 10, background: "#121a30", borderRadius: 8 }}>
            <div><b>{c.id}</b> — {c.priority}</div>
            <div style={{ opacity: 0.8 }}>
              confidence: {c.confidence}, deterioration: {c.deterioration_risk}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
