import { useEffect, useState } from "react";
import ReplayPage from "./pages/ReplayPage";
import MapPage from "./pages/MapPage";
import CoordinationPage from "./pages/CoordinationPage";
import CasualtyPage from "./pages/CasualtyPage";
import WorldStatePage from "./pages/WorldStatePage";
import ScenariosPage from "./pages/ScenariosPage";
import SessionsPage from "./pages/SessionsPage";
import AnalyticsPage from "./pages/AnalyticsPage";
import ScenarioEditorPage from "./pages/ScenarioEditorPage";
import PresetsPage from "./pages/PresetsPage";
import JobsPage from "./pages/JobsPage";
import WorkspacePage from "./pages/WorkspacePage";
import AuditPage from "./pages/AuditPage";
import WorkspaceHistoryPage from "./pages/WorkspaceHistoryPage";
import EventsPage from "./pages/EventsPage";
import DiffsPage from "./pages/DiffsPage";
import NotificationsPage from "./pages/NotificationsPage";
import PolicyProfilesPage from "./pages/PolicyProfilesPage";
import CompareBaselinesPage from "./pages/CompareBaselinesPage";
import DigestPresetsPage from "./pages/DigestPresetsPage";
import PolicyDiffPage from "./pages/PolicyDiffPage";
import TimelinePage from "./pages/TimelinePage";

type Casualty = {
  id: string;
  triage_priority: string;
  confidence: number;
  deterioration_risk: number;
  assigned_asset?: string | null;
  revisit_required: boolean;
  location: { x: number; y: number; z: number };
  bleeding_score: number;
  thermal_anomaly_score: number;
  uncertainty: { score: number; band: string; signal_quality: number };
  state_hypotheses: { name: string; score: number; explanation: string }[];
  priority_history: { t: number; priority: string; confidence: number }[];
};

type Scene = {
  scenario?: { id: string; name: string };
  casualties: { id: string; x: number; y: number; priority: string; confidence: number }[];
  platforms: { id: string; x: number; y: number; kind: string }[];
};

type Coordination = {
  assignments: { asset: string; casualty_id: string; action: string; priority: string }[];
  revisit_queue: { casualty_id: string; reason: string }[];
};

type WorldState = {
  scenario?: { id: string; name: string; description?: string };
  summary: { casualty_count: number; immediate_count: number; delayed_count: number; minimal_count: number; avg_deterioration_risk: number; avg_confidence?: number; revisit_count?: number; };
  analytics?: { asset_load?: Record<string, number>; risk_bands?: Record<string, number>; priority_histogram?: Record<string, number>; };
  casualties: { id: string; priority: string; confidence: number; deterioration_risk: number; assigned_asset?: string | null; revisit_required: boolean; uncertainty_band?: string | null; }[];
};

type TabKey = "overview" | "replay" | "world" | "scenarios" | "editor" | "sessions" | "analytics" | "presets" | "jobs" | "workspace" | "audit" | "workspace_history" | "events" | "diffs" | "notifications" | "policy" | "baselines" | "digest_presets" | "policy_diff" | "timeline";

function color(priority: string) {
  if (priority === "immediate") return "#ff5c5c";
  if (priority === "delayed") return "#ffb84d";
  return "#63d471";
}

export default function App() {
  const [casualties, setCasualties] = useState<Casualty[]>([]);
  const [scene, setScene] = useState<Scene | null>(null);
  const [coordination, setCoordination] = useState<Coordination | null>(null);
  const [worldState, setWorldState] = useState<WorldState | null>(null);
  const [selected, setSelected] = useState<Casualty | null>(null);
  const [handoff, setHandoff] = useState<any | null>(null);
  const [tab, setTab] = useState<TabKey>("overview");
  const [sessionToken, setSessionToken] = useState("");
  const [userId, setUserId] = useState("analyst_1");
  const [activeFilters, setActiveFilters] = useState<any>({ priority: "all" });
  const [sessionRole, setSessionRole] = useState<string>("viewer");

  function reload() {
    fetch("http://127.0.0.1:8000/casualties")
      .then((r) => r.json())
      .then((data: Casualty[]) => {
        setCasualties(data);
        if (data.length > 0) setSelected((prev) => data.find((d) => d.id === prev?.id) ?? data[0]);
      });

    fetch("http://127.0.0.1:8000/scene").then((r) => r.json()).then(setScene);
    fetch("http://127.0.0.1:8000/coordination").then((r) => r.json()).then(setCoordination);
    fetch("http://127.0.0.1:8000/world_state").then((r) => r.json()).then(setWorldState);
  }

  useEffect(() => {
    reload();
  }, []);

  useEffect(() => {
    if (!selected) return;
    fetch(`http://127.0.0.1:8000/handoff/${selected.id}`).then((r) => r.json()).then(setHandoff);
  }, [selected]);

  async function createSession() {
    const sess = await fetch("http://127.0.0.1:8000/auth/session", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ user_id: userId })
    }).then((r) => r.json());
    setSessionToken(sess.token);
    setActiveFilters(sess.payload?.filters || { priority: "all" });
    setSessionRole(sess.role || "analyst");
  }

  async function applyPreset(payload: any) {
    const filters = payload?.filters || { priority: "all" };
    setActiveFilters(filters);
    if (sessionToken) {
      await fetch(`http://127.0.0.1:8000/auth/session/${sessionToken}/filters`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ filters })
      });
    }
  }

  const shownCasualties = casualties.filter((c) => activeFilters.priority === 'all' ? true : c.triage_priority === activeFilters.priority);

  return (
    <div style={{ display: "grid", gridTemplateColumns: "340px 1fr", minHeight: "100vh" }}>
      <aside style={{ borderRight: "1px solid #1e2a44", padding: 16 }}>
        <h2 style={{ marginTop: 0 }}>triage4</h2>
        <div style={{ opacity: 0.8, marginBottom: 8 }}>v12 operational shell</div>
        <div style={{ opacity: 0.8, marginBottom: 14 }}>Scenario: {scene?.scenario?.name ?? worldState?.scenario?.name ?? "—"}</div>

        <div style={{ display: "flex", gap: 8, marginBottom: 10 }}>
          <input value={userId} onChange={(e) => setUserId(e.target.value)} style={{ width: 120 }} />
          <button onClick={createSession}>{sessionToken ? 'New Session' : 'Create Session'}</button>
        </div>
        <div style={{ opacity: 0.8, marginBottom: 4 }}>Session: {sessionToken ? `${sessionToken.slice(0,8)}…` : 'none'}</div>
        <div style={{ opacity: 0.8, marginBottom: 8 }}>Role: {sessionRole}</div>
        <div style={{ opacity: 0.8, marginBottom: 8 }}>Worker: online</div>
        <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
          <select value={activeFilters.priority} onChange={(e) => setActiveFilters((prev:any) => ({ ...prev, priority: e.target.value }))}>
            <option value="all">all</option>
            <option value="immediate">immediate</option>
            <option value="delayed">delayed</option>
            <option value="minimal">minimal</option>
          </select>
        </div>

        <div style={{ display: "flex", gap: 8, marginBottom: 14, flexWrap: "wrap" }}>
          <button onClick={() => setTab("overview")}>Overview</button>
          <button onClick={() => setTab("replay")}>Replay</button>
          <button onClick={() => setTab("world")}>World</button>
          <button onClick={() => setTab("scenarios")}>Scenarios</button>
          <button onClick={() => setTab("editor")}>Editor</button>
          <button onClick={() => setTab("sessions")}>Sessions</button>
          <button onClick={() => setTab("analytics")}>Analytics</button>
          <button onClick={() => setTab("presets")}>Presets</button>
          <button onClick={() => setTab("jobs")}>Jobs</button>
          <button onClick={() => setTab("workspace")}>Workspace</button>
          <button onClick={() => setTab("workspace_history")}>Workspace History</button>
          <button onClick={() => setTab("audit")}>Audit</button>
          <button onClick={() => setTab("events")}>Events</button>
          <button onClick={() => setTab("diffs")}>Diffs</button>
          <button onClick={() => setTab("notifications")}>Notifications</button>
          <button onClick={() => setTab("policy")}>Policy</button>
          <button onClick={() => setTab("baselines")}>Baselines</button>
          <button onClick={() => setTab("digest_presets")}>Digest</button>
          <button onClick={() => setTab("policy_diff")}>Policy Diff</button>
          <button onClick={() => setTab("timeline")}>Timeline</button>
          <button onClick={reload}>Refresh</button>
        </div>

        {shownCasualties.map((c) => (
          <div
            key={c.id}
            onClick={() => {
              setSelected(c);
              setTab("overview");
            }}
            style={{
              cursor: "pointer",
              marginBottom: 10,
              padding: 12,
              borderRadius: 10,
              border: `1px solid ${color(c.triage_priority)}`,
              background: selected?.id === c.id ? "#121a30" : "#0e1528"
            }}
          >
            <div><b>{c.id}</b></div>
            <div style={{ color: color(c.triage_priority), textTransform: "uppercase" }}>{c.triage_priority}</div>
            <div style={{ fontSize: 12, opacity: 0.8 }}>confidence: {c.confidence}</div>
            <div style={{ fontSize: 12, opacity: 0.8 }}>deterioration: {c.deterioration_risk}</div>
            <div style={{ fontSize: 12, opacity: 0.8 }}>uncertainty: {c.uncertainty?.band}</div>
          </div>
        ))}
      </aside>

      <main style={{ padding: 18 }}>
        {tab === "replay" && <ReplayPage />}
        {tab === "world" && <WorldStatePage worldState={worldState} />}
        {tab === "scenarios" && <ScenariosPage />}
        {tab === "editor" && <ScenarioEditorPage />}
        {tab === "sessions" && <SessionsPage />}
        {tab === "analytics" && <AnalyticsPage />}
        {tab === "presets" && <PresetsPage sessionToken={sessionToken} onApply={applyPreset} />}
        {tab === "jobs" && <JobsPage />}
        {tab === "workspace" && <WorkspacePage sessionToken={sessionToken} />}
        {tab === "workspace_history" && <WorkspaceHistoryPage sessionToken={sessionToken} />}
        {tab === "audit" && <AuditPage sessionToken={sessionToken} />}
        {tab === "events" && <EventsPage />}
        {tab === "diffs" && <DiffsPage sessionToken={sessionToken} />}
        {tab === "notifications" && <NotificationsPage sessionToken={sessionToken} />}
        {tab === "policy" && <PolicyProfilesPage sessionToken={sessionToken} />}
        {tab === "baselines" && <CompareBaselinesPage sessionToken={sessionToken} />}
        {tab === "digest_presets" && <DigestPresetsPage sessionToken={sessionToken} />}
        {tab === "policy_diff" && <PolicyDiffPage sessionToken={sessionToken} />}
        {tab === "timeline" && <TimelinePage />}

        {tab === "overview" && (
          <div style={{ display: "grid", gridTemplateColumns: "1.2fr 1fr", gap: 16 }}>
            <MapPage scene={scene} />
            <CoordinationPage coordination={coordination} />
            <CasualtyPage selected={selected} handoff={handoff} />
          </div>
        )}
      </main>
    </div>
  );
}
